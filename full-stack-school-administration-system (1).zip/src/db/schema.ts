import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export function generateStudentBarcode(nisn: string): string {
  const clean = nisn.trim().replace(/\s+/g, "").toUpperCase();
  return `SMPN1UML-${clean}`;
}

export function calculateGradeSummary(
  assignmentScore: number,
  midtermScore: number,
  finalScore: number
): { totalScore: number; predicate: string } {
  const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));
  const a = clamp(assignmentScore);
  const m = clamp(midtermScore);
  const f = clamp(finalScore);
  const totalScore = Math.round(a * 0.3 + m * 0.3 + f * 0.4);
  const predicate =
    totalScore >= 90
      ? "A"
      : totalScore >= 80
      ? "B"
      : totalScore >= 75
      ? "C"
      : "D";
  return { totalScore, predicate };
}

export const schoolSettings = pgTable("school_settings", {
  id: serial("id").primaryKey(),
  schoolName: text("school_name").notNull().default("SMP Negeri 1 Umalulu"),
  npsn: text("npsn").notNull().default("50303812"),
  address: text("address")
    .notNull()
    .default(
      "Jl. Raya Melolo - Umalulu, Kec. Umalulu, Kab. Sumba Timur, Nusa Tenggara Timur"
    ),
  academicYear: text("academic_year").notNull().default("2025/2026"),
  semester: text("semester").notNull().default("Genap"),
  principalName: text("principal_name")
    .notNull()
    .default("Drs. Umbu Maramba Meha, M.Pd."),
  principalNip: text("principal_nip")
    .notNull()
    .default("19690817 199512 1 003"),
  email: text("email").notNull().default("info@smpn1umalulu.sch.id"),
  phone: text("phone").notNull().default("(0387) 241088"),
  logoUrl: text("logo_url")
    .notNull()
    .default("/images/logo-smpn1-umalulu.png"),
  demoSeeded: boolean("demo_seeded").notNull().default(false),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nip: text("nip").notNull(),
  subject: text("subject").notNull(),
  employmentStatus: text("employment_status").notNull().default("PNS"),
  phone: text("phone").notNull().default(""),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const schoolClasses = pgTable("school_classes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  gradeLevel: integer("grade_level").notNull().default(7),
  room: text("room").notNull().default("R-01"),
  academicYear: text("academic_year").notNull().default("2025/2026"),
  capacity: integer("capacity").notNull().default(32),
  homeroomTeacherId: integer("homeroom_teacher_id")
    .references(() => teachers.id, { onDelete: "set null" })
    .unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  category: text("category").notNull().default("Umum"),
  kkm: integer("kkm").notNull().default(75),
  weeklyHours: integer("weekly_hours").notNull().default(4),
  teacherId: integer("teacher_id").references(() => teachers.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  nisn: text("nisn").notNull().unique(),
  nis: text("nis").notNull().default(""),
  barcodeCode: text("barcode_code").notNull().unique(),
  name: text("name").notNull(),
  gender: text("gender").notNull().default("L"),
  classId: integer("class_id")
    .notNull()
    .references(() => schoolClasses.id, { onDelete: "cascade" }),
  birthPlace: text("birth_place").notNull().default("Umalulu"),
  birthDate: text("birth_date").notNull().default(""),
  parentName: text("parent_name").notNull().default(""),
  address: text("address").notNull().default("Kec. Umalulu"),
  status: text("status").notNull().default("Aktif"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const attendanceRecords = pgTable(
  "attendance_records",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    classId: integer("class_id")
      .notNull()
      .references(() => schoolClasses.id, { onDelete: "cascade" }),
    attendanceType: text("attendance_type").notNull(), // 'mapel' | 'wali'
    subjectName: text("subject_name").notNull().default("Guru Wali"),
    teacherId: integer("teacher_id").references(() => teachers.id, {
      onDelete: "set null",
    }),
    date: text("date").notNull(), // YYYY-MM-DD
    status: text("status").notNull(), // 'H' | 'S' | 'I' | 'A'
    notes: text("notes").notNull().default(""),
    recordedBy: text("recorded_by").notNull().default("Admin Sistem"),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("attendance_unique_idx").on(
      table.studentId,
      table.date,
      table.attendanceType,
      table.subjectName
    ),
  ]
);

export const studentGrades = pgTable(
  "student_grades",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    classId: integer("class_id")
      .notNull()
      .references(() => schoolClasses.id, { onDelete: "cascade" }),
    subjectId: integer("subject_id")
      .notNull()
      .references(() => subjects.id, { onDelete: "cascade" }),
    semester: text("semester").notNull().default("Genap"),
    academicYear: text("academic_year").notNull().default("2025/2026"),
    assignmentScore: integer("assignment_score").notNull().default(80),
    midtermScore: integer("midterm_score").notNull().default(80),
    finalScore: integer("final_score").notNull().default(80),
    totalScore: integer("total_score").notNull().default(80),
    predicate: text("predicate").notNull().default("B"),
    teacherNotes: text("teacher_notes").notNull().default(""),
    updatedBy: text("updated_by").notNull().default("Guru Mapel"),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("student_grades_unique_idx").on(
      table.studentId,
      table.subjectId,
      table.semester,
      table.academicYear
    ),
  ]
);

export const guidanceRecords = pgTable("guidance_records", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id")
    .notNull()
    .references(() => students.id, { onDelete: "cascade" }),
  classId: integer("class_id")
    .notNull()
    .references(() => schoolClasses.id, { onDelete: "cascade" }),
  guruWaliId: integer("guru_wali_id").references(() => teachers.id, {
    onDelete: "set null",
  }),
  date: text("date").notNull(), // YYYY-MM-DD
  category: text("category").notNull().default("Akademik & Nilai"),
  topic: text("topic").notNull(),
  notes: text("notes").notNull().default(""),
  followUpPlan: text("follow_up_plan").notNull().default(""),
  parentInvolved: boolean("parent_involved").notNull().default(false),
  status: text("status").notNull().default("Dalam Pemantauan"),
  createdBy: text("created_by").notNull().default("Guru Wali"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("admin"), // 'admin' | 'wali_kelas' | 'guru_mapel'
  teacherId: integer("teacher_id").references(() => teachers.id, {
    onDelete: "set null",
  }),
  assignedClassId: integer("assigned_class_id").references(
    () => schoolClasses.id,
    { onDelete: "set null" }
  ),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type SchoolSettings = typeof schoolSettings.$inferSelect;
export type Teacher = typeof teachers.$inferSelect;
export type SchoolClass = typeof schoolClasses.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Student = typeof students.$inferSelect;
export type AttendanceRecord = typeof attendanceRecords.$inferSelect;
export type StudentGrade = typeof studentGrades.$inferSelect;
export type GuidanceRecord = typeof guidanceRecords.$inferSelect;
export type User = typeof users.$inferSelect;

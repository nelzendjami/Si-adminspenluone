export type ActiveTab =
  | "beranda"
  | "scan-barcode"
  | "absensi-mapel"
  | "absensi-wali"
  | "mapel-nilai"
  | "bimbingan-wali"
  | "rekapan"
  | "kelas"
  | "siswa"
  | "guru-kepsek"
  | "admin-logo";

export interface NavigationOptions {
  classId?: number;
  barcodeOpts?: { mode: "mapel" | "wali"; subTab?: "scanner" | "cards" };
  subjectOpts?: {
    subTab?: "master" | "grades" | "matrix";
    subjectId?: number;
  };
  guidanceStudentId?: number;
}

export interface SessionUserData {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: "admin" | "wali_kelas" | "guru_mapel";
  teacherId: number | null;
  teacherNip: string | null;
  teacherSubject: string | null;
  assignedClassId: number | null;
  assignedClassName: string | null;
}

export interface SchoolSettingsData {
  id: number;
  schoolName: string;
  npsn: string;
  address: string;
  academicYear: string;
  semester: string;
  principalName: string;
  principalNip: string;
  email: string;
  phone: string;
  logoUrl: string;
}

export interface ClassItem {
  id: number;
  name: string;
  gradeLevel: number;
  room: string;
  academicYear: string;
  capacity: number;
  homeroomTeacherId: number | null;
  homeroomTeacherName: string | null;
  homeroomTeacherNip: string | null;
  studentCount: number;
}

export interface TeacherItem {
  id: number;
  name: string;
  nip: string;
  subject: string;
  employmentStatus: string;
  phone: string;
  isActive: boolean;
  homeroomClassId: number | null;
  homeroomClassName: string | null;
}

export interface SubjectItem {
  id: number;
  code: string;
  name: string;
  category: string;
  kkm: number;
  weeklyHours: number;
  teacherId: number | null;
  teacherName: string | null;
  teacherNip: string | null;
  gradedCount?: number;
  averageScore?: number;
  belowKkmCount?: number;
}

export interface StudentItem {
  id: number;
  nisn: string;
  nis: string;
  barcodeCode: string;
  name: string;
  gender: string;
  classId: number;
  className: string;
  birthPlace: string | null;
  birthDate: string | null;
  parentName: string | null;
  address: string | null;
  status: string;
}

export interface AttendanceRowItem {
  studentId: number;
  nisn: string;
  nis: string;
  barcodeCode: string;
  name: string;
  gender: string;
  status: "H" | "S" | "I" | "A";
  notes: string;
  isRecorded: boolean;
  recordedBy: string | null;
}

export interface GradeRowItem {
  studentId: number;
  nisn: string;
  nis: string;
  name: string;
  gender: string;
  assignmentScore: number;
  midtermScore: number;
  finalScore: number;
  totalScore: number;
  predicate: string;
  kkm: number;
  isPassing: boolean;
  teacherNotes: string;
  isSaved: boolean;
  updatedBy: string | null;
}

export interface MatrixStudentRow {
  studentId: number;
  nisn: string;
  nis: string;
  name: string;
  gender: string;
  scoresBySubject: Record<
    number,
    {
      totalScore: number | null;
      predicate: string | null;
      assignmentScore: number | null;
      midtermScore: number | null;
      finalScore: number | null;
      belowKkm: boolean;
    }
  >;
  averageScore: number;
  belowKkmCount: number;
  weakSubjects: string[];
}

export interface AnakWaliProfile {
  id: number;
  nisn: string;
  nis: string;
  name: string;
  gender: string;
  parentName: string;
  address: string;
  averageGrade: number;
  belowKkmCount: number;
  belowKkmSubjects: string[];
  attendanceRate: number;
  alpaCount: number;
  guidanceCount: number;
  detailedGrades: Array<{
    subjectId: number;
    subjectCode: string;
    subjectName: string;
    kkm: number;
    assignmentScore: number | null;
    midtermScore: number | null;
    finalScore: number | null;
    totalScore: number | null;
    predicate: string | null;
    isBelowKkm: boolean;
  }>;
}

export interface GuidanceRecordItem {
  id: number;
  studentId: number;
  studentName: string;
  studentNisn: string;
  classId: number;
  className: string;
  guruWaliId: number | null;
  guruWaliName: string;
  guruWaliNip: string;
  date: string;
  category: string;
  topic: string;
  notes: string;
  followUpPlan: string;
  parentInvolved: boolean;
  status: string;
  createdBy: string;
}

export interface ScannedLogEntry {
  logId: string;
  scannedAt: string;
  alreadyRecorded: boolean;
  attendanceType: "mapel" | "wali";
  subjectName: string;
  date: string;
  status: string;
  classPresentCount: number;
  classTotalStudents: number;
  student: {
    id: number;
    nisn: string;
    nis: string;
    barcodeCode: string;
    name: string;
    gender: string;
    classId: number;
    className: string;
  };
}

export interface RecapResponse {
  filters: {
    classId: string;
    type: string;
    subjectName: string;
    startDate: string;
    endDate: string;
  };
  summary: {
    totalEntries: number;
    hadir: number;
    sakit: number;
    izin: number;
    alpa: number;
    attendanceRate: number;
  };
  studentRecap: Array<{
    studentId: number;
    nisn: string;
    nis: string;
    name: string;
    gender: string;
    classId: number;
    className: string;
    hadir: number;
    sakit: number;
    izin: number;
    alpa: number;
    total: number;
    percentage: number;
  }>;
  classSummary: Array<{
    classId: number;
    className: string;
    homeroomTeacherName: string;
    homeroomTeacherNip: string;
    hadir: number;
    sakit: number;
    izin: number;
    alpa: number;
    total: number;
    percentage: number;
  }>;
  dailyTrend: Array<{
    date: string;
    hadir: number;
    sakit: number;
    izin: number;
    alpa: number;
    total: number;
    percentage: number;
  }>;
}

export interface ToastMessage {
  id: string;
  type: "success" | "error" | "info";
  title: string;
  description?: string;
}

"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ShieldCheck,
  Lock,
  UserCheck,
  ArrowLeft,
  Loader2,
  BookOpen,
  CheckCircle2,
  Eye,
  EyeOff,
} from "lucide-react";
import { SchoolSettingsData } from "@/types/school";
import {
  installAuthFetchInterceptor,
  setStoredSessionToken,
} from "@/lib/client-auth";

export default function LoginPage() {
  const router = useRouter();
  const [settings, setSettings] = useState<SchoolSettingsData | null>(null);
  const [identifier, setIdentifier] = useState("admin");
  const [password, setPassword] = useState("admin123");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    installAuthFetchInterceptor();
    fetch("/api/settings", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (d.settings) setSettings(d.settings);
      })
      .catch(() => {});
  }, []);

  async function handleSubmit(
    e: React.FormEvent,
    customId?: string,
    customPw?: string
  ) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: customId ?? identifier,
          password: customPw ?? password,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Login gagal.");
        setLoading(false);
        return;
      }
      if (data.token) {
        setStoredSessionToken(data.token);
        router.push(`/?_st=${encodeURIComponent(data.token)}`);
      } else {
        router.push("/");
      }
      router.refresh();
    } catch {
      setError("Gagal menghubungi server autentikasi.");
      setLoading(false);
    }
  }

  const demoAccounts = [
    {
      label: "Admin Pribadi Sekolah",
      sub: "Akses Penuh, Logo Manual & Backup",
      user: "admin",
      pass: "admin123",
      badge: "Admin Pribadi",
      badgeClass: "bg-blue-50 text-blue-700 border-blue-200",
    },
    {
      label: "Maria Rambu Kahi, S.Pd.",
      sub: "Guru Wali Khusus Kelas VII-A (1 Kelas)",
      user: "wali7a",
      pass: "guru123",
      badge: "Guru Wali VII-A",
      badgeClass: "bg-emerald-50 text-emerald-700 border-emerald-200",
    },
    {
      label: "Agustina Rambu Danga, S.Pd.",
      sub: "Guru Wali Khusus Kelas VIII-A (1 Kelas)",
      user: "wali8a",
      pass: "guru123",
      badge: "Guru Wali VIII-A",
      badgeClass: "bg-emerald-50 text-emerald-700 border-emerald-200",
    },
    {
      label: "Petrus Umbu Lado, S.Pd.",
      sub: "Guru Mata Pelajaran PJOK",
      user: "mapel",
      pass: "guru123",
      badge: "Guru Mapel",
      badgeClass: "bg-amber-50 text-amber-700 border-amber-200",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl w-full mx-auto">
        <div className="mb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-blue-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Kembali ke Dashboard Administrasi
          </Link>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Left Institutional Visual Column */}
          <div className="lg:col-span-5 relative bg-slate-900 text-white p-8 flex flex-col justify-between overflow-hidden">
            <img
              src="/images/campus-umalulu.jpg"
              alt="Kampus SMP Negeri 1 Umalulu"
              className="absolute inset-0 w-full h-full object-cover opacity-25"
            />
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl bg-white p-2 shadow-md flex items-center justify-center shrink-0">
                  <img
                    src={settings?.logoUrl || "/images/logo-smpn1-umalulu.png"}
                    alt="Logo Sekolah"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-200 border border-blue-400/30 mb-1">
                    NPSN {settings?.npsn || "50303812"}
                  </span>
                  <h1 className="text-xl font-bold tracking-tight text-white">
                    {settings?.schoolName || "SMP Negeri 1 Umalulu"}
                  </h1>
                </div>
              </div>

              <p className="text-sm text-slate-200 leading-relaxed mb-6">
                Portal resmi administrasi akademik, absensi scan barcode siswa,
                absensi mata pelajaran & Guru Wali, daftar nilai per mapel,
                bimbingan anak wali, serta pengelolaan identitas sekolah.
              </p>

              <div className="space-y-3 text-xs text-slate-200">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Scan Barcode & Kartu Barcode Siswa Otomatis</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Import Logo Sekolah Manual khusus Admin Pribadi</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Daftar Nilai Mapel & Bimbingan Anak Wali Terpadu</span>
                </div>
              </div>
            </div>

            <div className="relative z-10 mt-10 pt-5 border-t border-white/15 text-xs text-slate-300">
              <p className="font-semibold text-white">
                Kepala Sekolah:{" "}
                {settings?.principalName || "Drs. Umbu Maramba Meha, M.Pd."}
              </p>
              <p className="font-mono-code mt-0.5 text-slate-300">
                NIP. {settings?.principalNip || "19690817 199512 1 003"}
              </p>
            </div>
          </div>

          {/* Right Form Column */}
          <div className="lg:col-span-7 p-8 sm:p-10">
            <div className="flex items-center gap-2.5 mb-2">
              <ShieldCheck className="w-5 h-5 text-blue-700" />
              <span className="text-xs font-semibold uppercase tracking-wider text-blue-700">
                Autentikasi Pengguna Resmi
              </span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900">
              Masuk ke Sistem Administrasi
            </h2>
            <p className="text-sm text-slate-600 mt-1 mb-6">
              Gunakan akun Admin Pribadi, Guru Wali, atau Guru Mata Pelajaran
              yang telah terdaftar.
            </p>

            {error && (
              <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-sm text-rose-700 font-medium">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                  Username atau Email Sekolah
                </label>
                <div className="relative">
                  <UserCheck className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="admin atau admin@smpn1umalulu.sch.id"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Masukkan password akun"
                    className="w-full pl-10 pr-11 py-2.5 rounded-xl border border-slate-300 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 px-5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-semibold text-sm shadow-sm transition-all flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Memverifikasi Sesi...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    Masuk Sekarang
                  </>
                )}
              </button>
            </form>

            {/* Quick Role Access Cards */}
            <div className="mt-8 pt-6 border-t border-slate-200">
              <div className="flex items-center gap-2 mb-3">
                <BookOpen className="w-4 h-4 text-slate-500" />
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Akses Cepat Peran Awal Sekolah
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {demoAccounts.map((acc) => (
                  <button
                    key={acc.user}
                    type="button"
                    disabled={loading}
                    onClick={(e) => {
                      setIdentifier(acc.user);
                      setPassword(acc.pass);
                      handleSubmit(e, acc.user, acc.pass);
                    }}
                    className="text-left p-3.5 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 transition-all group cursor-pointer"
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span
                        className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border ${acc.badgeClass}`}
                      >
                        {acc.badge}
                      </span>
                      <span className="font-mono-code text-[11px] text-slate-500">
                        {acc.user}
                      </span>
                    </div>
                    <p className="text-sm font-semibold text-slate-900 group-hover:text-blue-700">
                      {acc.label}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">{acc.sub}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

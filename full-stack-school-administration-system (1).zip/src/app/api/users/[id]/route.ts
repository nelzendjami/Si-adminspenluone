import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser, hashPassword } from "@/lib/auth";
import { ensureDatabaseReady } from "@/lib/seed";

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const current = await getCurrentUser(request);
    if (!current || current.role !== "admin") {
      return NextResponse.json({ error: "Akses ditolak." }, { status: 401 });
    }

    const { id } = await context.params;
    const targetId = Number(id);
    const body = await request.json();

    const updateFields: Record<string, unknown> = {};
    if (body.fullName) updateFields.fullName = String(body.fullName).trim();
    if (body.username)
      updateFields.username = String(body.username).trim().toLowerCase();
    if (body.email)
      updateFields.email = String(body.email).trim().toLowerCase();
    if (body.role) updateFields.role = String(body.role);
    if (body.newPassword && String(body.newPassword).trim().length >= 6) {
      updateFields.passwordHash = await hashPassword(
        String(body.newPassword).trim()
      );
    }

    await db.update(users).set(updateFields).where(eq(users.id, targetId));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Update user error:", error);
    return NextResponse.json(
      { error: "Gagal memperbarui akun pengguna." },
      { status: 400 }
    );
  }
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const current = await getCurrentUser(request);
    if (!current || current.role !== "admin") {
      return NextResponse.json({ error: "Akses ditolak." }, { status: 401 });
    }

    const { id } = await context.params;
    const targetId = Number(id);

    if (targetId === current.id) {
      return NextResponse.json(
        { error: "Akun Admin yang sedang aktif digunakan tidak dapat dihapus." },
        { status: 400 }
      );
    }

    await db.delete(users).where(eq(users.id, targetId));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Delete user error:", error);
    return NextResponse.json(
      { error: "Gagal menghapus akun pengguna." },
      { status: 500 }
    );
  }
}

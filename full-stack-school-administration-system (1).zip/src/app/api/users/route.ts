import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, teachers, schoolClasses } from "@/db/schema";
import { asc, eq, or } from "drizzle-orm";
import { getCurrentUser, hashPassword } from "@/lib/auth";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const current = await getCurrentUser(request);
    if (!current || current.role !== "admin") {
      return NextResponse.json(
        { error: "Hanya Admin Pribadi yang dapat melihat daftar akun pengguna." },
        { status: 401 }
      );
    }

    const [allUsers, allTeachers, allClasses] = await Promise.all([
      db.select().from(users).orderBy(asc(users.role), asc(users.username)),
      db.select().from(teachers),
      db.select().from(schoolClasses),
    ]);

    const safeUsers = allUsers.map((u) => {
      const t = allTeachers.find((tr) => tr.id === u.teacherId);
      const waliClass = u.teacherId
        ? allClasses.find((c) => c.homeroomTeacherId === u.teacherId)
        : allClasses.find((c) => c.id === u.assignedClassId);
      return {
        id: u.id,
        username: u.username,
        email: u.email,
        fullName: u.fullName,
        role: u.role,
        teacherId: u.teacherId,
        teacherName: t?.name || null,
        teacherNip: t?.nip || null,
        assignedClassId: waliClass?.id || u.assignedClassId || null,
        assignedClassName: waliClass?.name || null,
      };
    });

    return NextResponse.json({ users: safeUsers });
  } catch (error) {
    console.error("Get users error:", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar akun pengguna." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const current = await getCurrentUser(request);
    if (!current || current.role !== "admin") {
      return NextResponse.json(
        { error: "Akses ditolak. Login sebagai Admin Pribadi." },
        { status: 401 }
      );
    }

    const body = await request.json();
    const username = String(body.username || "")
      .trim()
      .toLowerCase();
    const email = String(
      body.email || `${username}@smpn1umalulu.sch.id`
    )
      .trim()
      .toLowerCase();
    const password = String(body.password || "").trim();
    const role = ["admin", "wali_kelas", "guru_mapel"].includes(body.role)
      ? String(body.role)
      : "guru_mapel";
    const teacherId = body.teacherId ? Number(body.teacherId) : null;

    if (!username || password.length < 6) {
      return NextResponse.json(
        { error: "Username wajib diisi dan password minimal 6 karakter." },
        { status: 400 }
      );
    }

    const dup = await db
      .select()
      .from(users)
      .where(or(eq(users.username, username), eq(users.email, email)))
      .limit(1);
    if (dup.length > 0) {
      return NextResponse.json(
        { error: "Username atau email sudah digunakan akun lain." },
        { status: 400 }
      );
    }

    let fullName = String(body.fullName || "").trim();
    let assignedClassId: number | null = body.assignedClassId
      ? Number(body.assignedClassId)
      : null;

    if (teacherId) {
      const tRows = await db
        .select()
        .from(teachers)
        .where(eq(teachers.id, teacherId))
        .limit(1);
      if (tRows[0] && !fullName) {
        fullName = tRows[0].name;
      }
      const cRows = await db
        .select()
        .from(schoolClasses)
        .where(eq(schoolClasses.homeroomTeacherId, teacherId))
        .limit(1);
      if (cRows[0]) {
        assignedClassId = cRows[0].id;
      }
    }

    if (!fullName) fullName = username.toUpperCase();
    const passwordHash = await hashPassword(password);

    const [created] = await db
      .insert(users)
      .values({
        username,
        email,
        passwordHash,
        fullName,
        role,
        teacherId,
        assignedClassId: role === "wali_kelas" ? assignedClassId : null,
      })
      .returning();

    return NextResponse.json(
      {
        ok: true,
        user: {
          id: created.id,
          username: created.username,
          email: created.email,
          fullName: created.fullName,
          role: created.role,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Create user account error:", error);
    return NextResponse.json(
      { error: "Gagal membuat akun pengguna baru." },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { subjects, teachers, studentGrades } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureDatabaseReady();
    const [allSubjects, allTeachers, allGrades] = await Promise.all([
      db.select().from(subjects).orderBy(asc(subjects.name)),
      db.select().from(teachers),
      db.select().from(studentGrades),
    ]);

    const enriched = allSubjects.map((s) => {
      const t = allTeachers.find((tr) => tr.id === s.teacherId);
      const sGrades = allGrades.filter((g) => g.subjectId === s.id);
      const avgScore =
        sGrades.length > 0
          ? Math.round(
              sGrades.reduce((acc, item) => acc + item.totalScore, 0) /
                sGrades.length
            )
          : 0;
      const belowKkmCount = sGrades.filter(
        (g) => g.totalScore < s.kkm
      ).length;

      return {
        ...s,
        teacherName: t?.name || null,
        teacherNip: t?.nip || null,
        gradedCount: sGrades.length,
        averageScore: avgScore,
        belowKkmCount,
      };
    });

    return NextResponse.json({ subjects: enriched });
  } catch (error) {
    console.error("Get subjects error:", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar mata pelajaran." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const body = await request.json();
    const code = String(body.code || "").trim().toUpperCase();
    const name = String(body.name || "").trim();
    const category = String(body.category || "Umum").trim();
    const kkm = Math.max(0, Math.min(100, Number(body.kkm ?? 75)));
    const weeklyHours = Math.max(
      1,
      Math.min(20, Number(body.weeklyHours ?? 4))
    );
    const teacherId = body.teacherId ? Number(body.teacherId) : null;

    if (!code || !name) {
      return NextResponse.json(
        { error: "Kode dan Nama Mata Pelajaran wajib diisi." },
        { status: 400 }
      );
    }

    const dup = await db
      .select()
      .from(subjects)
      .where(eq(subjects.code, code))
      .limit(1);
    if (dup.length > 0) {
      return NextResponse.json(
        { error: `Kode mata pelajaran "${code}" sudah digunakan.` },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(subjects)
      .values({
        code,
        name,
        category,
        kkm,
        weeklyHours,
        teacherId,
      })
      .returning();

    return NextResponse.json({ ok: true, subject: created }, { status: 201 });
  } catch (error) {
    console.error("Create subject error:", error);
    return NextResponse.json(
      { error: "Gagal menambahkan mata pelajaran baru." },
      { status: 400 }
    );
  }
}

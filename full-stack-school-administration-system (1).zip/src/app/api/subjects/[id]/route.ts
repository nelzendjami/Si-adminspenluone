import { NextResponse } from "next/server";
import { db } from "@/db";
import { subjects } from "@/db/schema";
import { and, eq, ne } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export async function PUT(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const subjectId = Number(id);
    const body = await request.json();

    const code = String(body.code || "").trim().toUpperCase();
    const name = String(body.name || "").trim();
    const category = String(body.category || "Umum").trim();
    const kkm = Math.max(0, Math.min(100, Number(body.kkm ?? 75)));
    const weeklyHours = Math.max(
      1,
      Math.min(20, Number(body.weeklyHours ?? 4))
    );
    const teacherId = body.teacherId ? Number(body.teacherId) : null;

    if (!code || !name) {
      return NextResponse.json(
        { error: "Kode dan Nama Mata Pelajaran wajib diisi." },
        { status: 400 }
      );
    }

    const dup = await db
      .select()
      .from(subjects)
      .where(and(eq(subjects.code, code), ne(subjects.id, subjectId)))
      .limit(1);
    if (dup.length > 0) {
      return NextResponse.json(
        { error: `Kode mata pelajaran "${code}" sudah digunakan mapel lain.` },
        { status: 400 }
      );
    }

    const [updated] = await db
      .update(subjects)
      .set({
        code,
        name,
        category,
        kkm,
        weeklyHours,
        teacherId,
      })
      .where(eq(subjects.id, subjectId))
      .returning();

    return NextResponse.json({ ok: true, subject: updated });
  } catch (error) {
    console.error("Update subject error:", error);
    return NextResponse.json(
      { error: "Gagal memperbarui data mata pelajaran." },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const subjectId = Number(id);

    await db.delete(subjects).where(eq(subjects.id, subjectId));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Delete subject error:", error);
    return NextResponse.json(
      { error: "Gagal menghapus mata pelajaran." },
      { status: 500 }
    );
  }
}

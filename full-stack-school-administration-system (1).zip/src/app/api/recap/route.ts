import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  attendanceRecords,
  students,
  schoolClasses,
  teachers,
} from "@/db/schema";
import { and, asc, eq, gte, lte, SQL } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const { searchParams } = new URL(request.url);

    const classIdParam = searchParams.get("classId") || "all";
    const typeParam = searchParams.get("type") || "all"; // 'all' | 'wali' | 'mapel'
    const subjectParam = searchParams.get("subjectName") || "all";

    const today = new Date();
    const defaultStart = new Date();
    defaultStart.setDate(today.getDate() - 30);

    const startDate =
      searchParams.get("startDate") || defaultStart.toISOString().slice(0, 10);
    const endDate =
      searchParams.get("endDate") || today.toISOString().slice(0, 10);

    const conditions: SQL[] = [
      gte(attendanceRecords.date, startDate),
      lte(attendanceRecords.date, endDate),
    ];

    if (classIdParam !== "all") {
      conditions.push(eq(attendanceRecords.classId, Number(classIdParam)));
    }
    if (typeParam === "wali" || typeParam === "mapel") {
      conditions.push(eq(attendanceRecords.attendanceType, typeParam));
    }
    if (typeParam === "mapel" && subjectParam !== "all") {
      conditions.push(eq(attendanceRecords.subjectName, subjectParam));
    }

    const [allClasses, allTeachers, filteredStudents, records] =
      await Promise.all([
        db
          .select()
          .from(schoolClasses)
          .orderBy(asc(schoolClasses.gradeLevel), asc(schoolClasses.name)),
        db.select().from(teachers),
        classIdParam !== "all"
          ? db
              .select()
              .from(students)
              .where(eq(students.classId, Number(classIdParam)))
              .orderBy(asc(students.name))
          : db.select().from(students).orderBy(asc(students.name)),
        db
          .select()
          .from(attendanceRecords)
          .where(and(...conditions)),
      ]);

    const classMap = new Map(allClasses.map((c) => [c.id, c]));

    // Per-student aggregation
    const studentRecap = filteredStudents.map((stu) => {
      const stuRecords = records.filter((r) => r.studentId === stu.id);
      const hadir = stuRecords.filter((r) => r.status === "H").length;
      const sakit = stuRecords.filter((r) => r.status === "S").length;
      const izin = stuRecords.filter((r) => r.status === "I").length;
      const alpa = stuRecords.filter((r) => r.status === "A").length;
      const total = stuRecords.length;
      const percentage = total > 0 ? Math.round((hadir / total) * 100) : 100;
      const cls = classMap.get(stu.classId);

      return {
        studentId: stu.id,
        nisn: stu.nisn,
        nis: stu.nis,
        name: stu.name,
        gender: stu.gender,
        classId: stu.classId,
        className: cls?.name || "-",
        hadir,
        sakit,
        izin,
        alpa,
        total,
        percentage,
      };
    });

    // Per-class summary
    const classSummary = allClasses.map((cls) => {
      const clsRecords = records.filter((r) => r.classId === cls.id);
      const hadir = clsRecords.filter((r) => r.status === "H").length;
      const sakit = clsRecords.filter((r) => r.status === "S").length;
      const izin = clsRecords.filter((r) => r.status === "I").length;
      const alpa = clsRecords.filter((r) => r.status === "A").length;
      const total = clsRecords.length;
      const percentage = total > 0 ? Math.round((hadir / total) * 100) : 100;
      const wali = allTeachers.find((t) => t.id === cls.homeroomTeacherId);

      return {
        classId: cls.id,
        className: cls.name,
        homeroomTeacherName: wali?.name || "Belum ditentukan",
        homeroomTeacherNip: wali?.nip || "-",
        hadir,
        sakit,
        izin,
        alpa,
        total,
        percentage,
      };
    });

    // Daily trend summary
    const uniqueDates = Array.from(new Set(records.map((r) => r.date))).sort();
    const dailyTrend = uniqueDates.map((dt) => {
      const dRecs = records.filter((r) => r.date === dt);
      const hadir = dRecs.filter((r) => r.status === "H").length;
      const sakit = dRecs.filter((r) => r.status === "S").length;
      const izin = dRecs.filter((r) => r.status === "I").length;
      const alpa = dRecs.filter((r) => r.status === "A").length;
      const total = dRecs.length;
      return {
        date: dt,
        hadir,
        sakit,
        izin,
        alpa,
        total,
        percentage: total > 0 ? Math.round((hadir / total) * 100) : 0,
      };
    });

    const totalHadir = records.filter((r) => r.status === "H").length;
    const totalSakit = records.filter((r) => r.status === "S").length;
    const totalIzin = records.filter((r) => r.status === "I").length;
    const totalAlpa = records.filter((r) => r.status === "A").length;
    const totalEntries = records.length;

    return NextResponse.json({
      filters: {
        classId: classIdParam,
        type: typeParam,
        subjectName: subjectParam,
        startDate,
        endDate,
      },
      summary: {
        totalEntries,
        hadir: totalHadir,
        sakit: totalSakit,
        izin: totalIzin,
        alpa: totalAlpa,
        attendanceRate:
          totalEntries > 0 ? Math.round((totalHadir / totalEntries) * 100) : 100,
      },
      studentRecap,
      classSummary,
      dailyTrend,
    });
  } catch (error) {
    console.error("Get recap error:", error);
    return NextResponse.json(
      { error: "Gagal memuat rekapan absensi." },
      { status: 500 }
    );
  }
}

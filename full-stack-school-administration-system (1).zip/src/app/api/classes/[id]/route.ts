import { NextResponse } from "next/server";
import { db } from "@/db";
import { schoolClasses, users } from "@/db/schema";
import { and, eq, ne } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export async function PUT(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const classId = Number(id);
    const body = await request.json();

    const name = String(body.name || "").trim().toUpperCase();
    const gradeLevel = Number(body.gradeLevel || 7);
    const room = String(body.room || "R-01").trim();
    const academicYear = String(body.academicYear || "2025/2026").trim();
    const capacity = Number(body.capacity || 32);
    const homeroomTeacherId = body.homeroomTeacherId
      ? Number(body.homeroomTeacherId)
      : null;

    if (!name) {
      return NextResponse.json(
        { error: "Nama kelas wajib diisi." },
        { status: 400 }
      );
    }

    const duplicate = await db
      .select()
      .from(schoolClasses)
      .where(and(eq(schoolClasses.name, name), ne(schoolClasses.id, classId)))
      .limit(1);
    if (duplicate.length > 0) {
      return NextResponse.json(
        { error: `Nama kelas ${name} sudah digunakan oleh kelas lain.` },
        { status: 400 }
      );
    }

    // Enforce 1 Guru Wali = 1 Kelas Saja
    if (homeroomTeacherId) {
      const existingWaliClass = await db
        .select()
        .from(schoolClasses)
        .where(
          and(
            eq(schoolClasses.homeroomTeacherId, homeroomTeacherId),
            ne(schoolClasses.id, classId)
          )
        )
        .limit(1);

      if (existingWaliClass.length > 0) {
        if (body.transferWali) {
          await db
            .update(schoolClasses)
            .set({ homeroomTeacherId: null })
            .where(eq(schoolClasses.id, existingWaliClass[0].id));
        } else {
          return NextResponse.json(
            {
              error: `Guru Wali hanya untuk satu kelas saja! Guru ini sudah bertugas di Kelas ${existingWaliClass[0].name}.`,
            },
            { status: 400 }
          );
        }
      }
    }

    const [updated] = await db
      .update(schoolClasses)
      .set({
        name,
        gradeLevel,
        room,
        academicYear,
        capacity,
        homeroomTeacherId,
      })
      .where(eq(schoolClasses.id, classId))
      .returning();

    if (homeroomTeacherId) {
      await db
        .update(users)
        .set({ assignedClassId: updated.id })
        .where(eq(users.teacherId, homeroomTeacherId));
    }

    return NextResponse.json({ ok: true, schoolClass: updated });
  } catch (error) {
    console.error("Update class error:", error);
    return NextResponse.json(
      { error: "Gagal memperbarui data kelas." },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const classId = Number(id);

    await db.delete(schoolClasses).where(eq(schoolClasses.id, classId));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Delete class error:", error);
    return NextResponse.json(
      { error: "Gagal menghapus kelas." },
      { status: 500 }
    );
  }
}

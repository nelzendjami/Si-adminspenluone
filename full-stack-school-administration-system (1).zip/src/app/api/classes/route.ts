import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  schoolClasses,
  teachers,
  students,
  users,
} from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureDatabaseReady();
    const allClasses = await db
      .select()
      .from(schoolClasses)
      .orderBy(asc(schoolClasses.gradeLevel), asc(schoolClasses.name));
    const allTeachers = await db.select().from(teachers);
    const allStudents = await db.select().from(students);

    const enriched = allClasses.map((cls) => {
      const wali = allTeachers.find((t) => t.id === cls.homeroomTeacherId);
      const count = allStudents.filter((s) => s.classId === cls.id).length;
      return {
        ...cls,
        homeroomTeacherName: wali?.name || null,
        homeroomTeacherNip: wali?.nip || null,
        studentCount: count,
      };
    });

    return NextResponse.json({ classes: enriched });
  } catch (error) {
    console.error("Get classes error:", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar kelas." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const body = await request.json();
    const name = String(body.name || "").trim().toUpperCase();
    const gradeLevel = Number(body.gradeLevel || 7);
    const room = String(body.room || "R-01").trim();
    const academicYear = String(body.academicYear || "2025/2026").trim();
    const capacity = Number(body.capacity || 32);
    const homeroomTeacherId = body.homeroomTeacherId
      ? Number(body.homeroomTeacherId)
      : null;

    if (!name) {
      return NextResponse.json(
        { error: "Nama kelas wajib diisi (contoh: VII-C)." },
        { status: 400 }
      );
    }

    const duplicate = await db
      .select()
      .from(schoolClasses)
      .where(eq(schoolClasses.name, name))
      .limit(1);
    if (duplicate.length > 0) {
      return NextResponse.json(
        { error: `Kelas ${name} sudah terdaftar.` },
        { status: 400 }
      );
    }

    // Strict 1 Guru Wali = 1 Kelas Saja enforcement
    if (homeroomTeacherId) {
      const existingWaliClass = await db
        .select()
        .from(schoolClasses)
        .where(eq(schoolClasses.homeroomTeacherId, homeroomTeacherId))
        .limit(1);

      if (existingWaliClass.length > 0) {
        if (body.transferWali) {
          await db
            .update(schoolClasses)
            .set({ homeroomTeacherId: null })
            .where(eq(schoolClasses.id, existingWaliClass[0].id));
        } else {
          return NextResponse.json(
            {
              error: `Guru Wali hanya boleh memegang 1 kelas saja! Guru tersebut saat ini sudah bertugas sebagai Guru Wali pada Kelas ${existingWaliClass[0].name}. Centang opsi pindah tugas atau pilih guru lain.`,
            },
            { status: 400 }
          );
        }
      }
    }

    const [created] = await db
      .insert(schoolClasses)
      .values({
        name,
        gradeLevel,
        room,
        academicYear,
        capacity,
        homeroomTeacherId,
      })
      .returning();

    if (homeroomTeacherId) {
      await db
        .update(users)
        .set({ assignedClassId: created.id })
        .where(eq(users.teacherId, homeroomTeacherId));
    }

    return NextResponse.json({ ok: true, schoolClass: created }, { status: 201 });
  } catch (error) {
    console.error("Create class error:", error);
    return NextResponse.json(
      { error: "Gagal menambahkan kelas baru." },
      { status: 500 }
    );
  }
}

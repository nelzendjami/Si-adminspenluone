import { NextResponse } from "next/server";
import * as XLSX from "xlsx";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const format = (searchParams.get("format") || "xlsx").toLowerCase();

  const templateRows = [
    {
      NISN: "0129510001",
      NIS: "2601",
      Nama_Lengkap: "Yohanes Umbu Hina",
      JK: "L",
      Kelas: "VII-A",
      Tempat_Lahir: "Umalulu",
      Tanggal_Lahir: "2013-03-14",
      Nama_Orang_Tua: "Marthen Hina",
      Alamat: "Desa Watupuda, Kec. Umalulu",
    },
    {
      NISN: "0129510002",
      NIS: "2602",
      Nama_Lengkap: "Maria Rambu Ngana",
      JK: "P",
      Kelas: "VII-A",
      Tempat_Lahir: "Melolo",
      Tanggal_Lahir: "2013-07-22",
      Nama_Orang_Tua: "Kornelis Ngana",
      Alamat: "Kel. Lumbukore, Kec. Umalulu",
    },
    {
      NISN: "0129510003",
      NIS: "2603",
      Nama_Lengkap: "Kristian Ndawa Meha",
      JK: "L",
      Kelas: "VIII-A",
      Tempat_Lahir: "Umalulu",
      Tanggal_Lahir: "2012-11-05",
      Nama_Orang_Tua: "Paulus Meha",
      Alamat: "Desa Matawai Atu, Kec. Umalulu",
    },
  ];

  if (format === "csv") {
    const headers = Object.keys(templateRows[0]).join(",");
    const lines = templateRows.map((r) =>
      Object.values(r)
        .map((v) => `"${String(v).replace(/"/g, '""')}"`)
        .join(",")
    );
    const csvContent = "\uFEFF" + [headers, ...lines].join("\r\n");

    return new NextResponse(csvContent, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition":
          'attachment; filename="Template_Import_Siswa_SMPN1_Umalulu.csv"',
      },
    });
  }

  const wb = XLSX.utils.book_new();
  const wsData = XLSX.utils.json_to_sheet(templateRows);
  wsData["!cols"] = [
    { wch: 15 },
    { wch: 10 },
    { wch: 28 },
    { wch: 6 },
    { wch: 10 },
    { wch: 16 },
    { wch: 15 },
    { wch: 24 },
    { wch: 32 },
  ];

  const guideRows = [
    {
      Kolom: "NISN",
      Wajib: "Ya",
      Keterangan: "Nomor Induk Siswa Nasional (unik per siswa, contoh: 0129510001)",
    },
    {
      Kolom: "NIS",
      Wajib: "Opsional",
      Keterangan: "Nomor Induk Sekolah (contoh: 2601)",
    },
    {
      Kolom: "Nama_Lengkap",
      Wajib: "Ya",
      Keterangan: "Nama lengkap peserta didik sesuai akta/ijazah",
    },
    {
      Kolom: "JK",
      Wajib: "Ya",
      Keterangan: "Isi L untuk Laki-laki atau P untuk Perempuan",
    },
    {
      Kolom: "Kelas",
      Wajib: "Ya",
      Keterangan: "Nama kelas tujuan (contoh: VII-A, VII-B, VIII-A, VIII-B, IX-A, IX-B)",
    },
    {
      Kolom: "Tempat_Lahir",
      Wajib: "Opsional",
      Keterangan: "Kota/Desa kelahiran (contoh: Umalulu)",
    },
    {
      Kolom: "Tanggal_Lahir",
      Wajib: "Opsional",
      Keterangan: "Format YYYY-MM-DD (contoh: 2013-03-14)",
    },
    {
      Kolom: "Nama_Orang_Tua",
      Wajib: "Opsional",
      Keterangan: "Nama ayah/ibu/wali murid",
    },
    {
      Kolom: "Alamat",
      Wajib: "Opsional",
      Keterangan: "Alamat tempat tinggal di Kecamatan Umalulu / sekitarnya",
    },
  ];
  const wsGuide = XLSX.utils.json_to_sheet(guideRows);
  wsGuide["!cols"] = [{ wch: 18 }, { wch: 10 }, { wch: 62 }];

  XLSX.utils.book_append_sheet(wb, wsData, "Data_Siswa");
  XLSX.utils.book_append_sheet(wb, wsGuide, "Petunjuk_Pengisian");

  const buffer = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

  return new NextResponse(buffer, {
    status: 200,
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition":
        'attachment; filename="Template_Import_Siswa_SMPN1_Umalulu.xlsx"',
    },
  });
}

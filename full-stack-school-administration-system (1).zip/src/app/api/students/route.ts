import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  students,
  schoolClasses,
  generateStudentBarcode,
} from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const { searchParams } = new URL(request.url);
    const classIdParam = searchParams.get("classId");

    const allClasses = await db.select().from(schoolClasses);
    const allStudents =
      classIdParam && classIdParam !== "all"
        ? await db
            .select()
            .from(students)
            .where(eq(students.classId, Number(classIdParam)))
            .orderBy(asc(students.name))
        : await db.select().from(students).orderBy(asc(students.name));

    const enriched = allStudents.map((s) => ({
      ...s,
      className: allClasses.find((c) => c.id === s.classId)?.name || "-",
    }));

    return NextResponse.json({ students: enriched });
  } catch (error) {
    console.error("Get students error:", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar siswa." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const body = await request.json();
    const nisn = String(body.nisn || "").trim();
    const nis = String(body.nis || "").trim();
    const name = String(body.name || "").trim();
    const gender = String(body.gender || "L").toUpperCase() === "P" ? "P" : "L";
    const classId = Number(body.classId);
    const birthPlace = String(body.birthPlace || "Umalulu").trim();
    const birthDate = String(body.birthDate || "").trim();
    const parentName = String(body.parentName || "").trim();
    const address = String(body.address || "Kec. Umalulu").trim();

    if (!nisn || !name || !classId) {
      return NextResponse.json(
        { error: "NISN, Nama Lengkap, dan Kelas wajib diisi." },
        { status: 400 }
      );
    }

    const existing = await db
      .select()
      .from(students)
      .where(eq(students.nisn, nisn))
      .limit(1);
    if (existing.length > 0) {
      return NextResponse.json(
        { error: `Siswa dengan NISN ${nisn} sudah terdaftar.` },
        { status: 400 }
      );
    }

    const barcodeCode = body.barcodeCode
      ? String(body.barcodeCode).trim().toUpperCase()
      : generateStudentBarcode(nisn);

    const [created] = await db
      .insert(students)
      .values({
        nisn,
        nis,
        barcodeCode,
        name,
        gender,
        classId,
        birthPlace,
        birthDate,
        parentName,
        address,
        status: "Aktif",
      })
      .returning();

    const cls = await db
      .select()
      .from(schoolClasses)
      .where(eq(schoolClasses.id, classId))
      .limit(1);

    return NextResponse.json(
      {
        ok: true,
        student: { ...created, className: cls[0]?.name || "-" },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Create student error:", error);
    return NextResponse.json(
      { error: "Gagal menambahkan data siswa." },
      { status: 500 }
    );
  }
}

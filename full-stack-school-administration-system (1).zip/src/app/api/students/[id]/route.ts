import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  students,
  schoolClasses,
  generateStudentBarcode,
} from "@/db/schema";
import { and, eq, ne } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export async function PUT(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const studentId = Number(id);
    const body = await request.json();

    // Support quick barcode regeneration action
    if (body.regenerateBarcode) {
      const existingRows = await db
        .select()
        .from(students)
        .where(eq(students.id, studentId))
        .limit(1);
      if (!existingRows[0]) {
        return NextResponse.json(
          { error: "Siswa tidak ditemukan." },
          { status: 404 }
        );
      }
      const stu = existingRows[0];
      const suffix = body.withRandomSuffix
        ? `-${Math.floor(10 + Math.random() * 89)}`
        : "";
      const newCode = `${generateStudentBarcode(stu.nisn)}${suffix}`;

      const [updated] = await db
        .update(students)
        .set({ barcodeCode: newCode })
        .where(eq(students.id, studentId))
        .returning();

      const cls = await db
        .select()
        .from(schoolClasses)
        .where(eq(schoolClasses.id, updated.classId))
        .limit(1);

      return NextResponse.json({
        ok: true,
        student: { ...updated, className: cls[0]?.name || "-" },
      });
    }

    const nisn = String(body.nisn || "").trim();
    const nis = String(body.nis || "").trim();
    const name = String(body.name || "").trim();
    const gender = String(body.gender || "L").toUpperCase() === "P" ? "P" : "L";
    const classId = Number(body.classId);
    const birthPlace = String(body.birthPlace || "Umalulu").trim();
    const birthDate = String(body.birthDate || "").trim();
    const parentName = String(body.parentName || "").trim();
    const address = String(body.address || "Kec. Umalulu").trim();
    const status = String(body.status || "Aktif").trim();

    if (!nisn || !name || !classId) {
      return NextResponse.json(
        { error: "NISN, Nama Lengkap, dan Kelas wajib diisi." },
        { status: 400 }
      );
    }

    const dup = await db
      .select()
      .from(students)
      .where(and(eq(students.nisn, nisn), ne(students.id, studentId)))
      .limit(1);
    if (dup.length > 0) {
      return NextResponse.json(
        { error: `NISN ${nisn} sudah digunakan siswa lain.` },
        { status: 400 }
      );
    }

    const barcodeCode = body.barcodeCode
      ? String(body.barcodeCode).trim().toUpperCase()
      : generateStudentBarcode(nisn);

    const [updated] = await db
      .update(students)
      .set({
        nisn,
        nis,
        barcodeCode,
        name,
        gender,
        classId,
        birthPlace,
        birthDate,
        parentName,
        address,
        status,
      })
      .where(eq(students.id, studentId))
      .returning();

    const cls = await db
      .select()
      .from(schoolClasses)
      .where(eq(schoolClasses.id, classId))
      .limit(1);

    return NextResponse.json({
      ok: true,
      student: { ...updated, className: cls[0]?.name || "-" },
    });
  } catch (error) {
    console.error("Update student error:", error);
    return NextResponse.json(
      { error: "Gagal memperbarui data siswa." },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const studentId = Number(id);

    await db.delete(students).where(eq(students.id, studentId));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Delete student error:", error);
    return NextResponse.json(
      { error: "Gagal menghapus data siswa." },
      { status: 500 }
    );
  }
}

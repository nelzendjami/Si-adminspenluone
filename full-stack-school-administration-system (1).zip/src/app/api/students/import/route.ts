import { NextResponse } from "next/server";
import * as XLSX from "xlsx";
import { db } from "@/db";
import {
  students,
  schoolClasses,
  generateStudentBarcode,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

function normalizeKey(k: string): string {
  return k.toLowerCase().replace(/[^a-z0-9]/g, "");
}

function getField(row: Record<string, unknown>, candidates: string[]): string {
  const entries = Object.entries(row);
  for (const cand of candidates) {
    const match = entries.find(([k]) => normalizeKey(k) === cand);
    if (match && match[1] !== undefined && match[1] !== null) {
      return String(match[1]).trim();
    }
  }
  return "";
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const contentType = request.headers.get("content-type") || "";
    let rawRows: Record<string, unknown>[] = [];
    let fallbackClassId: number | null = null;

    if (contentType.includes("multipart/form-data")) {
      const formData = await request.formData();
      const file = formData.get("file");
      const classIdVal = formData.get("defaultClassId");
      if (classIdVal) fallbackClassId = Number(classIdVal);

      if (!file || !(file instanceof File)) {
        return NextResponse.json(
          { error: "File template Excel/CSV belum dipilih." },
          { status: 400 }
        );
      }

      const arrayBuffer = await file.arrayBuffer();
      if (file.name.toLowerCase().endsWith(".csv")) {
        const text = Buffer.from(arrayBuffer).toString("utf-8");
        const wb = XLSX.read(text, { type: "string" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        rawRows = XLSX.utils.sheet_to_json(ws, { defval: "" });
      } else {
        const wb = XLSX.read(Buffer.from(arrayBuffer), { type: "buffer" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        rawRows = XLSX.utils.sheet_to_json(ws, { defval: "" });
      }
    } else {
      const body = await request.json();
      rawRows = Array.isArray(body.rows) ? body.rows : [];
      if (body.defaultClassId) fallbackClassId = Number(body.defaultClassId);
    }

    if (rawRows.length === 0) {
      return NextResponse.json(
        { error: "Tidak ada baris data siswa ditemukan di dalam file." },
        { status: 400 }
      );
    }

    let allClasses = await db.select().from(schoolClasses);
    if (!fallbackClassId && allClasses[0]) {
      fallbackClassId = allClasses[0].id;
    }

    let importedCount = 0;
    let updatedCount = 0;

    for (const row of rawRows) {
      const nisn = getField(row, ["nisn", "nomorinduksiswanasional"]);
      const nis = getField(row, ["nis", "noinduk"]);
      const name = getField(row, [
        "namalengkap",
        "nama",
        "namasiswa",
        "pesertadidik",
      ]);
      const genderRaw = getField(row, [
        "jk",
        "jeniskelamin",
        "gender",
        "lp",
      ]).toUpperCase();
      const classText = getField(row, [
        "kelas",
        "rombel",
        "namakelas",
      ]).toUpperCase();
      const birthPlace =
        getField(row, ["tempatlahir", "tmplahir"]) || "Umalulu";
      const birthDate = getField(row, ["tanggallahir", "tgllahir"]);
      const parentName = getField(row, [
        "namaorangtua",
        "orangtua",
        "wali",
        "namawali",
      ]);
      const address =
        getField(row, ["alamat", "alamatrumah"]) || "Kec. Umalulu";

      if (!nisn || !name) continue;

      const gender =
        genderRaw.startsWith("P") || genderRaw.startsWith("W") ? "P" : "L";

      let targetClassId = fallbackClassId!;
      if (classText) {
        let matched = allClasses.find(
          (c) => c.name.toUpperCase() === classText
        );
        if (!matched) {
          const gradeGuess =
            classText.startsWith("IX") || classText.startsWith("9")
              ? 9
              : classText.startsWith("VIII") || classText.startsWith("8")
              ? 8
              : 7;
          const [createdCls] = await db
            .insert(schoolClasses)
            .values({
              name: classText,
              gradeLevel: gradeGuess,
              room: `R-${classText}`,
              academicYear: "2025/2026",
              capacity: 32,
            })
            .returning();
          allClasses = [...allClasses, createdCls];
          matched = createdCls;
        }
        targetClassId = matched.id;
      }

      const existing = await db
        .select()
        .from(students)
        .where(eq(students.nisn, nisn))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(students)
          .set({
            nis: nis || existing[0].nis,
            barcodeCode: existing[0].barcodeCode || generateStudentBarcode(nisn),
            name,
            gender,
            classId: targetClassId,
            birthPlace,
            birthDate,
            parentName,
            address,
          })
          .where(eq(students.id, existing[0].id));
        updatedCount++;
      } else {
        await db.insert(students).values({
          nisn,
          nis,
          barcodeCode: generateStudentBarcode(nisn),
          name,
          gender,
          classId: targetClassId,
          birthPlace,
          birthDate,
          parentName,
          address,
          status: "Aktif",
        });
        importedCount++;
      }
    }

    if (importedCount === 0 && updatedCount === 0) {
      return NextResponse.json(
        {
          error:
            "Format kolom belum sesuai template. Pastikan kolom NISN dan Nama_Lengkap terisi.",
        },
        { status: 400 }
      );
    }

    return NextResponse.json({
      ok: true,
      importedCount,
      updatedCount,
      totalProcessed: importedCount + updatedCount,
    });
  } catch (error) {
    console.error("Import students error:", error);
    return NextResponse.json(
      {
        error:
          "Gagal mengimpor file siswa. Pastikan format .xlsx atau .csv valid.",
      },
      { status: 500 }
    );
  }
}

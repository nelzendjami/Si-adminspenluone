import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  attendanceRecords,
  students,
  schoolClasses,
  teachers,
} from "@/db/schema";
import { and, asc, eq, sql } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const { searchParams } = new URL(request.url);

    const type = searchParams.get("type") === "wali" ? "wali" : "mapel";
    let classId = Number(searchParams.get("classId") || 0);
    const date =
      searchParams.get("date") || new Date().toISOString().slice(0, 10);
    const subjectName =
      type === "wali"
        ? "Guru Wali"
        : String(searchParams.get("subjectName") || "Matematika");

    // Enforce strict 1-class rule when logged in as Guru Wali
    if (type === "wali" && user?.role === "wali_kelas" && user.assignedClassId) {
      classId = user.assignedClassId;
    }

    if (!classId) {
      const firstCls = await db
        .select()
        .from(schoolClasses)
        .orderBy(asc(schoolClasses.gradeLevel), asc(schoolClasses.name))
        .limit(1);
      if (!firstCls[0]) {
        return NextResponse.json({ rows: [], classInfo: null });
      }
      classId = firstCls[0].id;
    }

    const [classRows, classStudents, existingAttendance, allTeachers] =
      await Promise.all([
        db
          .select()
          .from(schoolClasses)
          .where(eq(schoolClasses.id, classId))
          .limit(1),
        db
          .select()
          .from(students)
          .where(eq(students.classId, classId))
          .orderBy(asc(students.name)),
        db
          .select()
          .from(attendanceRecords)
          .where(
            and(
              eq(attendanceRecords.classId, classId),
              eq(attendanceRecords.date, date),
              eq(attendanceRecords.attendanceType, type),
              eq(attendanceRecords.subjectName, subjectName)
            )
          ),
        db.select().from(teachers),
      ]);

    const cls = classRows[0] || null;
    const wali = cls
      ? allTeachers.find((t) => t.id === cls.homeroomTeacherId)
      : null;

    const rows = classStudents.map((stu) => {
      const rec = existingAttendance.find((r) => r.studentId === stu.id);
      return {
        studentId: stu.id,
        nisn: stu.nisn,
        nis: stu.nis,
        barcodeCode: stu.barcodeCode,
        name: stu.name,
        gender: stu.gender,
        status: rec?.status || "H",
        notes: rec?.notes || "",
        isRecorded: Boolean(rec),
        recordedBy: rec?.recordedBy || null,
      };
    });

    return NextResponse.json({
      classInfo: cls
        ? {
            ...cls,
            homeroomTeacherName: wali?.name || null,
            homeroomTeacherNip: wali?.nip || null,
          }
        : null,
      date,
      type,
      subjectName,
      rows,
    });
  } catch (error) {
    console.error("Get attendance error:", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar absensi kelas." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const body = await request.json();

    const attendanceType = body.attendanceType === "wali" ? "wali" : "mapel";
    const classId = Number(body.classId);
    const date = String(body.date || new Date().toISOString().slice(0, 10));
    const subjectName =
      attendanceType === "wali"
        ? "Guru Wali"
        : String(body.subjectName || "Matematika").trim();
    const teacherId = body.teacherId ? Number(body.teacherId) : null;

    // Enforce single-class restriction if signed in as Guru Wali
    if (
      attendanceType === "wali" &&
      user?.role === "wali_kelas" &&
      user.assignedClassId &&
      classId !== user.assignedClassId
    ) {
      return NextResponse.json(
        {
          error: `Akun Guru Wali Anda terkunci khusus untuk Kelas ${user.assignedClassName} (1 kelas saja).`,
        },
        { status: 403 }
      );
    }

    const recorderName =
      user?.fullName ||
      String(body.recordedBy || "") ||
      (attendanceType === "wali" ? "Guru Wali" : "Guru Mata Pelajaran");

    const entries: Array<{ studentId: number; status: string; notes: string }> =
      body.mode === "single"
        ? [
            {
              studentId: Number(body.studentId),
              status: String(body.status || "H"),
              notes: String(body.notes || ""),
            },
          ]
        : Array.isArray(body.entries)
        ? body.entries.map(
            (e: { studentId: number; status?: string; notes?: string }) => ({
              studentId: Number(e.studentId),
              status: String(e.status || "H"),
              notes: String(e.notes || ""),
            })
          )
        : [];

    if (!classId || entries.length === 0) {
      return NextResponse.json(
        { error: "Data absensi kosong atau kelas belum dipilih." },
        { status: 400 }
      );
    }

    for (const item of entries) {
      const validStatus = ["H", "S", "I", "A"].includes(item.status)
        ? item.status
        : "H";

      await db
        .insert(attendanceRecords)
        .values({
          studentId: item.studentId,
          classId,
          attendanceType,
          subjectName,
          teacherId,
          date,
          status: validStatus,
          notes: item.notes,
          recordedBy: recorderName,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: [
            attendanceRecords.studentId,
            attendanceRecords.date,
            attendanceRecords.attendanceType,
            attendanceRecords.subjectName,
          ],
          set: {
            classId,
            teacherId,
            status: validStatus,
            notes: item.notes,
            recordedBy: recorderName,
            updatedAt: new Date(),
          },
        });
    }

    const countRes = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(attendanceRecords)
      .where(
        and(
          eq(attendanceRecords.classId, classId),
          eq(attendanceRecords.date, date),
          eq(attendanceRecords.attendanceType, attendanceType),
          eq(attendanceRecords.subjectName, subjectName)
        )
      );

    return NextResponse.json({
      ok: true,
      savedCount: entries.length,
      totalRecordedInSession: countRes[0]?.total || entries.length,
    });
  } catch (error) {
    console.error("Save attendance error:", error);
    return NextResponse.json(
      { error: "Gagal menyimpan data kehadiran ke database." },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  attendanceRecords,
  students,
  schoolClasses,
  teachers,
} from "@/db/schema";
import { and, eq, or, sql } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const body = await request.json();

    const rawCode = String(body.code || "")
      .trim()
      .toUpperCase();
    if (!rawCode) {
      return NextResponse.json(
        { error: "Kode barcode / NISN siswa kosong." },
        { status: 400 }
      );
    }

    const attendanceType = body.attendanceType === "wali" ? "wali" : "mapel";
    const date = String(body.date || new Date().toISOString().slice(0, 10));
    const subjectName =
      attendanceType === "wali"
        ? "Guru Wali"
        : String(body.subjectName || "Matematika").trim();
    const status = ["H", "S", "I", "A"].includes(String(body.status || "H"))
      ? String(body.status || "H")
      : "H";
    const lockClass = Boolean(body.lockClass);
    const selectedClassId = body.classId ? Number(body.classId) : null;

    // Lookup student by system-generated barcodeCode, NISN, or NIS
    const matchedStudents = await db
      .select()
      .from(students)
      .where(
        or(
          eq(students.barcodeCode, rawCode),
          eq(students.nisn, rawCode),
          eq(students.nis, rawCode)
        )
      )
      .limit(1);

    if (matchedStudents.length === 0) {
      return NextResponse.json(
        {
          error: `Barcode "${rawCode}" tidak terdaftar pada data siswa SMP Negeri 1 Umalulu.`,
        },
        { status: 404 }
      );
    }

    const student = matchedStudents[0];
    const [allClasses, allTeachers] = await Promise.all([
      db.select().from(schoolClasses),
      db.select().from(teachers),
    ]);
    const studentClass = allClasses.find((c) => c.id === student.classId);

    // Enforce Guru Wali strict 1-class rule
    if (attendanceType === "wali") {
      if (
        user?.role === "wali_kelas" &&
        user.assignedClassId &&
        student.classId !== user.assignedClassId
      ) {
        return NextResponse.json(
          {
            error: `Ditolak: ${student.name} terdaftar di Kelas ${
              studentClass?.name || "-"
            }. Akun Guru Wali Anda terkunci khusus untuk Kelas ${
              user.assignedClassName
            } (1 kelas saja).`,
          },
          { status: 403 }
        );
      }

      if (selectedClassId && student.classId !== selectedClassId) {
        const expectedCls = allClasses.find((c) => c.id === selectedClassId);
        return NextResponse.json(
          {
            error: `Siswa ${student.name} berasal dari Kelas ${
              studentClass?.name || "-"
            }, bukan kelas binaan Guru Wali yang dipilih (Kelas ${
              expectedCls?.name || "-"
            }).`,
          },
          { status: 400 }
        );
      }
    } else if (lockClass && selectedClassId && student.classId !== selectedClassId) {
      const expectedCls = allClasses.find((c) => c.id === selectedClassId);
      return NextResponse.json(
        {
          error: `Siswa ${student.name} berada di Kelas ${
            studentClass?.name || "-"
          } (sedangkan sesi terkunci pada Kelas ${expectedCls?.name || "-"}).`,
        },
        { status: 400 }
      );
    }

    // Check whether student was already scanned/recorded for this exact session today
    const existingRecord = await db
      .select()
      .from(attendanceRecords)
      .where(
        and(
          eq(attendanceRecords.studentId, student.id),
          eq(attendanceRecords.date, date),
          eq(attendanceRecords.attendanceType, attendanceType),
          eq(attendanceRecords.subjectName, subjectName)
        )
      )
      .limit(1);

    const scanTime = new Date().toLocaleTimeString("id-ID", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });

    const teacherId =
      attendanceType === "wali"
        ? studentClass?.homeroomTeacherId || null
        : body.teacherId
        ? Number(body.teacherId)
        : null;

    const assignedGuruWali = studentClass?.homeroomTeacherId
      ? allTeachers.find((t) => t.id === studentClass.homeroomTeacherId)
      : null;

    const recorderName =
      user?.fullName ||
      String(body.recordedBy || "") ||
      assignedGuruWali?.name ||
      (attendanceType === "wali" ? "Guru Wali" : "Scan Barcode Sistem");

    const scanNote =
      body.notes && String(body.notes).trim()
        ? String(body.notes).trim()
        : `Scan Barcode (${scanTime})`;

    await db
      .insert(attendanceRecords)
      .values({
        studentId: student.id,
        classId: student.classId,
        attendanceType,
        subjectName,
        teacherId,
        date,
        status,
        notes: scanNote,
        recordedBy: recorderName,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [
          attendanceRecords.studentId,
          attendanceRecords.date,
          attendanceRecords.attendanceType,
          attendanceRecords.subjectName,
        ],
        set: {
          classId: student.classId,
          teacherId,
          status,
          notes: scanNote,
          recordedBy: recorderName,
          updatedAt: new Date(),
        },
      });

    const [presentCountRes, totalStudentsRes] = await Promise.all([
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(attendanceRecords)
        .where(
          and(
            eq(attendanceRecords.classId, student.classId),
            eq(attendanceRecords.date, date),
            eq(attendanceRecords.attendanceType, attendanceType),
            eq(attendanceRecords.subjectName, subjectName),
            eq(attendanceRecords.status, "H")
          )
        ),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(students)
        .where(eq(students.classId, student.classId)),
    ]);

    return NextResponse.json({
      ok: true,
      alreadyRecorded: existingRecord.length > 0,
      scannedAt: scanTime,
      session: {
        attendanceType,
        subjectName,
        date,
        status,
        classPresentCount: presentCountRes[0]?.count || 1,
        classTotalStudents: totalStudentsRes[0]?.count || 1,
      },
      student: {
        id: student.id,
        nisn: student.nisn,
        nis: student.nis,
        barcodeCode: student.barcodeCode,
        name: student.name,
        gender: student.gender,
        classId: student.classId,
        className: studentClass?.name || "-",
      },
    });
  } catch (error) {
    console.error("Barcode scan attendance error:", error);
    return NextResponse.json(
      { error: "Terjadi kesalahan saat memproses scan barcode siswa." },
      { status: 500 }
    );
  }
}

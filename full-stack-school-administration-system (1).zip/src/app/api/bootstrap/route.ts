import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  schoolSettings,
  schoolClasses,
  teachers,
  subjects,
  students,
  studentGrades,
} from "@/db/schema";
import { asc } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const [
      user,
      settingsRows,
      allClasses,
      allTeachers,
      allSubjects,
      allStudents,
      allGrades,
    ] = await Promise.all([
      getCurrentUser(request),
      db.select().from(schoolSettings).limit(1),
      db
        .select()
        .from(schoolClasses)
        .orderBy(asc(schoolClasses.gradeLevel), asc(schoolClasses.name)),
      db.select().from(teachers).orderBy(asc(teachers.name)),
      db.select().from(subjects).orderBy(asc(subjects.name)),
      db.select().from(students).orderBy(asc(students.name)),
      db.select().from(studentGrades),
    ]);

    const enrichedClasses = allClasses.map((cls) => {
      const wali = allTeachers.find((t) => t.id === cls.homeroomTeacherId);
      const count = allStudents.filter((s) => s.classId === cls.id).length;
      return {
        ...cls,
        homeroomTeacherName: wali?.name || null,
        homeroomTeacherNip: wali?.nip || null,
        studentCount: count,
      };
    });

    const enrichedTeachers = allTeachers.map((t) => {
      const waliCls = allClasses.find((c) => c.homeroomTeacherId === t.id);
      return {
        ...t,
        homeroomClassId: waliCls?.id || null,
        homeroomClassName: waliCls?.name || null,
      };
    });

    const enrichedSubjects = allSubjects.map((s) => {
      const t = allTeachers.find((tr) => tr.id === s.teacherId);
      const sGrades = allGrades.filter((g) => g.subjectId === s.id);
      const averageScore =
        sGrades.length > 0
          ? Math.round(
              sGrades.reduce((acc, item) => acc + item.totalScore, 0) /
                sGrades.length
            )
          : 0;
      const belowKkmCount = sGrades.filter(
        (g) => g.totalScore < s.kkm
      ).length;

      return {
        ...s,
        teacherName: t?.name || null,
        teacherNip: t?.nip || null,
        gradedCount: sGrades.length,
        averageScore,
        belowKkmCount,
      };
    });

    const enrichedStudents = allStudents.map((stu) => {
      const cls = allClasses.find((c) => c.id === stu.classId);
      return {
        ...stu,
        className: cls?.name || "-",
      };
    });

    return NextResponse.json({
      user,
      settings: settingsRows[0],
      classes: enrichedClasses,
      teachers: enrichedTeachers,
      subjects: enrichedSubjects,
      students: enrichedStudents,
    });
  } catch (error) {
    console.error("Bootstrap API error:", error);
    return NextResponse.json(
      { error: "Gagal memuat data awal sistem." },
      { status: 500 }
    );
  }
}

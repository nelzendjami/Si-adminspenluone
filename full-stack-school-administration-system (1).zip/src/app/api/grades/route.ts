import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  studentGrades,
  students,
  subjects,
  schoolClasses,
  teachers,
  calculateGradeSummary,
} from "@/db/schema";
import { and, asc, eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const { searchParams } = new URL(request.url);

    let classId = Number(searchParams.get("classId") || 0);
    const subjectId = Number(searchParams.get("subjectId") || 0);
    const semester = String(searchParams.get("semester") || "Genap");
    const academicYear = String(searchParams.get("academicYear") || "2025/2026");
    const view = searchParams.get("view") === "matrix" ? "matrix" : "subject";

    // If logged in as Guru Wali viewing matrix monitor, lock to their single class if none forced
    if (
      view === "matrix" &&
      user?.role === "wali_kelas" &&
      user.assignedClassId
    ) {
      classId = user.assignedClassId;
    }

    const [allClasses, allSubjects, allTeachers] = await Promise.all([
      db
        .select()
        .from(schoolClasses)
        .orderBy(asc(schoolClasses.gradeLevel), asc(schoolClasses.name)),
      db.select().from(subjects).orderBy(asc(subjects.name)),
      db.select().from(teachers),
    ]);

    if (!classId && allClasses[0]) {
      classId = allClasses[0].id;
    }

    const activeSubject =
      allSubjects.find((s) => s.id === subjectId) || allSubjects[0] || null;
    const activeClass = allClasses.find((c) => c.id === classId) || null;
    const guruWali = activeClass?.homeroomTeacherId
      ? allTeachers.find((t) => t.id === activeClass.homeroomTeacherId) || null
      : null;

    const classStudents = classId
      ? await db
          .select()
          .from(students)
          .where(eq(students.classId, classId))
          .orderBy(asc(students.name))
      : [];

    if (view === "matrix") {
      // Cross-subject grade monitoring matrix for Guru Wali & Guru Mapel
      const classGrades = classId
        ? await db
            .select()
            .from(studentGrades)
            .where(
              and(
                eq(studentGrades.classId, classId),
                eq(studentGrades.semester, semester),
                eq(studentGrades.academicYear, academicYear)
              )
            )
        : [];

      const matrixRows = classStudents.map((stu) => {
        const stuGrades = classGrades.filter((g) => g.studentId === stu.id);
        const scoresBySubject: Record<
          number,
          {
            totalScore: number | null;
            predicate: string | null;
            assignmentScore: number | null;
            midtermScore: number | null;
            finalScore: number | null;
            belowKkm: boolean;
          }
        > = {};

        let sum = 0;
        let count = 0;
        let belowKkmCount = 0;
        const weakSubjects: string[] = [];

        for (const subj of allSubjects) {
          const g = stuGrades.find((item) => item.subjectId === subj.id);
          if (g) {
            const isBelow = g.totalScore < subj.kkm;
            scoresBySubject[subj.id] = {
              totalScore: g.totalScore,
              predicate: g.predicate,
              assignmentScore: g.assignmentScore,
              midtermScore: g.midtermScore,
              finalScore: g.finalScore,
              belowKkm: isBelow,
            };
            sum += g.totalScore;
            count++;
            if (isBelow) {
              belowKkmCount++;
              weakSubjects.push(subj.name);
            }
          } else {
            scoresBySubject[subj.id] = {
              totalScore: null,
              predicate: null,
              assignmentScore: null,
              midtermScore: null,
              finalScore: null,
              belowKkm: false,
            };
          }
        }

        const averageScore = count > 0 ? Math.round(sum / count) : 0;

        return {
          studentId: stu.id,
          nisn: stu.nisn,
          nis: stu.nis,
          name: stu.name,
          gender: stu.gender,
          scoresBySubject,
          averageScore,
          belowKkmCount,
          weakSubjects,
        };
      });

      return NextResponse.json({
        view: "matrix",
        classInfo: activeClass
          ? {
              ...activeClass,
              guruWaliName: guruWali?.name || null,
              guruWaliNip: guruWali?.nip || null,
            }
          : null,
        semester,
        academicYear,
        subjects: allSubjects,
        matrixRows,
      });
    }

    // Per-Subject Grade Sheet for Input & Monitoring
    if (!activeSubject) {
      return NextResponse.json({
        view: "subject",
        subjectInfo: null,
        classInfo: activeClass,
        rows: [],
      });
    }

    const subjTeacher = activeSubject.teacherId
      ? allTeachers.find((t) => t.id === activeSubject.teacherId) || null
      : null;

    const existingGrades = await db
      .select()
      .from(studentGrades)
      .where(
        and(
          eq(studentGrades.classId, classId),
          eq(studentGrades.subjectId, activeSubject.id),
          eq(studentGrades.semester, semester),
          eq(studentGrades.academicYear, academicYear)
        )
      );

    const rows = classStudents.map((stu) => {
      const g = existingGrades.find((item) => item.studentId === stu.id);
      const assignmentScore = g?.assignmentScore ?? 80;
      const midtermScore = g?.midtermScore ?? 80;
      const finalScore = g?.finalScore ?? 80;
      const { totalScore, predicate } = g
        ? { totalScore: g.totalScore, predicate: g.predicate }
        : calculateGradeSummary(assignmentScore, midtermScore, finalScore);

      return {
        studentId: stu.id,
        nisn: stu.nisn,
        nis: stu.nis,
        name: stu.name,
        gender: stu.gender,
        assignmentScore,
        midtermScore,
        finalScore,
        totalScore,
        predicate,
        kkm: activeSubject.kkm,
        isPassing: totalScore >= activeSubject.kkm,
        teacherNotes: g?.teacherNotes ?? "",
        isSaved: Boolean(g),
        updatedBy: g?.updatedBy ?? null,
      };
    });

    return NextResponse.json({
      view: "subject",
      subjectInfo: {
        ...activeSubject,
        teacherName: subjTeacher?.name || null,
        teacherNip: subjTeacher?.nip || null,
      },
      classInfo: activeClass
        ? {
            ...activeClass,
            guruWaliName: guruWali?.name || null,
            guruWaliNip: guruWali?.nip || null,
          }
        : null,
      semester,
      academicYear,
      rows,
    });
  } catch (error) {
    console.error("Get grades error:", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar nilai mata pelajaran." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const body = await request.json();

    const classId = Number(body.classId);
    const subjectId = Number(body.subjectId);
    const semester = String(body.semester || "Genap");
    const academicYear = String(body.academicYear || "2025/2026");

    if (!classId || !subjectId) {
      return NextResponse.json(
        { error: "Kelas dan Mata Pelajaran wajib dipilih." },
        { status: 400 }
      );
    }

    const updatedBy =
      user?.fullName || String(body.updatedBy || "Guru Mata Pelajaran");

    const entries: Array<{
      studentId: number;
      assignmentScore: number;
      midtermScore: number;
      finalScore: number;
      teacherNotes: string;
    }> =
      body.mode === "single"
        ? [
            {
              studentId: Number(body.studentId),
              assignmentScore: Number(body.assignmentScore ?? 0),
              midtermScore: Number(body.midtermScore ?? 0),
              finalScore: Number(body.finalScore ?? 0),
              teacherNotes: String(body.teacherNotes || ""),
            },
          ]
        : Array.isArray(body.entries)
        ? body.entries.map(
            (e: {
              studentId: number;
              assignmentScore?: number;
              midtermScore?: number;
              finalScore?: number;
              teacherNotes?: string;
            }) => ({
              studentId: Number(e.studentId),
              assignmentScore: Number(e.assignmentScore ?? 0),
              midtermScore: Number(e.midtermScore ?? 0),
              finalScore: Number(e.finalScore ?? 0),
              teacherNotes: String(e.teacherNotes || ""),
            })
          )
        : [];

    if (entries.length === 0) {
      return NextResponse.json(
        { error: "Tidak ada data nilai untuk disimpan." },
        { status: 400 }
      );
    }

    for (const item of entries) {
      const a = Math.max(0, Math.min(100, Math.round(item.assignmentScore)));
      const m = Math.max(0, Math.min(100, Math.round(item.midtermScore)));
      const f = Math.max(0, Math.min(100, Math.round(item.finalScore)));
      const { totalScore, predicate } = calculateGradeSummary(a, m, f);

      await db
        .insert(studentGrades)
        .values({
          studentId: item.studentId,
          classId,
          subjectId,
          semester,
          academicYear,
          assignmentScore: a,
          midtermScore: m,
          finalScore: f,
          totalScore,
          predicate,
          teacherNotes: item.teacherNotes,
          updatedBy,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: [
            studentGrades.studentId,
            studentGrades.subjectId,
            studentGrades.semester,
            studentGrades.academicYear,
          ],
          set: {
            classId,
            assignmentScore: a,
            midtermScore: m,
            finalScore: f,
            totalScore,
            predicate,
            teacherNotes: item.teacherNotes,
            updatedBy,
            updatedAt: new Date(),
          },
        });
    }

    return NextResponse.json({
      ok: true,
      savedCount: entries.length,
    });
  } catch (error) {
    console.error("Save grades error:", error);
    return NextResponse.json(
      { error: "Gagal menyimpan nilai mata pelajaran ke database." },
      { status: 500 }
    );
  }
}

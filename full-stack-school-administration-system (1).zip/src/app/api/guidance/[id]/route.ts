import { NextResponse } from "next/server";
import { db } from "@/db";
import { guidanceRecords } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";

export async function PUT(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const { id } = await context.params;
    const recordId = Number(id);
    const body = await request.json();

    const existing = await db
      .select()
      .from(guidanceRecords)
      .where(eq(guidanceRecords.id, recordId))
      .limit(1);

    if (!existing[0]) {
      return NextResponse.json(
        { error: "Data bimbingan tidak ditemukan." },
        { status: 404 }
      );
    }

    if (
      user?.role === "wali_kelas" &&
      user.assignedClassId &&
      existing[0].classId !== user.assignedClassId
    ) {
      return NextResponse.json(
        { error: "Anda hanya dapat mengubah bimbingan Anak Wali kelas Anda." },
        { status: 403 }
      );
    }

    const [updated] = await db
      .update(guidanceRecords)
      .set({
        studentId: body.studentId
          ? Number(body.studentId)
          : existing[0].studentId,
        date: body.date ? String(body.date) : existing[0].date,
        category: body.category
          ? String(body.category).trim()
          : existing[0].category,
        topic: body.topic ? String(body.topic).trim() : existing[0].topic,
        notes:
          body.notes !== undefined
            ? String(body.notes).trim()
            : existing[0].notes,
        followUpPlan:
          body.followUpPlan !== undefined
            ? String(body.followUpPlan).trim()
            : existing[0].followUpPlan,
        parentInvolved:
          body.parentInvolved !== undefined
            ? Boolean(body.parentInvolved)
            : existing[0].parentInvolved,
        status: body.status ? String(body.status).trim() : existing[0].status,
      })
      .where(eq(guidanceRecords.id, recordId))
      .returning();

    return NextResponse.json({ ok: true, guidance: updated });
  } catch (error) {
    console.error("Update guidance record error:", error);
    return NextResponse.json(
      { error: "Gagal memperbarui catatan bimbingan anak wali." },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const { id } = await context.params;
    const recordId = Number(id);

    const existing = await db
      .select()
      .from(guidanceRecords)
      .where(eq(guidanceRecords.id, recordId))
      .limit(1);

    if (
      existing[0] &&
      user?.role === "wali_kelas" &&
      user.assignedClassId &&
      existing[0].classId !== user.assignedClassId
    ) {
      return NextResponse.json(
        { error: "Akses ditolak." },
        { status: 403 }
      );
    }

    await db.delete(guidanceRecords).where(eq(guidanceRecords.id, recordId));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Delete guidance record error:", error);
    return NextResponse.json(
      { error: "Gagal menghapus catatan bimbingan." },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  guidanceRecords,
  students,
  schoolClasses,
  teachers,
  studentGrades,
  subjects,
  attendanceRecords,
} from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const { searchParams } = new URL(request.url);

    let classId = Number(searchParams.get("classId") || 0);

    // Strictly lock Guru Wali session to their single assigned class
    if (user?.role === "wali_kelas" && user.assignedClassId) {
      classId = user.assignedClassId;
    }

    const [allClasses, allTeachers, allSubjects] = await Promise.all([
      db
        .select()
        .from(schoolClasses)
        .orderBy(asc(schoolClasses.gradeLevel), asc(schoolClasses.name)),
      db.select().from(teachers),
      db.select().from(subjects).orderBy(asc(subjects.name)),
    ]);

    if (!classId && allClasses[0]) {
      classId = allClasses[0].id;
    }

    const activeClass = allClasses.find((c) => c.id === classId) || null;
    const guruWali = activeClass?.homeroomTeacherId
      ? allTeachers.find((t) => t.id === activeClass.homeroomTeacherId) || null
      : null;

    const [classStudents, records, classGrades, classAttendance] =
      await Promise.all([
        classId
          ? db
              .select()
              .from(students)
              .where(eq(students.classId, classId))
              .orderBy(asc(students.name))
          : Promise.resolve([]),
        classId
          ? db
              .select()
              .from(guidanceRecords)
              .where(eq(guidanceRecords.classId, classId))
              .orderBy(desc(guidanceRecords.date), desc(guidanceRecords.id))
          : Promise.resolve([]),
        classId
          ? db
              .select()
              .from(studentGrades)
              .where(eq(studentGrades.classId, classId))
          : Promise.resolve([]),
        classId
          ? db
              .select()
              .from(attendanceRecords)
              .where(eq(attendanceRecords.classId, classId))
          : Promise.resolve([]),
      ]);

    const studentMap = new Map(classStudents.map((s) => [s.id, s]));

    // Build holistic Anak Wali Monitoring Profiles (Grades + Attendance + Guidance)
    const childProfiles = classStudents.map((stu) => {
      const sGrades = classGrades.filter((g) => g.studentId === stu.id);
      const averageGrade =
        sGrades.length > 0
          ? Math.round(
              sGrades.reduce((sum, g) => sum + g.totalScore, 0) / sGrades.length
            )
          : 0;

      const detailedGrades = allSubjects.map((subj) => {
        const g = sGrades.find((item) => item.subjectId === subj.id);
        return {
          subjectId: subj.id,
          subjectCode: subj.code,
          subjectName: subj.name,
          kkm: subj.kkm,
          assignmentScore: g?.assignmentScore ?? null,
          midtermScore: g?.midtermScore ?? null,
          finalScore: g?.finalScore ?? null,
          totalScore: g?.totalScore ?? null,
          predicate: g?.predicate ?? null,
          isBelowKkm: g ? g.totalScore < subj.kkm : false,
        };
      });

      const belowKkmSubjects = detailedGrades
        .filter((d) => d.isBelowKkm)
        .map((d) => `${d.subjectName} (${d.totalScore})`);

      const sAtt = classAttendance.filter((a) => a.studentId === stu.id);
      const presentCount = sAtt.filter((a) => a.status === "H").length;
      const alpaCount = sAtt.filter((a) => a.status === "A").length;
      const attendanceRate =
        sAtt.length > 0 ? Math.round((presentCount / sAtt.length) * 100) : 100;

      const guidanceCount = records.filter(
        (r) => r.studentId === stu.id
      ).length;

      return {
        id: stu.id,
        nisn: stu.nisn,
        nis: stu.nis,
        name: stu.name,
        gender: stu.gender,
        parentName: stu.parentName || "-",
        address: stu.address || "-",
        averageGrade,
        belowKkmCount: belowKkmSubjects.length,
        belowKkmSubjects,
        attendanceRate,
        alpaCount,
        guidanceCount,
        detailedGrades,
      };
    });

    const enrichedRecords = records.map((rec) => {
      const stu = studentMap.get(rec.studentId);
      const gw = allTeachers.find((t) => t.id === rec.guruWaliId);
      return {
        ...rec,
        studentName: stu?.name || "-",
        studentNisn: stu?.nisn || "-",
        className: activeClass?.name || "-",
        guruWaliName: gw?.name || guruWali?.name || "Guru Wali",
        guruWaliNip: gw?.nip || guruWali?.nip || "-",
      };
    });

    return NextResponse.json({
      classInfo: activeClass
        ? {
            ...activeClass,
            guruWaliName: guruWali?.name || null,
            guruWaliNip: guruWali?.nip || null,
          }
        : null,
      childProfiles,
      records: enrichedRecords,
    });
  } catch (error) {
    console.error("Get guidance records error:", error);
    return NextResponse.json(
      { error: "Gagal memuat data bimbingan anak wali." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    const body = await request.json();

    const studentId = Number(body.studentId);
    const classId = Number(body.classId);
    const date = String(body.date || new Date().toISOString().slice(0, 10));
    const category = String(body.category || "Akademik & Nilai").trim();
    const topic = String(body.topic || "").trim();
    const notes = String(body.notes || "").trim();
    const followUpPlan = String(body.followUpPlan || "").trim();
    const parentInvolved = Boolean(body.parentInvolved);
    const status = String(body.status || "Dalam Pemantauan").trim();

    if (!studentId || !classId || !topic) {
      return NextResponse.json(
        { error: "Anak Wali, Kelas, dan Topik Bimbingan wajib diisi." },
        { status: 400 }
      );
    }

    if (
      user?.role === "wali_kelas" &&
      user.assignedClassId &&
      classId !== user.assignedClassId
    ) {
      return NextResponse.json(
        {
          error: `Akun Guru Wali Anda terkunci khusus untuk Anak Wali Kelas ${user.assignedClassName}.`,
        },
        { status: 403 }
      );
    }

    const clsRows = await db
      .select()
      .from(schoolClasses)
      .where(eq(schoolClasses.id, classId))
      .limit(1);
    const guruWaliId = body.guruWaliId
      ? Number(body.guruWaliId)
      : clsRows[0]?.homeroomTeacherId || null;

    const createdBy =
      user?.fullName || String(body.createdBy || "Guru Wali");

    const [created] = await db
      .insert(guidanceRecords)
      .values({
        studentId,
        classId,
        guruWaliId,
        date,
        category,
        topic,
        notes,
        followUpPlan,
        parentInvolved,
        status,
        createdBy,
      })
      .returning();

    return NextResponse.json(
      { ok: true, guidance: created },
      { status: 201 }
    );
  } catch (error) {
    console.error("Create guidance record error:", error);
    return NextResponse.json(
      { error: "Gagal menyimpan catatan bimbingan anak wali." },
      { status: 500 }
    );
  }
}

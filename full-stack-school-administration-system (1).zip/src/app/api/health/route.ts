import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    await ensureDatabaseReady();
    return Response.json({ ok: true, school: "SMP Negeri 1 Umalulu" });
  } catch (err) {
    console.error("Health check error:", err);
    return Response.json({ ok: false }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { and, eq, ne, or } from "drizzle-orm";
import { getCurrentUser, hashPassword } from "@/lib/auth";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    return NextResponse.json(
      { user },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (error) {
    console.error("Auth me error:", error);
    return NextResponse.json({ user: null });
  }
}

export async function PATCH(request: Request) {
  try {
    await ensureDatabaseReady();
    const body = await request.json();
    const current = await getCurrentUser(request, body?._st || null);

    if (!current) {
      return NextResponse.json(
        { error: "Silakan login terlebih dahulu." },
        { status: 401 }
      );
    }

    const fullName = String(body.fullName || current.fullName).trim();
    const username = String(body.username || current.username)
      .trim()
      .toLowerCase();
    const email = String(body.email || current.email)
      .trim()
      .toLowerCase();
    const newPassword = String(body.newPassword || "").trim();

    if (!username || !email) {
      return NextResponse.json(
        { error: "Username dan email wajib diisi." },
        { status: 400 }
      );
    }

    const duplicate = await db
      .select()
      .from(users)
      .where(
        and(
          ne(users.id, current.id),
          or(eq(users.username, username), eq(users.email, email))
        )
      )
      .limit(1);

    if (duplicate.length > 0) {
      return NextResponse.json(
        { error: "Username atau email tersebut sudah dipakai akun lain." },
        { status: 400 }
      );
    }

    const updateData: {
      fullName: string;
      username: string;
      email: string;
      passwordHash?: string;
    } = {
      fullName,
      username,
      email,
    };

    if (newPassword.length > 0) {
      if (newPassword.length < 6) {
        return NextResponse.json(
          { error: "Password baru minimal 6 karakter." },
          { status: 400 }
        );
      }
      updateData.passwordHash = await hashPassword(newPassword);
    }

    await db.update(users).set(updateData).where(eq(users.id, current.id));
    const updatedUser = await getCurrentUser(request, body?._st || null);

    return NextResponse.json({ ok: true, user: updatedUser });
  } catch (error) {
    console.error("Profile update error:", error);
    return NextResponse.json(
      { error: "Gagal memperbarui profil akun." },
      { status: 400 }
    );
  }
}

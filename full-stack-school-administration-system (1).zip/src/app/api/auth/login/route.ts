import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, teachers, schoolClasses } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { createSession, verifyPassword, SessionUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/lib/seed";

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const body = await request.json();
    const identifier = String(body.identifier || body.username || "").trim();
    const password = String(body.password || "");

    if (!identifier || !password) {
      return NextResponse.json(
        { error: "Username/email dan password wajib diisi." },
        { status: 400 }
      );
    }

    const found = await db
      .select()
      .from(users)
      .where(
        or(
          eq(users.username, identifier.toLowerCase()),
          eq(users.email, identifier.toLowerCase()),
          eq(users.username, identifier)
        )
      )
      .limit(1);

    if (found.length === 0) {
      return NextResponse.json(
        { error: "Akun tidak ditemukan. Periksa kembali username atau email." },
        { status: 401 }
      );
    }

    const userRow = found[0];
    const valid = await verifyPassword(password, userRow.passwordHash);
    if (!valid) {
      return NextResponse.json(
        { error: "Password yang dimasukkan salah." },
        { status: 401 }
      );
    }

    const token = await createSession(userRow.id, request);

    let assignedClassId = userRow.assignedClassId;
    let assignedClassName: string | null = null;
    let teacherNip: string | null = null;
    let teacherSubject: string | null = null;

    if (userRow.teacherId) {
      const tRows = await db
        .select()
        .from(teachers)
        .where(eq(teachers.id, userRow.teacherId))
        .limit(1);
      if (tRows[0]) {
        teacherNip = tRows[0].nip;
        teacherSubject = tRows[0].subject;
      }
      const cRows = await db
        .select()
        .from(schoolClasses)
        .where(eq(schoolClasses.homeroomTeacherId, userRow.teacherId))
        .limit(1);
      if (cRows[0]) {
        assignedClassId = cRows[0].id;
        assignedClassName = cRows[0].name;
      }
    }

    if (assignedClassId && !assignedClassName) {
      const cRows = await db
        .select()
        .from(schoolClasses)
        .where(eq(schoolClasses.id, assignedClassId))
        .limit(1);
      if (cRows[0]) assignedClassName = cRows[0].name;
    }

    const sessionUser: SessionUser = {
      id: userRow.id,
      username: userRow.username,
      email: userRow.email,
      fullName: userRow.fullName,
      role: (userRow.role as SessionUser["role"]) || "admin",
      teacherId: userRow.teacherId,
      teacherNip,
      teacherSubject,
      assignedClassId,
      assignedClassName,
    };

    return NextResponse.json({
      ok: true,
      token,
      user: sessionUser,
    });
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json(
      { error: "Terjadi kesalahan saat memproses login." },
      { status: 500 }
    );
  }
}

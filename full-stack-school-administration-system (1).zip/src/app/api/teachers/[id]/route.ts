import { NextResponse } from "next/server";
import { db } from "@/db";
import { teachers, subjects } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export async function PUT(
  request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const teacherId = Number(id);
    const body = await request.json();

    const name = String(body.name || "").trim();
    const nip = String(body.nip || "").trim();
    const subject = String(body.subject || "").trim();
    const employmentStatus = String(body.employmentStatus || "PNS").trim();
    const phone = String(body.phone || "").trim();

    if (!name || !nip || !subject) {
      return NextResponse.json(
        { error: "Nama Guru, NIP, dan Mata Pelajaran wajib diisi." },
        { status: 400 }
      );
    }

    const [updated] = await db
      .update(teachers)
      .set({
        name,
        nip,
        subject,
        employmentStatus,
        phone,
      })
      .where(eq(teachers.id, teacherId))
      .returning();

    const existingSubj = await db
      .select()
      .from(subjects)
      .where(eq(subjects.name, subject))
      .limit(1);

    if (existingSubj.length === 0) {
      const cleanCode =
        subject
          .replace(/[^A-Za-z]/g, "")
          .slice(0, 4)
          .toUpperCase() + Math.floor(10 + Math.random() * 89);
      await db.insert(subjects).values({
        code: cleanCode,
        name: subject,
        teacherId: updated.id,
      });
    }

    return NextResponse.json({ ok: true, teacher: updated });
  } catch (error) {
    console.error("Update teacher error:", error);
    return NextResponse.json(
      { error: "Gagal memperbarui data guru." },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    await ensureDatabaseReady();
    const { id } = await context.params;
    const teacherId = Number(id);

    await db.delete(teachers).where(eq(teachers.id, teacherId));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Delete teacher error:", error);
    return NextResponse.json(
      { error: "Gagal menghapus data guru." },
      { status: 500 }
    );
  }
}

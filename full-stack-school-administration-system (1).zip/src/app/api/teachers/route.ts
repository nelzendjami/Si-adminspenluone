import { NextResponse } from "next/server";
import { db } from "@/db";
import { teachers, schoolClasses, subjects } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureDatabaseReady();
    const allTeachers = await db
      .select()
      .from(teachers)
      .orderBy(asc(teachers.name));
    const allClasses = await db.select().from(schoolClasses);

    const enriched = allTeachers.map((t) => {
      const waliClass = allClasses.find((c) => c.homeroomTeacherId === t.id);
      return {
        ...t,
        homeroomClassId: waliClass?.id || null,
        homeroomClassName: waliClass?.name || null,
      };
    });

    return NextResponse.json({ teachers: enriched });
  } catch (error) {
    console.error("Get teachers error:", error);
    return NextResponse.json(
      { error: "Gagal memuat daftar guru." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const body = await request.json();
    const name = String(body.name || "").trim();
    const nip = String(body.nip || "").trim();
    const subject = String(body.subject || "").trim();
    const employmentStatus = String(body.employmentStatus || "PNS").trim();
    const phone = String(body.phone || "").trim();

    if (!name || !nip || !subject) {
      return NextResponse.json(
        { error: "Nama Guru, NIP, dan Mata Pelajaran wajib diisi." },
        { status: 400 }
      );
    }

    const [created] = await db
      .insert(teachers)
      .values({
        name,
        nip,
        subject,
        employmentStatus,
        phone,
      })
      .returning();

    // Ensure subject exists in master subjects list so it appears in Subject Attendance dropdown
    const existingSubj = await db
      .select()
      .from(subjects)
      .where(eq(subjects.name, subject))
      .limit(1);

    if (existingSubj.length === 0) {
      const cleanCode =
        subject
          .replace(/[^A-Za-z]/g, "")
          .slice(0, 4)
          .toUpperCase() + Math.floor(10 + Math.random() * 89);
      await db.insert(subjects).values({
        code: cleanCode,
        name: subject,
        teacherId: created.id,
      });
    }

    return NextResponse.json({ ok: true, teacher: created }, { status: 201 });
  } catch (error) {
    console.error("Create teacher error:", error);
    return NextResponse.json(
      { error: "Gagal menambahkan data guru." },
      { status: 500 }
    );
  }
}

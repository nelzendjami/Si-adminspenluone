import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  schoolSettings,
  teachers,
  schoolClasses,
  subjects,
  students,
  attendanceRecords,
  studentGrades,
  guidanceRecords,
} from "@/db/schema";
import { sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

// GET: Export Full JSON Backup for School Archival & Production Safety
export async function GET(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    if (!user || user.role !== "admin") {
      return NextResponse.json(
        { error: "Login Admin Pribadi diperlukan untuk mengunduh backup." },
        { status: 401 }
      );
    }

    const [
      settingsData,
      teachersData,
      classesData,
      subjectsData,
      studentsData,
      attendanceData,
      gradesData,
      guidanceData,
    ] = await Promise.all([
      db.select().from(schoolSettings),
      db.select().from(teachers),
      db.select().from(schoolClasses),
      db.select().from(subjects),
      db.select().from(students),
      db.select().from(attendanceRecords),
      db.select().from(studentGrades),
      db.select().from(guidanceRecords),
    ]);

    const backupPayload = {
      exportedAt: new Date().toISOString(),
      system: "SI-ADMIN SMP Negeri 1 Umalulu",
      version: "1.0.0",
      data: {
        settings: settingsData,
        teachers: teachersData,
        classes: classesData,
        subjects: subjectsData,
        students: studentsData,
        attendanceRecords: attendanceData,
        studentGrades: gradesData,
        guidanceRecords: guidanceData,
      },
    };

    const fileDate = new Date().toISOString().slice(0, 10);
    return new NextResponse(JSON.stringify(backupPayload, null, 2), {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="Backup_SI_ADMIN_SMPN1_Umalulu_${fileDate}.json"`,
      },
    });
  } catch (error) {
    console.error("Backup export error:", error);
    return NextResponse.json(
      { error: "Gagal membuat file cadangan database." },
      { status: 500 }
    );
  }
}

// POST: Clean Production Preparation Actions (Admin Pribadi Only)
export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);
    if (!user || user.role !== "admin") {
      return NextResponse.json(
        { error: "Akses ditolak. Login sebagai Admin Pribadi." },
        { status: 401 }
      );
    }

    const body = await request.json();
    const action = String(body.action || "");

    if (action === "reset_transactional_records") {
      // Clears demo attendance, grades & guidance logs while keeping School Logo, Classes, Teachers, Subjects & Students
      await db.execute(sql`
        DELETE FROM "attendance_records";
        DELETE FROM "student_grades";
        DELETE FROM "guidance_records";
        UPDATE "school_settings" SET "demo_seeded" = true;
      `);
      return NextResponse.json({
        ok: true,
        message:
          "Riwayat absensi, nilai, dan jurnal bimbingan ujicoba telah dibersihkan. Master kelas, guru, mapel, dan siswa tetap terjaga.",
      });
    }

    if (action === "clear_demo_students") {
      // Clears students + transactional records so school operator can import real Dapodik students cleanly
      await db.execute(sql`
        DELETE FROM "attendance_records";
        DELETE FROM "student_grades";
        DELETE FROM "guidance_records";
        DELETE FROM "students";
        UPDATE "school_settings" SET "demo_seeded" = true;
      `);
      return NextResponse.json({
        ok: true,
        message:
          "Seluruh data siswa contoh telah dikosongkan. Sistem kini bersih dan siap menerima Import Data Siswa Asli SMP Negeri 1 Umalulu.",
      });
    }

    return NextResponse.json(
      { error: "Tindakan pemeliharaan tidak dikenali." },
      { status: 400 }
    );
  } catch (error) {
    console.error("System manage action error:", error);
    return NextResponse.json(
      { error: "Gagal memproses tindakan pemeliharaan sistem." },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { schoolSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureDatabaseReady } from "@/lib/seed";

export const dynamic = "force-dynamic";

function guessImageMime(filename: string, rawType: string): string | null {
  if (rawType && rawType.startsWith("image/")) {
    return rawType === "image/jpg" ? "image/jpeg" : rawType;
  }
  const lower = filename.toLowerCase();
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".jfif"))
    return "image/jpeg";
  if (lower.endsWith(".webp")) return "image/webp";
  if (lower.endsWith(".svg")) return "image/svg+xml";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".ico")) return "image/x-icon";
  if (lower.endsWith(".bmp")) return "image/bmp";
  return null;
}

export async function GET() {
  try {
    await ensureDatabaseReady();
    const rows = await db.select().from(schoolSettings).limit(1);
    return NextResponse.json(
      { settings: rows[0] },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (error) {
    console.error("Get settings error:", error);
    return NextResponse.json(
      { error: "Gagal memuat pengaturan sekolah." },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    await ensureDatabaseReady();
    const body = await request.json();
    const existing = await db.select().from(schoolSettings).limit(1);

    const payload: {
      schoolName: string;
      npsn: string;
      address: string;
      academicYear: string;
      semester: string;
      principalName: string;
      principalNip: string;
      email: string;
      phone: string;
      logoUrl?: string;
      updatedAt: Date;
    } = {
      schoolName: String(body.schoolName || "SMP Negeri 1 Umalulu").trim(),
      npsn: String(body.npsn || "50303812").trim(),
      address: String(body.address || "").trim(),
      academicYear: String(body.academicYear || "2025/2026").trim(),
      semester: String(body.semester || "Genap").trim(),
      principalName: String(body.principalName || "").trim(),
      principalNip: String(body.principalNip || "").trim(),
      email: String(body.email || "").trim(),
      phone: String(body.phone || "").trim(),
      updatedAt: new Date(),
    };

    if (!payload.principalName || !payload.principalNip) {
      return NextResponse.json(
        { error: "Nama Kepala Sekolah dan NIP wajib diisi." },
        { status: 400 }
      );
    }

    // If an authenticated Admin also sends logoUrl in PUT, persist it atomically
    if (body.logoUrl) {
      const user = await getCurrentUser(request);
      if (user?.role === "admin") {
        payload.logoUrl = String(body.logoUrl).trim();
      }
    }

    let updated;
    if (existing.length > 0) {
      [updated] = await db
        .update(schoolSettings)
        .set(payload)
        .where(eq(schoolSettings.id, existing[0].id))
        .returning();
    } else {
      [updated] = await db.insert(schoolSettings).values(payload).returning();
    }

    return NextResponse.json(
      { ok: true, settings: updated },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (error) {
    console.error("Update settings error:", error);
    return NextResponse.json(
      { error: "Gagal menyimpan profil sekolah & Kepala Sekolah." },
      { status: 500 }
    );
  }
}

// POST: Manual School Logo Import (Strict Admin Pribadi Login Required)
export async function POST(request: Request) {
  try {
    await ensureDatabaseReady();
    const user = await getCurrentUser(request);

    if (!user || user.role !== "admin") {
      return NextResponse.json(
        {
          error:
            "Akses ditolak. Silakan login terlebih dahulu sebagai Admin Pribadi untuk mengganti Logo Sekolah.",
        },
        { status: 401 }
      );
    }

    const contentType = request.headers.get("content-type") || "";
    let newLogoUrl = "/images/logo-smpn1-umalulu.png";

    if (contentType.includes("multipart/form-data")) {
      const formData = await request.formData();
      const file = formData.get("file");

      if (!file || !(file instanceof File)) {
        return NextResponse.json(
          { error: "Pilih file gambar logo terlebih dahulu." },
          { status: 400 }
        );
      }

      const detectedMime = guessImageMime(file.name, file.type);
      if (!detectedMime) {
        return NextResponse.json(
          {
            error:
              "Format logo tidak didukung. Gunakan file PNG, JPG, WEBP, SVG, GIF, atau ICO.",
          },
          { status: 400 }
        );
      }

      if (file.size > 10 * 1024 * 1024) {
        return NextResponse.json(
          { error: "Ukuran file logo maksimal 10 MB." },
          { status: 400 }
        );
      }

      const bytes = await file.arrayBuffer();
      const base64 = Buffer.from(bytes).toString("base64");
      newLogoUrl = `data:${detectedMime};base64,${base64}`;
    } else {
      const body = await request.json();
      if (body.resetDefault) {
        newLogoUrl = "/images/logo-smpn1-umalulu.png";
      } else if (body.logoDataUrl) {
        const raw = String(body.logoDataUrl).trim();
        if (
          raw.startsWith("data:image/") ||
          raw.startsWith("https://") ||
          raw.startsWith("http://") ||
          raw.startsWith("/")
        ) {
          newLogoUrl = raw;
        } else {
          return NextResponse.json(
            {
              error:
                "Data atau URL logo tidak valid. Unggah file gambar atau masukkan URL https://...",
            },
            { status: 400 }
          );
        }
      } else {
        return NextResponse.json(
          { error: "Data gambar logo tidak ditemukan." },
          { status: 400 }
        );
      }
    }

    const existing = await db.select().from(schoolSettings).limit(1);
    let updated;
    if (existing.length > 0) {
      [updated] = await db
        .update(schoolSettings)
        .set({ logoUrl: newLogoUrl, updatedAt: new Date() })
        .where(eq(schoolSettings.id, existing[0].id))
        .returning();
    } else {
      [updated] = await db
        .insert(schoolSettings)
        .values({ logoUrl: newLogoUrl })
        .returning();
    }

    return NextResponse.json(
      { ok: true, settings: updated },
      { headers: { "Cache-Control": "no-store, max-age=0" } }
    );
  } catch (error) {
    console.error("Upload logo error:", error);
    return NextResponse.json(
      { error: "Gagal mengimpor logo sekolah." },
      { status: 500 }
    );
  }
}

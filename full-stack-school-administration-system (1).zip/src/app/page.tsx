import React from "react";
import { db } from "@/db";
import {
  schoolSettings,
  schoolClasses,
  teachers,
  subjects,
  students,
  attendanceRecords,
  studentGrades,
} from "@/db/schema";
import { and, asc, gte, lte } from "drizzle-orm";
import { ensureDatabaseReady } from "@/lib/seed";
import { getCurrentUser } from "@/lib/auth";
import SchoolAdminDashboard from "@/components/SchoolAdminDashboard";
import { RecapResponse } from "@/types/school";

export const dynamic = "force-dynamic";

export default async function HomePage({
  searchParams,
}: {
  searchParams?: Promise<{ _st?: string }>;
}) {
  await ensureDatabaseReady();
  const resolvedParams = searchParams ? await searchParams : undefined;
  const tokenFromUrl =
    typeof resolvedParams?._st === "string" ? resolvedParams._st : null;

  const today = new Date();
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(today.getDate() - 30);
  const startDate = thirtyDaysAgo.toISOString().slice(0, 10);
  const endDate = today.toISOString().slice(0, 10);

  const [
    user,
    settingsRows,
    allClasses,
    allTeachers,
    allSubjects,
    allStudents,
    recentAttendance,
    allGrades,
  ] = await Promise.all([
    getCurrentUser(undefined, tokenFromUrl),
    db.select().from(schoolSettings).limit(1),
    db
      .select()
      .from(schoolClasses)
      .orderBy(asc(schoolClasses.gradeLevel), asc(schoolClasses.name)),
    db.select().from(teachers).orderBy(asc(teachers.name)),
    db.select().from(subjects).orderBy(asc(subjects.name)),
    db.select().from(students).orderBy(asc(students.name)),
    db
      .select()
      .from(attendanceRecords)
      .where(
        and(
          gte(attendanceRecords.date, startDate),
          lte(attendanceRecords.date, endDate)
        )
      ),
    db.select().from(studentGrades),
  ]);

  const enrichedClasses = allClasses.map((cls) => {
    const wali = allTeachers.find((t) => t.id === cls.homeroomTeacherId);
    const count = allStudents.filter((s) => s.classId === cls.id).length;
    return {
      ...cls,
      homeroomTeacherName: wali?.name || null,
      homeroomTeacherNip: wali?.nip || null,
      studentCount: count,
    };
  });

  const enrichedTeachers = allTeachers.map((t) => {
    const waliCls = allClasses.find((c) => c.homeroomTeacherId === t.id);
    return {
      ...t,
      homeroomClassId: waliCls?.id || null,
      homeroomClassName: waliCls?.name || null,
    };
  });

  const enrichedSubjects = allSubjects.map((s) => {
    const t = allTeachers.find((tr) => tr.id === s.teacherId);
    const sGrades = allGrades.filter((g) => g.subjectId === s.id);
    const averageScore =
      sGrades.length > 0
        ? Math.round(
            sGrades.reduce((acc, item) => acc + item.totalScore, 0) /
              sGrades.length
          )
        : 0;
    const belowKkmCount = sGrades.filter((g) => g.totalScore < s.kkm).length;

    return {
      ...s,
      teacherName: t?.name || null,
      teacherNip: t?.nip || null,
      gradedCount: sGrades.length,
      averageScore,
      belowKkmCount,
    };
  });

  const enrichedStudents = allStudents.map((stu) => {
    const cls = allClasses.find((c) => c.id === stu.classId);
    return {
      ...stu,
      className: cls?.name || "-",
    };
  });

  const uniqueDates = Array.from(
    new Set(recentAttendance.map((r) => r.date))
  ).sort();
  const dailyTrend = uniqueDates.map((dt) => {
    const dRecs = recentAttendance.filter((r) => r.date === dt);
    const hadir = dRecs.filter((r) => r.status === "H").length;
    const sakit = dRecs.filter((r) => r.status === "S").length;
    const izin = dRecs.filter((r) => r.status === "I").length;
    const alpa = dRecs.filter((r) => r.status === "A").length;
    const total = dRecs.length;
    return {
      date: dt,
      hadir,
      sakit,
      izin,
      alpa,
      total,
      percentage: total > 0 ? Math.round((hadir / total) * 100) : 0,
    };
  });

  const totalHadir = recentAttendance.filter((r) => r.status === "H").length;
  const totalSakit = recentAttendance.filter((r) => r.status === "S").length;
  const totalIzin = recentAttendance.filter((r) => r.status === "I").length;
  const totalAlpa = recentAttendance.filter((r) => r.status === "A").length;
  const totalEntries = recentAttendance.length;

  const initialRecap: RecapResponse = {
    filters: {
      classId: "all",
      type: "all",
      subjectName: "all",
      startDate,
      endDate,
    },
    summary: {
      totalEntries,
      hadir: totalHadir,
      sakit: totalSakit,
      izin: totalIzin,
      alpa: totalAlpa,
      attendanceRate:
        totalEntries > 0 ? Math.round((totalHadir / totalEntries) * 100) : 100,
    },
    studentRecap: [],
    classSummary: [],
    dailyTrend,
  };

  return (
    <SchoolAdminDashboard
      initialUser={user}
      initialSessionToken={tokenFromUrl}
      initialSettings={settingsRows[0]}
      initialClasses={enrichedClasses}
      initialTeachers={enrichedTeachers}
      initialSubjects={enrichedSubjects}
      initialStudents={enrichedStudents}
      initialRecap={initialRecap}
    />
  );
}

import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title:
    "SI-ADMIN SMP Negeri 1 Umalulu — Sistem Administrasi & Absensi Barcode Sekolah",
  description:
    "Sistem Informasi Administrasi Sekolah, Scan Barcode Siswa Otomatis, Absensi Mata Pelajaran, Absensi Guru Wali, Daftar Nilai Per Mapel, Bimbingan Anak Wali & Rekapan Kehadiran SMP Negeri 1 Umalulu, Kab. Sumba Timur.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}

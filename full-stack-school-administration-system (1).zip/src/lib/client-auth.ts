"use client";

export const CLIENT_TOKEN_STORAGE_KEY = "smpn1_umalulu_auth_token";

// In-memory token store: works 100% even in strict Incognito / cross-site iframes
// where BOTH third-party cookies AND localStorage/sessionStorage are blocked!
let memorySessionToken: string | null = null;

export function getStoredSessionToken(): string | null {
  if (memorySessionToken) return memorySessionToken;
  if (typeof window === "undefined") return null;

  try {
    const fromSession = window.sessionStorage.getItem(CLIENT_TOKEN_STORAGE_KEY);
    if (fromSession) {
      memorySessionToken = fromSession;
      return fromSession;
    }
  } catch {
    // ignore sandboxed sessionStorage SecurityError
  }

  try {
    const fromLocal = window.localStorage.getItem(CLIENT_TOKEN_STORAGE_KEY);
    if (fromLocal) {
      memorySessionToken = fromLocal;
      return fromLocal;
    }
  } catch {
    // ignore sandboxed localStorage SecurityError
  }

  return null;
}

export function setStoredSessionToken(token: string | null): void {
  const clean = token && token.trim() ? token.trim() : null;
  memorySessionToken = clean;

  if (typeof window === "undefined") return;

  try {
    if (clean) {
      window.sessionStorage.setItem(CLIENT_TOKEN_STORAGE_KEY, clean);
    } else {
      window.sessionStorage.removeItem(CLIENT_TOKEN_STORAGE_KEY);
    }
  } catch {
    // ignore storage restriction
  }

  try {
    if (clean) {
      window.localStorage.setItem(CLIENT_TOKEN_STORAGE_KEY, clean);
    } else {
      window.localStorage.removeItem(CLIENT_TOKEN_STORAGE_KEY);
    }
  } catch {
    // ignore storage restriction
  }
}

export function appendSessionTokenToApiUrl(urlStr: string): string {
  const token = getStoredSessionToken();
  if (!token) return urlStr;
  if (urlStr.includes("_st=")) return urlStr;
  const separator = urlStr.includes("?") ? "&" : "?";
  return `${urlStr}${separator}_st=${encodeURIComponent(token)}`;
}

declare global {
  interface Window {
    __smpn1FetchPatched?: boolean;
  }
}

/**
 * Wraps `window.fetch` for all same-origin `/api/*` requests so every single call
 * carries the active session token simultaneously via:
 *   1. URL query parameter `?_st=<token>` (never stripped by proxies or iframes!)
 *   2. Header `X-Session-Token: <token>`
 *   3. Header `Authorization: Bearer <token>`
 *   4. Same-origin Cookies (`credentials: "include"`)
 */
export function installAuthFetchInterceptor(): void {
  if (typeof window === "undefined" || window.__smpn1FetchPatched) return;
  window.__smpn1FetchPatched = true;

  const originalFetch = window.fetch.bind(window);

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const rawUrl =
      typeof input === "string"
        ? input
        : input instanceof URL
        ? input.toString()
        : input.url;

    const isSameOriginApi =
      rawUrl.startsWith("/api/") ||
      (typeof window !== "undefined" &&
        rawUrl.startsWith(`${window.location.origin}/api/`));

    if (!isSameOriginApi) {
      return originalFetch(input, init);
    }

    const token = getStoredSessionToken();
    const finalUrl = token ? appendSessionTokenToApiUrl(rawUrl) : rawUrl;
    const headers = new Headers(init?.headers || {});

    if (token) {
      if (!headers.has("X-Session-Token")) {
        headers.set("X-Session-Token", token);
      }
      if (!headers.has("Authorization")) {
        headers.set("Authorization", `Bearer ${token}`);
      }
    }

    const response = await originalFetch(finalUrl, {
      ...init,
      credentials: init?.credentials || "include",
      headers,
    });

    if (rawUrl.includes("/api/auth/login") && response.ok) {
      try {
        const cloned = response.clone();
        const data = await cloned.json();
        if (data?.token) {
          setStoredSessionToken(data.token);
        }
      } catch {
        // ignore clone parse error
      }
    } else if (rawUrl.includes("/api/auth/logout")) {
      setStoredSessionToken(null);
    }

    return response;
  };
}

/**
 * Optimizes any user-selected logo file into a crisp, transparent-preserving PNG/SVG
 * Data URL (< ~150KB) so reverse proxies never reject large raw camera/desktop files.
 */
export async function optimizeLogoFileToDataUrl(file: File): Promise<string> {
  const nameLower = file.name.toLowerCase();

  if (
    (file.type === "image/svg+xml" || nameLower.endsWith(".svg")) &&
    file.size <= 512 * 1024
  ) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          const fixed = reader.result.startsWith("data:image/")
            ? reader.result
            : reader.result.replace(/^data:[^;]+;/, "data:image/svg+xml;");
          resolve(fixed);
        } else {
          reject(new Error("Gagal membaca file SVG."));
        }
      };
      reader.onerror = () => reject(new Error("Gagal membaca file SVG."));
      reader.readAsDataURL(file);
    });
  }

  const rawDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") resolve(reader.result);
      else reject(new Error("Gagal membaca file gambar."));
    };
    reader.onerror = () => reject(new Error("Gagal membaca file gambar."));
    reader.readAsDataURL(file);
  });

  return new Promise<string>((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      try {
        const MAX_DIM = 480;
        let width = img.naturalWidth || img.width || 256;
        let height = img.naturalHeight || img.height || 256;

        if (width > MAX_DIM || height > MAX_DIM) {
          if (width >= height) {
            height = Math.max(1, Math.round((height * MAX_DIM) / width));
            width = MAX_DIM;
          } else {
            width = Math.max(1, Math.round((width * MAX_DIM) / height));
            height = MAX_DIM;
          }
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(rawDataUrl);
          return;
        }
        ctx.clearRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const pngDataUrl = canvas.toDataURL("image/png");
        resolve(pngDataUrl);
      } catch {
        resolve(rawDataUrl);
      }
    };
    img.onerror = () =>
      reject(
        new Error(
          "Format file gambar tidak valid. Pilih file PNG, JPG, WEBP, SVG, atau ICO."
        )
      );
    img.src = rawDataUrl;
  });
}

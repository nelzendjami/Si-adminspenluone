import { db } from "@/db";
import {
  schoolSettings,
  teachers,
  schoolClasses,
  subjects,
  students,
  attendanceRecords,
  studentGrades,
  guidanceRecords,
  users,
  generateStudentBarcode,
  calculateGradeSummary,
} from "@/db/schema";
import { asc, sql } from "drizzle-orm";
import { hashPassword } from "./auth";

let initializationPromise: Promise<void> | null = null;

function formatDateOffset(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().slice(0, 10);
}

export async function ensureDatabaseReady(): Promise<void> {
  if (!initializationPromise) {
    initializationPromise = runInitialization().catch((err) => {
      initializationPromise = null;
      throw err;
    });
  }
  return initializationPromise;
}

async function runInitialization(): Promise<void> {
  // Ensure tables & columns exist idempotently even after schema upgrades
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS "school_settings" (
      "id" serial PRIMARY KEY NOT NULL,
      "school_name" text DEFAULT 'SMP Negeri 1 Umalulu' NOT NULL,
      "npsn" text DEFAULT '50303812' NOT NULL,
      "address" text DEFAULT 'Jl. Raya Melolo - Umalulu, Kec. Umalulu, Kab. Sumba Timur, Nusa Tenggara Timur' NOT NULL,
      "academic_year" text DEFAULT '2025/2026' NOT NULL,
      "semester" text DEFAULT 'Genap' NOT NULL,
      "principal_name" text DEFAULT 'Drs. Umbu Maramba Meha, M.Pd.' NOT NULL,
      "principal_nip" text DEFAULT '19690817 199512 1 003' NOT NULL,
      "email" text DEFAULT 'info@smpn1umalulu.sch.id' NOT NULL,
      "phone" text DEFAULT '(0387) 241088' NOT NULL,
      "logo_url" text DEFAULT '/images/logo-smpn1-umalulu.png' NOT NULL,
      "demo_seeded" boolean DEFAULT false NOT NULL,
      "updated_at" timestamp DEFAULT now() NOT NULL
    );

    ALTER TABLE "school_settings" ADD COLUMN IF NOT EXISTS "demo_seeded" boolean DEFAULT false NOT NULL;

    CREATE TABLE IF NOT EXISTS "teachers" (
      "id" serial PRIMARY KEY NOT NULL,
      "name" text NOT NULL,
      "nip" text NOT NULL,
      "subject" text NOT NULL,
      "employment_status" text DEFAULT 'PNS' NOT NULL,
      "phone" text DEFAULT '' NOT NULL,
      "is_active" boolean DEFAULT true NOT NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );

    CREATE TABLE IF NOT EXISTS "school_classes" (
      "id" serial PRIMARY KEY NOT NULL,
      "name" text NOT NULL UNIQUE,
      "grade_level" integer DEFAULT 7 NOT NULL,
      "room" text DEFAULT 'R-01' NOT NULL,
      "academic_year" text DEFAULT '2025/2026' NOT NULL,
      "capacity" integer DEFAULT 32 NOT NULL,
      "homeroom_teacher_id" integer UNIQUE REFERENCES "teachers"("id") ON DELETE SET NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );

    CREATE TABLE IF NOT EXISTS "subjects" (
      "id" serial PRIMARY KEY NOT NULL,
      "code" text NOT NULL UNIQUE,
      "name" text NOT NULL,
      "category" text DEFAULT 'Umum' NOT NULL,
      "kkm" integer DEFAULT 75 NOT NULL,
      "weekly_hours" integer DEFAULT 4 NOT NULL,
      "teacher_id" integer REFERENCES "teachers"("id") ON DELETE SET NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );

    ALTER TABLE "subjects" ADD COLUMN IF NOT EXISTS "category" text DEFAULT 'Umum' NOT NULL;
    ALTER TABLE "subjects" ADD COLUMN IF NOT EXISTS "kkm" integer DEFAULT 75 NOT NULL;
    ALTER TABLE "subjects" ADD COLUMN IF NOT EXISTS "weekly_hours" integer DEFAULT 4 NOT NULL;

    CREATE TABLE IF NOT EXISTS "students" (
      "id" serial PRIMARY KEY NOT NULL,
      "nisn" text NOT NULL UNIQUE,
      "nis" text DEFAULT '' NOT NULL,
      "barcode_code" text,
      "name" text NOT NULL,
      "gender" text DEFAULT 'L' NOT NULL,
      "class_id" integer NOT NULL REFERENCES "school_classes"("id") ON DELETE CASCADE,
      "birth_place" text DEFAULT 'Umalulu',
      "birth_date" text DEFAULT '',
      "parent_name" text DEFAULT '',
      "address" text DEFAULT 'Kec. Umalulu',
      "status" text DEFAULT 'Aktif' NOT NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );

    ALTER TABLE "students" ADD COLUMN IF NOT EXISTS "barcode_code" text;
    UPDATE "students" SET "barcode_code" = 'SMPN1UML-' || UPPER(TRIM("nisn")) WHERE "barcode_code" IS NULL OR "barcode_code" = '';
    ALTER TABLE "students" ALTER COLUMN "barcode_code" SET NOT NULL;
    DO $$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'students_barcode_code_unique') THEN
        ALTER TABLE "students" ADD CONSTRAINT "students_barcode_code_unique" UNIQUE ("barcode_code");
      END IF;
    END $$;

    CREATE TABLE IF NOT EXISTS "attendance_records" (
      "id" serial PRIMARY KEY NOT NULL,
      "student_id" integer NOT NULL REFERENCES "students"("id") ON DELETE CASCADE,
      "class_id" integer NOT NULL REFERENCES "school_classes"("id") ON DELETE CASCADE,
      "attendance_type" text NOT NULL,
      "subject_name" text DEFAULT 'Guru Wali' NOT NULL,
      "teacher_id" integer REFERENCES "teachers"("id") ON DELETE SET NULL,
      "date" text NOT NULL,
      "status" text NOT NULL,
      "notes" text DEFAULT '' NOT NULL,
      "recorded_by" text DEFAULT 'Admin Sistem' NOT NULL,
      "updated_at" timestamp DEFAULT now() NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS "attendance_unique_idx"
      ON "attendance_records" ("student_id", "date", "attendance_type", "subject_name");

    UPDATE "attendance_records"
      SET "subject_name" = 'Guru Wali'
      WHERE "attendance_type" = 'wali' AND "subject_name" = 'Wali Kelas';
    UPDATE "attendance_records"
      SET "recorded_by" = 'Guru Wali'
      WHERE "attendance_type" = 'wali' AND "recorded_by" = 'Wali Kelas';

    CREATE TABLE IF NOT EXISTS "student_grades" (
      "id" serial PRIMARY KEY NOT NULL,
      "student_id" integer NOT NULL REFERENCES "students"("id") ON DELETE CASCADE,
      "class_id" integer NOT NULL REFERENCES "school_classes"("id") ON DELETE CASCADE,
      "subject_id" integer NOT NULL REFERENCES "subjects"("id") ON DELETE CASCADE,
      "semester" text DEFAULT 'Genap' NOT NULL,
      "academic_year" text DEFAULT '2025/2026' NOT NULL,
      "assignment_score" integer DEFAULT 80 NOT NULL,
      "midterm_score" integer DEFAULT 80 NOT NULL,
      "final_score" integer DEFAULT 80 NOT NULL,
      "total_score" integer DEFAULT 80 NOT NULL,
      "predicate" text DEFAULT 'B' NOT NULL,
      "teacher_notes" text DEFAULT '' NOT NULL,
      "updated_by" text DEFAULT 'Guru Mapel' NOT NULL,
      "updated_at" timestamp DEFAULT now() NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS "student_grades_unique_idx"
      ON "student_grades" ("student_id", "subject_id", "semester", "academic_year");

    CREATE TABLE IF NOT EXISTS "guidance_records" (
      "id" serial PRIMARY KEY NOT NULL,
      "student_id" integer NOT NULL REFERENCES "students"("id") ON DELETE CASCADE,
      "class_id" integer NOT NULL REFERENCES "school_classes"("id") ON DELETE CASCADE,
      "guru_wali_id" integer REFERENCES "teachers"("id") ON DELETE SET NULL,
      "date" text NOT NULL,
      "category" text DEFAULT 'Akademik & Nilai' NOT NULL,
      "topic" text NOT NULL,
      "notes" text DEFAULT '' NOT NULL,
      "follow_up_plan" text DEFAULT '' NOT NULL,
      "parent_involved" boolean DEFAULT false NOT NULL,
      "status" text DEFAULT 'Dalam Pemantauan' NOT NULL,
      "created_by" text DEFAULT 'Guru Wali' NOT NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );

    CREATE TABLE IF NOT EXISTS "users" (
      "id" serial PRIMARY KEY NOT NULL,
      "username" text NOT NULL UNIQUE,
      "email" text NOT NULL UNIQUE,
      "password_hash" text NOT NULL,
      "full_name" text NOT NULL,
      "role" text DEFAULT 'admin' NOT NULL,
      "teacher_id" integer REFERENCES "teachers"("id") ON DELETE SET NULL,
      "assigned_class_id" integer REFERENCES "school_classes"("id") ON DELETE SET NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );

    CREATE TABLE IF NOT EXISTS "sessions" (
      "id" text PRIMARY KEY NOT NULL,
      "user_id" integer NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
      "expires_at" timestamp NOT NULL,
      "created_at" timestamp DEFAULT now() NOT NULL
    );
  `);

  const existingSettings = await db.select().from(schoolSettings).limit(1);
  if (existingSettings.length === 0) {
    // 1. Seed School Profile & Principal with NIP
    await db.insert(schoolSettings).values({
      schoolName: "SMP Negeri 1 Umalulu",
      npsn: "50303812",
      address:
        "Jl. Raya Melolo - Umalulu, Desa Watupuda, Kec. Umalulu, Kab. Sumba Timur, NTT 87182",
      academicYear: "2025/2026",
      semester: "Genap",
      principalName: "Drs. Umbu Maramba Meha, M.Pd.",
      principalNip: "19690817 199512 1 003",
      email: "info@smpn1umalulu.sch.id",
      phone: "(0387) 241088",
      logoUrl: "/images/logo-smpn1-umalulu.png",
    });

    // 2. Seed Teachers (Guru Mapel & Guru Wali beserta NIP)
    const insertedTeachers = await db
      .insert(teachers)
      .values([
        {
          name: "Maria Rambu Kahi, S.Pd.",
          nip: "19840412 200904 2 006",
          subject: "Matematika",
          employmentStatus: "PNS",
          phone: "0812-3910-4412",
        },
        {
          name: "Yohanes Umbu Nay, S.Pd.",
          nip: "19821105 200801 1 009",
          subject: "Bahasa Indonesia",
          employmentStatus: "PNS",
          phone: "0813-3922-8105",
        },
        {
          name: "Agustina Rambu Danga, S.Pd., Gr.",
          nip: "19880821 201403 2 004",
          subject: "IPA Terpadu",
          employmentStatus: "PNS",
          phone: "0821-4608-2188",
        },
        {
          name: "Kornelis Ndawa Luji, S.Pd.",
          nip: "19860319 201101 1 007",
          subject: "Bahasa Inggris",
          employmentStatus: "PNS",
          phone: "0812-3891-0319",
        },
        {
          name: "Fransiska Rambu Ata, S.Pd.",
          nip: "19900614 201903 2 011",
          subject: "IPS Terpadu",
          employmentStatus: "PNS",
          phone: "0852-3940-0614",
        },
        {
          name: "Dominggus Hina Kondanamu, S.Pd.",
          nip: "19920228 202221 1 005",
          subject: "PPKn",
          employmentStatus: "PPPK",
          phone: "0822-3711-0228",
        },
        {
          name: "Petrus Umbu Lado, S.Pd.",
          nip: "19940910 202321 1 008",
          subject: "PJOK",
          employmentStatus: "PPPK",
          phone: "0813-3877-0910",
        },
        {
          name: "Veronika Rambu Ngana, S.Kom.",
          nip: "19960503 202421 2 012",
          subject: "Informatika",
          employmentStatus: "PPPK",
          phone: "0821-4455-0503",
        },
      ])
      .returning();

    // 3. Seed Classes (1 Guru Wali strictly assigned to 1 Kelas Saja)
    const insertedClasses = await db
      .insert(schoolClasses)
      .values([
        {
          name: "VII-A",
          gradeLevel: 7,
          room: "Gedung A - R.01",
          academicYear: "2025/2026",
          capacity: 30,
          homeroomTeacherId: insertedTeachers[0].id,
        },
        {
          name: "VII-B",
          gradeLevel: 7,
          room: "Gedung A - R.02",
          academicYear: "2025/2026",
          capacity: 30,
          homeroomTeacherId: insertedTeachers[1].id,
        },
        {
          name: "VIII-A",
          gradeLevel: 8,
          room: "Gedung B - R.03",
          academicYear: "2025/2026",
          capacity: 32,
          homeroomTeacherId: insertedTeachers[2].id,
        },
        {
          name: "VIII-B",
          gradeLevel: 8,
          room: "Gedung B - R.04",
          academicYear: "2025/2026",
          capacity: 32,
          homeroomTeacherId: insertedTeachers[3].id,
        },
        {
          name: "IX-A",
          gradeLevel: 9,
          room: "Gedung C - R.05",
          academicYear: "2025/2026",
          capacity: 32,
          homeroomTeacherId: insertedTeachers[4].id,
        },
        {
          name: "IX-B",
          gradeLevel: 9,
          room: "Gedung C - R.06",
          academicYear: "2025/2026",
          capacity: 32,
          homeroomTeacherId: insertedTeachers[5].id,
        },
      ])
      .returning();

    // 4. Seed Subjects with KKM & JP
    await db.insert(subjects).values([
      {
        code: "MTK",
        name: "Matematika",
        category: "Umum",
        kkm: 75,
        weeklyHours: 5,
        teacherId: insertedTeachers[0].id,
      },
      {
        code: "BIN",
        name: "Bahasa Indonesia",
        category: "Umum",
        kkm: 75,
        weeklyHours: 6,
        teacherId: insertedTeachers[1].id,
      },
      {
        code: "IPA",
        name: "IPA Terpadu",
        category: "Umum",
        kkm: 75,
        weeklyHours: 5,
        teacherId: insertedTeachers[2].id,
      },
      {
        code: "BIG",
        name: "Bahasa Inggris",
        category: "Umum",
        kkm: 75,
        weeklyHours: 4,
        teacherId: insertedTeachers[3].id,
      },
      {
        code: "IPS",
        name: "IPS Terpadu",
        category: "Umum",
        kkm: 75,
        weeklyHours: 4,
        teacherId: insertedTeachers[4].id,
      },
      {
        code: "PKN",
        name: "PPKn",
        category: "Umum",
        kkm: 78,
        weeklyHours: 3,
        teacherId: insertedTeachers[5].id,
      },
      {
        code: "PJOK",
        name: "PJOK",
        category: "Umum",
        kkm: 78,
        weeklyHours: 3,
        teacherId: insertedTeachers[6].id,
      },
      {
        code: "INF",
        name: "Informatika",
        category: "Pilihan",
        kkm: 75,
        weeklyHours: 3,
        teacherId: insertedTeachers[7].id,
      },
    ]);

    // 5. Seed Authentic Sumba Timur Students
    const studentSeedList = [
      {
        nisn: "0118421001",
        nis: "2501",
        name: "Umbu Raka Pratama",
        gender: "L",
        classIdx: 0,
        birthPlace: "Umalulu",
        birthDate: "2012-04-14",
        parentName: "Umbu Ndilu",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0118421002",
        nis: "2502",
        name: "Rambu Naha Hawu",
        gender: "P",
        classIdx: 0,
        birthPlace: "Melolo",
        birthDate: "2012-08-22",
        parentName: "Yohanis Hawu",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0118421003",
        nis: "2503",
        name: "Dionisius Umbu Meha",
        gender: "L",
        classIdx: 0,
        birthPlace: "Umalulu",
        birthDate: "2012-02-09",
        parentName: "Marthen Meha",
        address: "Desa Matawai Atu, Umalulu",
      },
      {
        nisn: "0118421004",
        nis: "2504",
        name: "Mersiana Rambu Kudu",
        gender: "P",
        classIdx: 0,
        birthPlace: "Waingapu",
        birthDate: "2012-11-03",
        parentName: "Kornelis Kudu",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0118421005",
        nis: "2505",
        name: "Yulius Ndilu Hamandika",
        gender: "L",
        classIdx: 0,
        birthPlace: "Pau",
        birthDate: "2012-06-18",
        parentName: "Lukas Hamandika",
        address: "Desa Umalulu",
      },
      {
        nisn: "0118421006",
        nis: "2506",
        name: "Teresia Rambu Wandal",
        gender: "P",
        classIdx: 0,
        birthPlace: "Umalulu",
        birthDate: "2012-09-27",
        parentName: "Paulus Wandal",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0118421007",
        nis: "2507",
        name: "Kristoforus Umbu Hunga",
        gender: "L",
        classIdx: 1,
        birthPlace: "Umalulu",
        birthDate: "2012-03-11",
        parentName: "Daniel Hunga",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0118421008",
        nis: "2508",
        name: "Clarissa Rambu Bana",
        gender: "P",
        classIdx: 1,
        birthPlace: "Melolo",
        birthDate: "2012-07-19",
        parentName: "Stefanus Bana",
        address: "Desa Patawang, Umalulu",
      },
      {
        nisn: "0118421009",
        nis: "2509",
        name: "Oktavianus Ndawa",
        gender: "L",
        classIdx: 1,
        birthPlace: "Umalulu",
        birthDate: "2012-10-08",
        parentName: "Hendrikus Ndawa",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0118421010",
        nis: "2510",
        name: "Febriani Rambu Leki",
        gender: "P",
        classIdx: 1,
        birthPlace: "Waingapu",
        birthDate: "2012-02-24",
        parentName: "Yakobus Leki",
        address: "Desa Umalulu",
      },
      {
        nisn: "0118421011",
        nis: "2511",
        name: "Samuel Umbu Tapa",
        gender: "L",
        classIdx: 1,
        birthPlace: "Umalulu",
        birthDate: "2012-05-30",
        parentName: "Matias Tapa",
        address: "Desa Watuhadang, Umalulu",
      },
      {
        nisn: "0118421012",
        nis: "2512",
        name: "Angelina Rambu Mbani",
        gender: "P",
        classIdx: 1,
        birthPlace: "Umalulu",
        birthDate: "2012-12-15",
        parentName: "Simson Mbani",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0107312001",
        nis: "2401",
        name: "Alfonsus Umbu Awang",
        gender: "L",
        classIdx: 2,
        birthPlace: "Umalulu",
        birthDate: "2011-01-16",
        parentName: "Tomas Awang",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0107312002",
        nis: "2402",
        name: "Margaretha Rambu Paji",
        gender: "P",
        classIdx: 2,
        birthPlace: "Melolo",
        birthDate: "2011-05-04",
        parentName: "Nikolaus Paji",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0107312003",
        nis: "2403",
        name: "Gilbertus Hina",
        gender: "L",
        classIdx: 2,
        birthPlace: "Umalulu",
        birthDate: "2011-08-12",
        parentName: "Anderias Hina",
        address: "Desa Ngaru Kanoru, Umalulu",
      },
      {
        nisn: "0107312004",
        nis: "2404",
        name: "Natalia Rambu Day",
        gender: "P",
        classIdx: 2,
        birthPlace: "Waingapu",
        birthDate: "2011-12-25",
        parentName: "Filipus Day",
        address: "Desa Umalulu",
      },
      {
        nisn: "0107312005",
        nis: "2405",
        name: "Hendrik Umbu Katanga",
        gender: "L",
        classIdx: 2,
        birthPlace: "Umalulu",
        birthDate: "2011-04-02",
        parentName: "Barnabas Katanga",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0107312006",
        nis: "2406",
        name: "Lidwina Rambu Nggik",
        gender: "P",
        classIdx: 2,
        birthPlace: "Umalulu",
        birthDate: "2011-09-19",
        parentName: "Ruben Nggik",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0107312007",
        nis: "2407",
        name: "Emanuel Umbu Deta",
        gender: "L",
        classIdx: 3,
        birthPlace: "Melolo",
        birthDate: "2011-03-21",
        parentName: "Gideon Deta",
        address: "Desa Patawang, Umalulu",
      },
      {
        nisn: "0107312008",
        nis: "2408",
        name: "Yosefina Rambu Chika",
        gender: "P",
        classIdx: 3,
        birthPlace: "Umalulu",
        birthDate: "2011-07-07",
        parentName: "Markus Chika",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0107312009",
        nis: "2409",
        name: "Rivaldo Ndima",
        gender: "L",
        classIdx: 3,
        birthPlace: "Umalulu",
        birthDate: "2011-11-14",
        parentName: "Yusuf Ndima",
        address: "Desa Watuhadang, Umalulu",
      },
      {
        nisn: "0107312010",
        nis: "2410",
        name: "Sesilia Rambu Intan",
        gender: "P",
        classIdx: 3,
        birthPlace: "Waingapu",
        birthDate: "2011-06-29",
        parentName: "Antonius Intan",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0107312011",
        nis: "2411",
        name: "Marianus Umbu Nggaba",
        gender: "L",
        classIdx: 3,
        birthPlace: "Umalulu",
        birthDate: "2011-02-13",
        parentName: "Zakarias Nggaba",
        address: "Desa Umalulu",
      },
      {
        nisn: "0107312012",
        nis: "2412",
        name: "Katarina Rambu Sari",
        gender: "P",
        classIdx: 3,
        birthPlace: "Umalulu",
        birthDate: "2011-10-20",
        parentName: "Benyamin Sari",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0096203001",
        nis: "2301",
        name: "Valentinus Umbu Windi",
        gender: "L",
        classIdx: 4,
        birthPlace: "Umalulu",
        birthDate: "2010-02-14",
        parentName: "Kristian Windi",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0096203002",
        nis: "2302",
        name: "Rosalina Rambu Hana",
        gender: "P",
        classIdx: 4,
        birthPlace: "Melolo",
        birthDate: "2010-05-18",
        parentName: "Daud Hana",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0096203003",
        nis: "2303",
        name: "Ardiansyah Umbu Pekambani",
        gender: "L",
        classIdx: 4,
        birthPlace: "Umalulu",
        birthDate: "2010-08-03",
        parentName: "Ibrahim Pekambani",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0096203004",
        nis: "2304",
        name: "Nadia Putri Rambu",
        gender: "P",
        classIdx: 4,
        birthPlace: "Waingapu",
        birthDate: "2010-11-28",
        parentName: "Ridwan",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0096203005",
        nis: "2305",
        name: "Leonardus Umbu Pati",
        gender: "L",
        classIdx: 4,
        birthPlace: "Umalulu",
        birthDate: "2010-04-09",
        parentName: "Gregorius Pati",
        address: "Desa Umalulu",
      },
      {
        nisn: "0096203006",
        nis: "2306",
        name: "Graciela Rambu Lika",
        gender: "P",
        classIdx: 4,
        birthPlace: "Umalulu",
        birthDate: "2010-09-12",
        parentName: "Samuel Lika",
        address: "Desa Matawai Atu, Umalulu",
      },
      {
        nisn: "0096203007",
        nis: "2307",
        name: "Benediktus Umbu Kudu",
        gender: "L",
        classIdx: 5,
        birthPlace: "Umalulu",
        birthDate: "2010-01-23",
        parentName: "Yosef Kudu",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0096203008",
        nis: "2308",
        name: "Melania Rambu Djuka",
        gender: "P",
        classIdx: 5,
        birthPlace: "Melolo",
        birthDate: "2010-06-06",
        parentName: "Petrus Djuka",
        address: "Desa Watupuda, Umalulu",
      },
      {
        nisn: "0096203009",
        nis: "2309",
        name: "Ferdinandus Ndapamerang",
        gender: "L",
        classIdx: 5,
        birthPlace: "Umalulu",
        birthDate: "2010-10-17",
        parentName: "Umbu Ndapamerang",
        address: "Desa Wanga, Umalulu",
      },
      {
        nisn: "0096203010",
        nis: "2310",
        name: "Veronika Rambu Kasih",
        gender: "P",
        classIdx: 5,
        birthPlace: "Waingapu",
        birthDate: "2010-03-30",
        parentName: "Yohanes Kasih",
        address: "Desa Umalulu",
      },
      {
        nisn: "0096203011",
        nis: "2311",
        name: "Rikardus Umbu Mada",
        gender: "L",
        classIdx: 5,
        birthPlace: "Umalulu",
        birthDate: "2010-07-21",
        parentName: "Titus Mada",
        address: "Kel. Lumbukore, Umalulu",
      },
      {
        nisn: "0096203012",
        nis: "2312",
        name: "Desiana Rambu Ata",
        gender: "P",
        classIdx: 5,
        birthPlace: "Umalulu",
        birthDate: "2010-12-08",
        parentName: "Soleman Ata",
        address: "Desa Watupuda, Umalulu",
      },
    ];

    const insertedStudents = await db
      .insert(students)
      .values(
        studentSeedList.map((s) => ({
          nisn: s.nisn,
          nis: s.nis,
          barcodeCode: generateStudentBarcode(s.nisn),
          name: s.name.trim(),
          gender: s.gender,
          classId: insertedClasses[s.classIdx].id,
          birthPlace: s.birthPlace,
          birthDate: s.birthDate,
          parentName: s.parentName.trim(),
          address: s.address,
          status: "Aktif",
        }))
      )
      .returning();

    // 6. Seed Accounts
    const adminHash = await hashPassword("admin123");
    const guruHash = await hashPassword("guru123");

    await db.insert(users).values([
      {
        username: "admin",
        email: "admin@smpn1umalulu.sch.id",
        passwordHash: adminHash,
        fullName: "Admin Pribadi SMPN 1 Umalulu",
        role: "admin",
        teacherId: null,
        assignedClassId: null,
      },
      {
        username: "wali7a",
        email: "wali7a@smpn1umalulu.sch.id",
        passwordHash: guruHash,
        fullName: "Maria Rambu Kahi, S.Pd.",
        role: "wali_kelas",
        teacherId: insertedTeachers[0].id,
        assignedClassId: insertedClasses[0].id,
      },
      {
        username: "wali8a",
        email: "wali8a@smpn1umalulu.sch.id",
        passwordHash: guruHash,
        fullName: "Agustina Rambu Danga, S.Pd., Gr.",
        role: "wali_kelas",
        teacherId: insertedTeachers[2].id,
        assignedClassId: insertedClasses[2].id,
      },
      {
        username: "mapel",
        email: "mapel@smpn1umalulu.sch.id",
        passwordHash: guruHash,
        fullName: "Petrus Umbu Lado, S.Pd.",
        role: "guru_mapel",
        teacherId: insertedTeachers[6].id,
        assignedClassId: null,
      },
    ]);

    // 7. Seed Realistic Attendance Records
    const dates = [
      formatDateOffset(4),
      formatDateOffset(3),
      formatDateOffset(2),
      formatDateOffset(1),
      formatDateOffset(0),
    ];

    const attendanceBatch: Array<{
      studentId: number;
      classId: number;
      attendanceType: string;
      subjectName: string;
      teacherId: number | null;
      date: string;
      status: string;
      notes: string;
      recordedBy: string;
    }> = [];

    const pickStatus = (studentIdx: number, dayIdx: number, salt: number) => {
      const hash = (studentIdx * 13 + dayIdx * 7 + salt * 5) % 24;
      if (hash === 3) return { status: "S", notes: "Demam / Istirahat rumah" };
      if (hash === 9) return { status: "I", notes: "Izin kegiatan keluarga" };
      if (hash === 17) return { status: "A", notes: "Tanpa keterangan" };
      return { status: "H", notes: "" };
    };

    dates.forEach((dt, dayIdx) => {
      insertedStudents.forEach((stu, stuIdx) => {
        const cls = insertedClasses.find((c) => c.id === stu.classId)!;

        const waliStatus = pickStatus(stuIdx, dayIdx, 1);
        attendanceBatch.push({
          studentId: stu.id,
          classId: stu.classId,
          attendanceType: "wali",
          subjectName: "Guru Wali",
          teacherId: cls.homeroomTeacherId,
          date: dt,
          status: waliStatus.status,
          notes: waliStatus.notes,
          recordedBy: "Guru Wali",
        });

        const mtkStatus = pickStatus(stuIdx, dayIdx, 2);
        attendanceBatch.push({
          studentId: stu.id,
          classId: stu.classId,
          attendanceType: "mapel",
          subjectName: "Matematika",
          teacherId: insertedTeachers[0].id,
          date: dt,
          status: mtkStatus.status,
          notes: mtkStatus.notes,
          recordedBy: insertedTeachers[0].name,
        });

        const binStatus = pickStatus(stuIdx, dayIdx, 4);
        attendanceBatch.push({
          studentId: stu.id,
          classId: stu.classId,
          attendanceType: "mapel",
          subjectName: "Bahasa Indonesia",
          teacherId: insertedTeachers[1].id,
          date: dt,
          status: binStatus.status,
          notes: binStatus.notes,
          recordedBy: insertedTeachers[1].name,
        });
      });
    });

    if (attendanceBatch.length > 0) {
      await db.insert(attendanceRecords).values(attendanceBatch);
    }
  }

  const currentSettingsRows = await db.select().from(schoolSettings).limit(1);
  if (currentSettingsRows[0]?.demoSeeded) {
    return;
  }

  // 8. Seed Subject Grades (Daftar Nilai Per Mapel) idempotently on first setup
  const existingGrades = await db.select().from(studentGrades).limit(1);
  if (existingGrades.length === 0) {
    const [allStudents, allSubjects, allTeachers] = await Promise.all([
      db.select().from(students).orderBy(asc(students.id)),
      db.select().from(subjects).orderBy(asc(subjects.id)),
      db.select().from(teachers),
    ]);

    const gradesBatch: Array<{
      studentId: number;
      classId: number;
      subjectId: number;
      semester: string;
      academicYear: string;
      assignmentScore: number;
      midtermScore: number;
      finalScore: number;
      totalScore: number;
      predicate: string;
      teacherNotes: string;
      updatedBy: string;
    }> = [];

    allStudents.forEach((stu, stuIdx) => {
      allSubjects.forEach((subj, subjIdx) => {
        const seed = (stuIdx * 11 + subjIdx * 7) % 19;
        // Generate realistic scores across 68 - 96 so some students need Guru Wali guidance (<75) while most excel
        const base =
          seed === 2
            ? 69
            : seed === 11
            ? 72
            : 76 + ((stuIdx * 5 + subjIdx * 3) % 19);
        const assignmentScore = Math.min(98, base + 3);
        const midtermScore = Math.max(62, base - 2);
        const finalScore = Math.min(97, base + 1);
        const { totalScore, predicate } = calculateGradeSummary(
          assignmentScore,
          midtermScore,
          finalScore
        );
        const subjTeacher = allTeachers.find((t) => t.id === subj.teacherId);

        gradesBatch.push({
          studentId: stu.id,
          classId: stu.classId,
          subjectId: subj.id,
          semester: "Genap",
          academicYear: "2025/2026",
          assignmentScore,
          midtermScore,
          finalScore,
          totalScore,
          predicate,
          teacherNotes:
            totalScore < subj.kkm
              ? "Perlu pendampingan remedial & pantauan Guru Wali"
              : totalScore >= 90
              ? "Capaian kompetensi sangat baik & aktif"
              : "Tuntas sesuai KKTP",
          updatedBy: subjTeacher?.name || "Guru Mata Pelajaran",
        });
      });
    });

    if (gradesBatch.length > 0) {
      await db.insert(studentGrades).values(gradesBatch);
    }
  }

  // 9. Seed Guidance Records (Bimbingan Anak Wali) idempotently if empty
  const existingGuidance = await db.select().from(guidanceRecords).limit(1);
  if (existingGuidance.length === 0) {
    const [allClasses, allStudents, allTeachers] = await Promise.all([
      db.select().from(schoolClasses).orderBy(asc(schoolClasses.id)),
      db.select().from(students).orderBy(asc(students.id)),
      db.select().from(teachers),
    ]);

    const guidanceSeeds: Array<{
      studentId: number;
      classId: number;
      guruWaliId: number | null;
      date: string;
      category: string;
      topic: string;
      notes: string;
      followUpPlan: string;
      parentInvolved: boolean;
      status: string;
      createdBy: string;
    }> = [];

    const templates = [
      {
        category: "Akademik & Nilai",
        topic: "Pendampingan Peningkatan Nilai Matematika & IPA",
        notes:
          "Anak wali menunjukkan semangat belajar namun masih kesulitan pada materi soal cerita dan latihan mandiri.",
        followUpPlan:
          "Jadwal belajar kelompok 2x seminggu dan koordinasi remedial bersama Guru Mapel.",
        parentInvolved: true,
        status: "Dalam Pemantauan",
      },
      {
        category: "Kedisiplinan & Kehadiran",
        topic: "Pembinaan Ketepatan Waktu Hadir Pagi",
        notes:
          "Terlambat hadir dua kali karena jarak tempuh dari Desa Watupuda saat hujan pagi.",
        followUpPlan:
          "Komunikasi dengan orang tua agar berangkat 15 menit lebih awal.",
        parentInvolved: true,
        status: "Perlu Tindak Lanjut",
      },
      {
        category: "Minat, Bakat & Karir",
        topic: "Pengembangan Prestasi OSN & Ekstrakurikuler",
        notes:
          "Memiliki rata-rata nilai rapor di atas 88 dan antusias mengikuti seleksi lomba akademik tingkat kabupaten.",
        followUpPlan:
          "Rekomendasi pembinaan intensif bersama Guru Mapel pembina.",
        parentInvolved: false,
        status: "Tuntas",
      },
    ];

    allClasses.forEach((cls, clsIdx) => {
      const clsStudents = allStudents.filter((s) => s.classId === cls.id);
      const gw = allTeachers.find((t) => t.id === cls.homeroomTeacherId);
      if (clsStudents[0]) {
        const tpl = templates[clsIdx % templates.length];
        guidanceSeeds.push({
          studentId: clsStudents[0].id,
          classId: cls.id,
          guruWaliId: cls.homeroomTeacherId,
          date: formatDateOffset(clsIdx % 4),
          category: tpl.category,
          topic: tpl.topic,
          notes: tpl.notes,
          followUpPlan: tpl.followUpPlan,
          parentInvolved: tpl.parentInvolved,
          status: tpl.status,
          createdBy: gw?.name || "Guru Wali",
        });
      }
      if (clsStudents[2]) {
        const tpl2 = templates[(clsIdx + 1) % templates.length];
        guidanceSeeds.push({
          studentId: clsStudents[2].id,
          classId: cls.id,
          guruWaliId: cls.homeroomTeacherId,
          date: formatDateOffset((clsIdx + 1) % 4),
          category: tpl2.category,
          topic: tpl2.topic,
          notes: tpl2.notes,
          followUpPlan: tpl2.followUpPlan,
          parentInvolved: tpl2.parentInvolved,
          status: tpl2.status,
          createdBy: gw?.name || "Guru Wali",
        });
      }
    });

    if (guidanceSeeds.length > 0) {
      await db.insert(guidanceRecords).values(guidanceSeeds);
    }
  }

  await db.execute(
    sql`UPDATE "school_settings" SET "demo_seeded" = true WHERE "demo_seeded" = false`
  );
}

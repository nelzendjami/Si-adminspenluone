import { cookies, headers } from "next/headers";
import crypto from "crypto";
import bcrypt from "bcryptjs";
import { db } from "@/db";
import { sessions, users, schoolClasses, teachers } from "@/db/schema";
import { eq, gt, and } from "drizzle-orm";

export const SESSION_COOKIE_NAME = "smpn1_umalulu_session";
const SESSION_DURATION_MS = 1000 * 60 * 60 * 24 * 30; // 30 days

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export interface SessionUser {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: "admin" | "wali_kelas" | "guru_mapel";
  teacherId: number | null;
  teacherNip: string | null;
  teacherSubject: string | null;
  assignedClassId: number | null;
  assignedClassName: string | null;
}

async function isHttpsRequest(request?: Request): Promise<boolean> {
  try {
    if (request) {
      const fwdProto = request.headers.get("x-forwarded-proto");
      if (fwdProto) return fwdProto.split(",")[0].trim() === "https";
      return request.url.startsWith("https://");
    }
    const hdrs = await headers();
    const fwdProto = hdrs.get("x-forwarded-proto");
    if (fwdProto) return fwdProto.split(",")[0].trim() === "https";
    return false;
  } catch {
    return false;
  }
}

export async function extractSessionToken(
  request?: Request,
  explicitToken?: string | null
): Promise<string | null> {
  if (explicitToken && explicitToken.trim()) {
    return explicitToken.trim();
  }

  // 1. Direct extraction from incoming Request URL query param `?_st=` or headers
  if (request) {
    try {
      const parsedUrl = new URL(request.url, "http://localhost");
      const queryToken = parsedUrl.searchParams.get("_st");
      if (queryToken && queryToken.trim()) {
        return queryToken.trim();
      }
    } catch {
      // ignore invalid URL parse
    }

    const customHdr = request.headers.get("x-session-token");
    if (customHdr && customHdr.trim()) {
      return customHdr.trim();
    }

    const authHdr = request.headers.get("authorization") || "";
    if (authHdr.toLowerCase().startsWith("bearer ")) {
      const bearer = authHdr.slice(7).trim();
      if (bearer) return bearer;
    }
  }

  // 2. Next.js request headers() context fallback
  try {
    const hdrs = await headers();
    const customHdr = hdrs.get("x-session-token");
    if (customHdr && customHdr.trim()) {
      return customHdr.trim();
    }
    const authHdr = hdrs.get("authorization") || "";
    if (authHdr.toLowerCase().startsWith("bearer ")) {
      const bearer = authHdr.slice(7).trim();
      if (bearer) return bearer;
    }
  } catch {
    // outside request header context
  }

  // 3. Standard HTTP-only Cookie fallback
  try {
    const cookieStore = await cookies();
    const cookieVal = cookieStore.get(SESSION_COOKIE_NAME)?.value;
    if (cookieVal && cookieVal.trim()) {
      return cookieVal.trim();
    }
  } catch {
    // outside cookie context
  }

  return null;
}

export async function createSession(
  userId: number,
  request?: Request
): Promise<string> {
  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DURATION_MS);

  await db.insert(sessions).values({
    id: token,
    userId,
    expiresAt,
  });

  try {
    const https = await isHttpsRequest(request);
    const cookieStore = await cookies();
    cookieStore.set(SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      path: "/",
      sameSite: https ? "none" : "lax",
      secure: https,
      partitioned: https,
      maxAge: Math.floor(SESSION_DURATION_MS / 1000),
    });
  } catch {
    // Token still returned & active in PostgreSQL even if cookie write is restricted
  }

  return token;
}

export async function destroySession(request?: Request): Promise<void> {
  const targetToken = await extractSessionToken(request);
  if (targetToken) {
    await db.delete(sessions).where(eq(sessions.id, targetToken));
  }
  try {
    const cookieStore = await cookies();
    cookieStore.delete(SESSION_COOKIE_NAME);
  } catch {
    // ignore
  }
}

export async function getCurrentUser(
  request?: Request,
  explicitToken?: string | null
): Promise<SessionUser | null> {
  try {
    const token = await extractSessionToken(request, explicitToken);
    if (!token) return null;

    const now = new Date();
    const foundSessions = await db
      .select()
      .from(sessions)
      .where(and(eq(sessions.id, token), gt(sessions.expiresAt, now)))
      .limit(1);

    if (foundSessions.length === 0) {
      return null;
    }

    const foundUsers = await db
      .select()
      .from(users)
      .where(eq(users.id, foundSessions[0].userId))
      .limit(1);

    if (foundUsers.length === 0) return null;
    const u = foundUsers[0];

    let assignedClassId = u.assignedClassId;
    let assignedClassName: string | null = null;
    let teacherNip: string | null = null;
    let teacherSubject: string | null = null;

    if (u.teacherId) {
      const tRows = await db
        .select()
        .from(teachers)
        .where(eq(teachers.id, u.teacherId))
        .limit(1);
      if (tRows[0]) {
        teacherNip = tRows[0].nip;
        teacherSubject = tRows[0].subject;
      }

      const cRows = await db
        .select()
        .from(schoolClasses)
        .where(eq(schoolClasses.homeroomTeacherId, u.teacherId))
        .limit(1);
      if (cRows[0]) {
        assignedClassId = cRows[0].id;
        assignedClassName = cRows[0].name;
      }
    }

    if (assignedClassId && !assignedClassName) {
      const cRows = await db
        .select()
        .from(schoolClasses)
        .where(eq(schoolClasses.id, assignedClassId))
        .limit(1);
      if (cRows[0]) {
        assignedClassName = cRows[0].name;
      }
    }

    return {
      id: u.id,
      username: u.username,
      email: u.email,
      fullName: u.fullName,
      role: (u.role as SessionUser["role"]) || "admin",
      teacherId: u.teacherId,
      teacherNip,
      teacherSubject,
      assignedClassId,
      assignedClassName,
    };
  } catch {
    return null;
  }
}

"use client";

import React, { useEffect, useRef, useState } from "react";
import JsBarcode from "jsbarcode";
import QRCode from "qrcode";
import { Download, RefreshCw, ScanLine } from "lucide-react";
import { SchoolSettingsData, StudentItem } from "@/types/school";

interface StudentBarcodeCardProps {
  student: StudentItem;
  settings: SchoolSettingsData;
  onQuickScan?: (barcodeCode: string) => void;
  onRegenerate?: (student: StudentItem) => void;
  compact?: boolean;
}

export default function StudentBarcodeCard({
  student,
  settings,
  onQuickScan,
  onRegenerate,
  compact = false,
}: StudentBarcodeCardProps) {
  const barcodeSvgRef = useRef<SVGSVGElement | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>("");

  const codeValue = student.barcodeCode || `SMPN1UML-${student.nisn}`;

  useEffect(() => {
    if (barcodeSvgRef.current) {
      try {
        JsBarcode(barcodeSvgRef.current, codeValue, {
          format: "CODE128",
          lineColor: "#0f172a",
          background: "#ffffff",
          width: compact ? 1.4 : 1.65,
          height: compact ? 38 : 46,
          displayValue: true,
          fontSize: 12,
          fontOptions: "bold",
          margin: 4,
        });
      } catch {
        // ignore invalid chars fallback
      }
    }

    QRCode.toDataURL(codeValue, {
      margin: 1,
      width: 140,
      color: { dark: "#0f172a", light: "#ffffff" },
    })
      .then((url) => setQrDataUrl(url))
      .catch(() => {});
  }, [codeValue, compact]);

  async function handleDownloadCardPng() {
    const canvas = document.createElement("canvas");
    canvas.width = 720;
    canvas.height = 420;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // White Card Background + Border
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Royal Blue Header Banner
    ctx.fillStyle = "#1d4ed8";
    ctx.fillRect(0, 0, canvas.width, 86);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 22px sans-serif";
    ctx.fillText(settings.schoolName.toUpperCase(), 28, 40);
    ctx.font = "600 13px sans-serif";
    ctx.fillStyle = "#dbeafe";
    ctx.fillText(
      `KARTU ABSENSI BARCODE SISWA • NPSN ${settings.npsn}`,
      28,
      64
    );

    // Student Identity Details
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 24px sans-serif";
    ctx.fillText(student.name, 28, 134);

    ctx.font = "600 15px monospace";
    ctx.fillStyle = "#334155";
    ctx.fillText(
      `NISN: ${student.nisn}   |   NIS: ${student.nis || "-"}   |   KELAS: ${
        student.className
      }`,
      28,
      166
    );

    // Generate 1D Barcode onto temporary canvas
    const tempBarcodeCanvas = document.createElement("canvas");
    JsBarcode(tempBarcodeCanvas, codeValue, {
      format: "CODE128",
      lineColor: "#000000",
      background: "#ffffff",
      width: 2.2,
      height: 85,
      displayValue: true,
      fontSize: 16,
      fontOptions: "bold",
      margin: 10,
    });
    ctx.drawImage(tempBarcodeCanvas, 24, 215, 450, 155);

    // Draw high-contrast QR Code on the right side for ultra-fast decoding
    const qrHighRes = await QRCode.toDataURL(codeValue, {
      margin: 2,
      width: 190,
      color: { dark: "#000000", light: "#ffffff" },
    });
    const qrImg = new Image();
    qrImg.src = qrHighRes;
    await new Promise((resolve) => {
      qrImg.onload = resolve;
      qrImg.onerror = resolve;
    });
    ctx.drawImage(qrImg, 505, 195, 185, 185);

    // Outer subtle border
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 3;
    ctx.strokeRect(1.5, 1.5, canvas.width - 3, canvas.height - 3);

    const link = document.createElement("a");
    link.download = `Kartu_Barcode_${student.className}_${student.name.replace(
      /\s+/g,
      "_"
    )}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col justify-between break-inside-avoid print:border-slate-400">
      {/* Official School Card Header */}
      <div className="bg-gradient-to-r from-blue-700 to-blue-800 px-4 py-3 text-white flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <img
            src={settings.logoUrl || "/images/logo-smpn1-umalulu.png"}
            alt="Logo"
            className="w-8 h-8 rounded-lg bg-white p-1 object-contain shrink-0"
          />
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-wider text-blue-200 leading-none">
              Kartu Absensi Barcode
            </p>
            <p className="text-xs font-extrabold truncate mt-0.5">
              {settings.schoolName}
            </p>
          </div>
        </div>
        <span className="px-2.5 py-0.5 rounded-md bg-white/15 border border-white/25 text-[11px] font-extrabold shrink-0">
          {student.className}
        </span>
      </div>

      {/* Student Details + Generated 1D Barcode & 2D QR Code */}
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-slate-900 truncate">
              {student.name}
            </h3>
            <p className="font-mono-code text-xs text-slate-600 mt-0.5">
              NISN: <strong>{student.nisn}</strong> • NIS:{" "}
              {student.nis || "-"}
            </p>
          </div>
          <span
            className={`px-2 py-0.5 rounded-md text-[11px] font-bold shrink-0 ${
              student.gender === "P"
                ? "bg-pink-50 text-pink-700"
                : "bg-indigo-50 text-indigo-700"
            }`}
          >
            {student.gender}
          </span>
        </div>

        {/* Scannable Code-128 Barcode + QR Code Side-by-Side */}
        <div className="p-2.5 rounded-xl bg-white border border-slate-200 flex items-center justify-between gap-2">
          <div className="flex-1 min-w-0 overflow-hidden flex items-center justify-center">
            <svg ref={barcodeSvgRef} className="max-w-full h-auto" />
          </div>
          {qrDataUrl && (
            <img
              src={qrDataUrl}
              alt={`QR ${codeValue}`}
              className="w-16 h-16 object-contain shrink-0 border border-slate-100 rounded-lg p-0.5"
            />
          )}
        </div>
      </div>

      {/* Action Footer (Hidden when Printing) */}
      <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2 no-print">
        <button
          type="button"
          onClick={handleDownloadCardPng}
          className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-blue-700" />
          Unduh PNG
        </button>

        <div className="flex items-center gap-1.5">
          {onRegenerate && (
            <button
              type="button"
              onClick={() => onRegenerate(student)}
              title="Generate ulang kode barcode siswa"
              className="p-1.5 rounded-lg bg-white hover:bg-amber-50 border border-slate-200 text-slate-600 hover:text-amber-700 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
          {onQuickScan && (
            <button
              type="button"
              onClick={() => onQuickScan(codeValue)}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ScanLine className="w-3.5 h-3.5" />
              Uji Scan
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

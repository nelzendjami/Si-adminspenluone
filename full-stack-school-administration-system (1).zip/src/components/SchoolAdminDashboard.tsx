"use client";

import React, { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  LayoutDashboard,
  ScanLine,
  BookOpen,
  UserCheck,
  BookMarked,
  HeartHandshake,
  FileBarChart2,
  School,
  Users,
  GraduationCap,
  ShieldCheck,
  Menu,
  X,
  LogIn,
  CheckCircle2,
  AlertCircle,
  Info,
  Pencil,
} from "lucide-react";
import {
  ActiveTab,
  ClassItem,
  NavigationOptions,
  RecapResponse,
  SchoolSettingsData,
  SessionUserData,
  StudentItem,
  SubjectItem,
  TeacherItem,
  ToastMessage,
} from "@/types/school";
import {
  getStoredSessionToken,
  installAuthFetchInterceptor,
  setStoredSessionToken,
} from "@/lib/client-auth";
import OverviewSection from "./OverviewSection";
import StudentBarcodeSection from "./StudentBarcodeSection";
import AttendanceSection from "./AttendanceSection";
import SubjectsGradesSection from "./SubjectsGradesSection";
import GuidanceSection from "./GuidanceSection";
import RecapSection from "./RecapSection";
import ClassesSection from "./ClassesSection";
import StudentsSection from "./StudentsSection";
import TeachersPrincipalSection from "./TeachersPrincipalSection";
import AdminSettingsLogoSection from "./AdminSettingsLogoSection";
import AuthModal from "./AuthModal";

// Install client fetch bridge eagerly at module evaluation on client
if (typeof window !== "undefined") {
  installAuthFetchInterceptor();
}

interface SchoolAdminDashboardProps {
  initialUser: SessionUserData | null;
  initialSessionToken?: string | null;
  initialSettings: SchoolSettingsData;
  initialClasses: ClassItem[];
  initialTeachers: TeacherItem[];
  initialSubjects: SubjectItem[];
  initialStudents: StudentItem[];
  initialRecap: RecapResponse;
}

export default function SchoolAdminDashboard({
  initialUser,
  initialSessionToken = null,
  initialSettings,
  initialClasses,
  initialTeachers,
  initialSubjects,
  initialStudents,
  initialRecap,
}: SchoolAdminDashboardProps) {
  if (typeof window !== "undefined" && initialSessionToken) {
    setStoredSessionToken(initialSessionToken);
  }
  const [activeTab, setActiveTab] = useState<ActiveTab>("beranda");
  const [targetClassId, setTargetClassId] = useState<number | null>(null);
  const [barcodeNavConfig, setBarcodeNavConfig] = useState<{
    mode: "mapel" | "wali";
    subTab: "scanner" | "cards";
  }>({ mode: "mapel", subTab: "scanner" });
  const [subjectNavConfig, setSubjectNavConfig] = useState<{
    subTab: "master" | "grades" | "matrix";
    subjectId: number | null;
  }>({ subTab: "master", subjectId: null });
  const [guidanceStudentId, setGuidanceStudentId] = useState<number | null>(
    null
  );

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const [currentUser, setCurrentUser] = useState<SessionUserData | null>(
    initialUser
  );
  const [settings, setSettings] = useState<SchoolSettingsData>(initialSettings);
  const [classes, setClasses] = useState<ClassItem[]>(initialClasses);
  const [teachers, setTeachers] = useState<TeacherItem[]>(initialTeachers);
  const [subjects, setSubjects] = useState<SubjectItem[]>(initialSubjects);
  const [students, setStudents] = useState<StudentItem[]>(initialStudents);
  const [recap, setRecap] = useState<RecapResponse>(initialRecap);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((msg: Omit<ToastMessage, "id">) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { ...msg, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  // Dynamically sync browser tab title & favicon to active school name & custom imported logo
  useEffect(() => {
    installAuthFetchInterceptor();
    if (typeof document !== "undefined" && settings?.logoUrl) {
      document.title = `SI-ADMIN ${settings.schoolName} — Sistem Administrasi Sekolah`;
      let link = document.querySelector(
        "link[rel~='icon']"
      ) as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement("link");
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = settings.logoUrl;
    }
  }, [settings.logoUrl, settings.schoolName]);

  const refreshBootstrap = useCallback(async () => {
    try {
      const res = await fetch("/api/bootstrap", { cache: "no-store" });
      const data = await res.json();
      if (res.ok) {
        if (data.settings) setSettings(data.settings);
        if (Array.isArray(data.classes)) setClasses(data.classes);
        if (Array.isArray(data.teachers)) setTeachers(data.teachers);
        if (Array.isArray(data.subjects)) setSubjects(data.subjects);
        if (Array.isArray(data.students)) setStudents(data.students);
        setCurrentUser(data.user ?? null);
      }
    } catch {
      // ignore transient error
    }
  }, []);

  // Clean URL `?_st=` token after capturing in memory & recover session if needed
  useEffect(() => {
    if (typeof window !== "undefined") {
      const url = new URL(window.location.href);
      const urlSt = url.searchParams.get("_st");
      if (urlSt) {
        setStoredSessionToken(urlSt);
        url.searchParams.delete("_st");
        window.history.replaceState({}, "", url.pathname + url.search);
      }
    }
    if (!initialUser && getStoredSessionToken()) {
      refreshBootstrap();
    }
  }, [initialUser, refreshBootstrap]);

  const refreshRecap = useCallback(async () => {
    try {
      const res = await fetch("/api/recap", { cache: "no-store" });
      const data = await res.json();
      if (res.ok) setRecap(data);
    } catch {
      // ignore transient error
    }
  }, []);

  const handleNavigate = useCallback(
    (
      tab: ActiveTab,
      classIdOrOpts?: number | NavigationOptions,
      barcodeOpts?: { mode: "mapel" | "wali"; subTab?: "scanner" | "cards" }
    ) => {
      if (typeof classIdOrOpts === "number") {
        setTargetClassId(classIdOrOpts);
      } else if (classIdOrOpts && typeof classIdOrOpts === "object") {
        if (classIdOrOpts.classId) setTargetClassId(classIdOrOpts.classId);
        if (classIdOrOpts.barcodeOpts) {
          setBarcodeNavConfig({
            mode: classIdOrOpts.barcodeOpts.mode,
            subTab: classIdOrOpts.barcodeOpts.subTab || "scanner",
          });
        }
        if (classIdOrOpts.subjectOpts) {
          setSubjectNavConfig({
            subTab: classIdOrOpts.subjectOpts.subTab || "master",
            subjectId: classIdOrOpts.subjectOpts.subjectId || null,
          });
        }
        setGuidanceStudentId(classIdOrOpts.guidanceStudentId ?? null);
      } else {
        setGuidanceStudentId(null);
      }

      if (barcodeOpts) {
        setBarcodeNavConfig({
          mode: barcodeOpts.mode,
          subTab: barcodeOpts.subTab || "scanner",
        });
      }

      setActiveTab(tab);
      setMobileMenuOpen(false);
    },
    []
  );

  const primaryNav: Array<{
    id: ActiveTab;
    label: string;
    badge?: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      id: "beranda",
      label: "Beranda Sekolah",
      icon: LayoutDashboard,
    },
    {
      id: "scan-barcode",
      label: "Scan & Kartu Barcode",
      badge: "Auto",
      icon: ScanLine,
    },
    {
      id: "absensi-mapel",
      label: "Absensi Mata Pelajaran",
      badge: "Multi",
      icon: BookOpen,
    },
    {
      id: "absensi-wali",
      label: "Absensi Guru Wali",
      badge: "1 Kelas",
      icon: UserCheck,
    },
    {
      id: "bimbingan-wali",
      label: "Bimbingan Anak Wali",
      badge: "Wali",
      icon: HeartHandshake,
    },
    {
      id: "rekapan",
      label: "Rekapan Absensi",
      icon: FileBarChart2,
    },
  ];

  const masterNav: Array<{
    id: ActiveTab;
    label: string;
    badge?: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      id: "mapel-nilai",
      label: "Data Mapel & Nilai",
      badge: `${subjects.length}`,
      icon: BookMarked,
    },
    {
      id: "kelas",
      label: "Data Kelas",
      badge: `${classes.length}`,
      icon: School,
    },
    {
      id: "siswa",
      label: "Data Siswa & Import",
      badge: `${students.length}`,
      icon: Users,
    },
    {
      id: "guru-kepsek",
      label: "Guru Mapel & Kepsek",
      badge: "NIP",
      icon: GraduationCap,
    },
    {
      id: "admin-logo",
      label: "Logo & Admin Pribadi",
      icon: ShieldCheck,
    },
  ];

  const renderSidebarContent = () => (
    <div className="h-full flex flex-col justify-between bg-white border-r border-slate-200 overflow-y-auto">
      <div>
        {/* Brand Header with Custom Imported Logo */}
        <div className="p-5 border-b border-slate-200 flex items-center gap-3.5">
          <button
            type="button"
            onClick={() => handleNavigate("admin-logo")}
            title="Klik untuk mengganti Logo Sekolah"
            className="group relative w-12 h-12 rounded-xl bg-slate-50 border border-slate-200 p-1.5 flex items-center justify-center shrink-0 cursor-pointer hover:border-blue-500 transition-colors"
          >
            <img
              src={settings.logoUrl || "/images/logo-smpn1-umalulu.png"}
              alt="Logo Sekolah"
              className="w-full h-full object-contain"
            />
            <span className="w-4 h-4 rounded-full bg-blue-700 text-white flex items-center justify-center absolute -bottom-1 -right-1 shadow-xs opacity-90 group-hover:scale-110 transition-transform">
              <Pencil className="w-2.5 h-2.5" />
            </span>
          </button>
          <div className="min-w-0">
            <h2 className="text-sm font-extrabold text-slate-900 truncate">
              {settings.schoolName}
            </h2>
            <p className="text-[11px] font-medium text-slate-500 truncate">
              Kec. Umalulu • Kab. Sumba Timur
            </p>
          </div>
        </div>

        {/* Navigation Groups */}
        <div className="p-4 space-y-5">
          <div>
            <p className="px-3 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Kehadiran & Pendampingan
            </p>
            <nav className="space-y-1">
              {primaryNav.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavigate(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                      active
                        ? "bg-blue-700 text-white shadow-xs"
                        : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                    }`}
                  >
                    <span className="flex items-center gap-3 truncate">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {item.badge && (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                          active
                            ? "bg-white/20 text-white"
                            : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          <div>
            <p className="px-3 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Akademik & Master Data
            </p>
            <nav className="space-y-1">
              {masterNav.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavigate(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                      active
                        ? "bg-blue-700 text-white shadow-xs"
                        : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                    }`}
                  >
                    <span className="flex items-center gap-3 truncate">
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {item.badge && (
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                          active
                            ? "bg-white/20 text-white"
                            : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      </div>

      {/* Bottom Auth & Session Footer */}
      <div className="p-4 border-t border-slate-200 bg-slate-50/70">
        {currentUser ? (
          <div className="space-y-2.5">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-700 text-white font-bold text-xs flex items-center justify-center shrink-0">
                {currentUser.fullName.slice(0, 2).toUpperCase()}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-slate-900 truncate">
                  {currentUser.fullName}
                </p>
                <p className="text-[11px] text-emerald-700 font-semibold truncate">
                  {currentUser.role === "admin"
                    ? "Admin Pribadi Aktif"
                    : currentUser.role === "wali_kelas"
                    ? `Guru Wali ${currentUser.assignedClassName}`
                    : "Guru Mapel"}
                </p>
              </div>
            </div>
            <button
              onClick={() => setAuthModalOpen(true)}
              className="w-full py-2 px-3 rounded-xl bg-white border border-slate-200 hover:border-blue-300 text-xs font-semibold text-slate-700 cursor-pointer"
            >
              Ganti Akun / Keluar
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <button
              onClick={() => setAuthModalOpen(true)}
              className="w-full py-2.5 px-3.5 rounded-xl bg-slate-900 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              Login Admin / Guru
            </button>
            <Link
              href="/login"
              className="block text-center text-[11px] font-medium text-slate-500 hover:text-blue-700"
            >
              Buka Halaman Login Penuh →
            </Link>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:block w-72 shrink-0 fixed inset-y-0 left-0 z-30 no-print">
        {renderSidebarContent()}
      </aside>

      {/* Mobile Drawer Sidebar */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex no-print">
          <div
            onClick={() => setMobileMenuOpen(false)}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="absolute top-4 right-3 p-1.5 rounded-lg bg-slate-100 text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>
            {renderSidebarContent()}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-72 flex flex-col min-w-0">
        {/* Sticky Top Header Bar */}
        <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 sm:px-8 h-16 flex items-center justify-between gap-4 no-print">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-blue-700">
                SI-ADMIN SEKOLAH
              </p>
              <p className="text-sm font-bold text-slate-900 hidden sm:block">
                {settings.schoolName} — TP {settings.academicYear} (
                {settings.semester})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setAuthModalOpen(true)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all cursor-pointer ${
                currentUser
                  ? "bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100"
                  : "bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100"
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>
                {currentUser
                  ? `${currentUser.username.toUpperCase()} (${
                      currentUser.role === "wali_kelas"
                        ? `Guru Wali ${currentUser.assignedClassName}`
                        : currentUser.role
                    })`
                  : "Login Admin Pribadi / Guru"}
              </span>
            </button>
          </div>
        </header>

        {/* Main Workspace Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === "beranda" && (
            <OverviewSection
              settings={settings}
              classes={classes}
              teachers={teachers}
              subjects={subjects}
              students={students}
              recap={recap}
              currentUser={currentUser}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === "scan-barcode" && (
            <StudentBarcodeSection
              key={`${barcodeNavConfig.subTab}-${barcodeNavConfig.mode}-${targetClassId}`}
              settings={settings}
              classes={classes}
              teachers={teachers}
              subjects={subjects}
              students={students}
              currentUser={currentUser}
              initialSubTab={barcodeNavConfig.subTab}
              initialMode={barcodeNavConfig.mode}
              initialClassId={targetClassId}
              onRefreshBootstrap={refreshBootstrap}
              onRefreshRecap={refreshRecap}
              onNotify={addToast}
            />
          )}

          {activeTab === "absensi-mapel" && (
            <AttendanceSection
              mode="mapel"
              classes={classes}
              teachers={teachers}
              subjects={subjects}
              currentUser={currentUser}
              initialClassId={targetClassId}
              onNotify={addToast}
              onRefreshRecap={refreshRecap}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === "absensi-wali" && (
            <AttendanceSection
              mode="wali"
              classes={classes}
              teachers={teachers}
              subjects={subjects}
              currentUser={currentUser}
              onNotify={addToast}
              onRefreshRecap={refreshRecap}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === "mapel-nilai" && (
            <SubjectsGradesSection
              key={`${subjectNavConfig.subTab}-${subjectNavConfig.subjectId}-${targetClassId}`}
              settings={settings}
              classes={classes}
              teachers={teachers}
              subjects={subjects}
              currentUser={currentUser}
              initialSubTab={subjectNavConfig.subTab}
              initialSubjectId={subjectNavConfig.subjectId}
              initialClassId={targetClassId}
              onRefreshBootstrap={refreshBootstrap}
              onNotify={addToast}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === "bimbingan-wali" && (
            <GuidanceSection
              key={`${targetClassId}-${guidanceStudentId}`}
              settings={settings}
              classes={classes}
              teachers={teachers}
              currentUser={currentUser}
              initialClassId={targetClassId}
              initialStudentId={guidanceStudentId}
              onNotify={addToast}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === "rekapan" && (
            <RecapSection
              settings={settings}
              classes={classes}
              subjects={subjects}
              teachers={teachers}
              onNotify={addToast}
            />
          )}

          {activeTab === "kelas" && (
            <ClassesSection
              classes={classes}
              teachers={teachers}
              onRefreshBootstrap={refreshBootstrap}
              onNotify={addToast}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === "siswa" && (
            <StudentsSection
              settings={settings}
              students={students}
              classes={classes}
              onRefreshBootstrap={refreshBootstrap}
              onNotify={addToast}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === "guru-kepsek" && (
            <TeachersPrincipalSection
              settings={settings}
              teachers={teachers}
              onRefreshBootstrap={refreshBootstrap}
              onNotify={addToast}
            />
          )}

          {activeTab === "admin-logo" && (
            <AdminSettingsLogoSection
              settings={settings}
              teachers={teachers}
              classes={classes}
              currentUser={currentUser}
              onLoginSuccess={(user) => {
                setCurrentUser(user);
              }}
              onSettingsUpdated={(updated) => {
                setSettings(updated);
              }}
              onRefreshBootstrap={refreshBootstrap}
              onNotify={addToast}
            />
          )}
        </main>
      </div>

      {/* Authentication Modal */}
      <AuthModal
        open={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        currentUser={currentUser}
        settings={settings}
        onLoginSuccess={(u) => {
          setCurrentUser(u);
          addToast({
            type: "success",
            title: `Login berhasil: ${u.fullName}`,
            description:
              u.role === "wali_kelas"
                ? `Terkunci otomatis khusus Guru Wali — Kelas ${u.assignedClassName}`
                : "Sesi aktif tersimpan.",
          });
        }}
        onLogoutSuccess={() => {
          setCurrentUser(null);
          addToast({
            type: "info",
            title: "Anda telah keluar dari sesi akun",
          });
        }}
      />

      {/* Toast Notification Stack */}
      <div className="fixed bottom-5 right-5 z-50 space-y-2.5 max-w-sm w-full px-4 sm:px-0 no-print">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`p-4 rounded-2xl border shadow-lg bg-white flex items-start gap-3 transition-all ${
              t.type === "error"
                ? "border-rose-200"
                : t.type === "info"
                ? "border-blue-200"
                : "border-emerald-200"
            }`}
          >
            {t.type === "error" ? (
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            ) : t.type === "info" ? (
              <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            )}
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-slate-900">{t.title}</p>
              {t.description && (
                <p className="text-xs text-slate-600 mt-0.5">{t.description}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

"use client";

import React, { useCallback, useEffect, useState } from "react";
import * as XLSX from "xlsx";
import {
  BookMarked,
  Plus,
  Pencil,
  Trash2,
  Save,
  Search,
  FileSpreadsheet,
  Printer,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  X,
  Table2,
  HeartHandshake,
  Award,
  Lock,
} from "lucide-react";
import {
  ActiveTab,
  ClassItem,
  GradeRowItem,
  MatrixStudentRow,
  NavigationOptions,
  SchoolSettingsData,
  SessionUserData,
  SubjectItem,
  TeacherItem,
  ToastMessage,
} from "@/types/school";

interface SubjectsGradesSectionProps {
  settings: SchoolSettingsData;
  classes: ClassItem[];
  teachers: TeacherItem[];
  subjects: SubjectItem[];
  currentUser: SessionUserData | null;
  initialSubTab?: "master" | "grades" | "matrix";
  initialSubjectId?: number | null;
  initialClassId?: number | null;
  onRefreshBootstrap: () => Promise<void>;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
  onNavigate: (tab: ActiveTab, opts?: NavigationOptions) => void;
}

function computeLocalGrade(a: number, m: number, f: number) {
  const clamp = (v: number) =>
    Math.max(0, Math.min(100, Number.isNaN(v) ? 0 : Math.round(v)));
  const ca = clamp(a);
  const cm = clamp(m);
  const cf = clamp(f);
  const totalScore = Math.round(ca * 0.3 + cm * 0.3 + cf * 0.4);
  const predicate =
    totalScore >= 90
      ? "A"
      : totalScore >= 80
      ? "B"
      : totalScore >= 75
      ? "C"
      : "D";
  return { totalScore, predicate };
}

export default function SubjectsGradesSection({
  settings,
  classes,
  teachers,
  subjects,
  currentUser,
  initialSubTab = "master",
  initialSubjectId = null,
  initialClassId = null,
  onRefreshBootstrap,
  onNotify,
  onNavigate,
}: SubjectsGradesSectionProps) {
  const [subTab, setSubTab] = useState<"master" | "grades" | "matrix">(
    initialSubTab
  );

  // =========================================================================
  // 1. MASTER MATA PELAJARAN (TAMBAH, EDIT & HAPUS) STATE
  // =========================================================================
  const [subjectSearch, setSubjectSearch] = useState("");
  const [subjectModalOpen, setSubjectModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<SubjectItem | null>(
    null
  );
  const [deleteTargetSubject, setDeleteTargetSubject] =
    useState<SubjectItem | null>(null);

  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Umum");
  const [kkm, setKkm] = useState<number>(75);
  const [weeklyHours, setWeeklyHours] = useState<number>(4);
  const [teacherId, setTeacherId] = useState<string>("");
  const [savingSubject, setSavingSubject] = useState(false);

  function openAddSubject() {
    setEditingSubject(null);
    setCode("");
    setName("");
    setCategory("Umum");
    setKkm(75);
    setWeeklyHours(4);
    setTeacherId(teachers[0] ? String(teachers[0].id) : "");
    setSubjectModalOpen(true);
  }

  function openEditSubject(subj: SubjectItem) {
    setEditingSubject(subj);
    setCode(subj.code);
    setName(subj.name);
    setCategory(subj.category || "Umum");
    setKkm(subj.kkm ?? 75);
    setWeeklyHours(subj.weeklyHours ?? 4);
    setTeacherId(subj.teacherId ? String(subj.teacherId) : "");
    setSubjectModalOpen(true);
  }

  async function handleSaveSubject(e: React.FormEvent) {
    e.preventDefault();
    setSavingSubject(true);
    try {
      const payload = {
        code,
        name,
        category,
        kkm,
        weeklyHours,
        teacherId: teacherId ? Number(teacherId) : null,
      };
      const res = editingSubject
        ? await fetch(`/api/subjects/${editingSubject.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch("/api/subjects", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
      const data = await res.json();
      if (!res.ok) {
        onNotify({
          type: "error",
          title: "Gagal menyimpan mata pelajaran",
          description: data.error || "Periksa kembali kode dan nama mapel.",
        });
        setSavingSubject(false);
        return;
      }

      await onRefreshBootstrap();
      setSubjectModalOpen(false);
      onNotify({
        type: "success",
        title: editingSubject
          ? `Mata Pelajaran ${name} diperbarui`
          : `Mata Pelajaran ${name} (${code.toUpperCase()}) ditambahkan`,
        description:
          "Tersinkronisasi otomatis ke Absensi Mapel & Daftar Nilai.",
      });
    } catch {
      onNotify({ type: "error", title: "Koneksi ke server gagal" });
    } finally {
      setSavingSubject(false);
    }
  }

  async function handleConfirmDeleteSubject() {
    if (!deleteTargetSubject) return;
    setSavingSubject(true);
    try {
      const res = await fetch(`/api/subjects/${deleteTargetSubject.id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error();
      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: `Mata Pelajaran ${deleteTargetSubject.name} berhasil dihapus`,
      });
      setDeleteTargetSubject(null);
    } catch {
      onNotify({ type: "error", title: "Gagal menghapus mata pelajaran" });
    } finally {
      setSavingSubject(false);
    }
  }

  const filteredSubjects = subjects.filter(
    (s) =>
      s.name.toLowerCase().includes(subjectSearch.toLowerCase()) ||
      s.code.toLowerCase().includes(subjectSearch.toLowerCase()) ||
      (s.teacherName || "").toLowerCase().includes(subjectSearch.toLowerCase())
  );

  // =========================================================================
  // 2. INPUT & DAFTAR NILAI PER MATA PELAJARAN + MATRIKS PANTAUAN STATE
  // =========================================================================
  const [selectedClassId, setSelectedClassId] = useState<number>(() => {
    if (currentUser?.role === "wali_kelas" && currentUser.assignedClassId) {
      return currentUser.assignedClassId;
    }
    return initialClassId || classes[0]?.id || 0;
  });

  const [selectedSubjectId, setSelectedSubjectId] = useState<number>(() => {
    if (initialSubjectId) return initialSubjectId;
    if (currentUser?.teacherSubject) {
      const matched = subjects.find(
        (s) => s.name === currentUser.teacherSubject
      );
      if (matched) return matched.id;
    }
    return subjects[0]?.id || 0;
  });

  const [semester, setSemester] = useState<string>(
    settings.semester || "Genap"
  );
  const [gradeSearch, setGradeSearch] = useState<string>("");
  const [gradeRows, setGradeRows] = useState<GradeRowItem[]>([]);
  const [matrixRows, setMatrixRows] = useState<MatrixStudentRow[]>([]);
  const [loadingGrades, setLoadingGrades] = useState<boolean>(false);
  const [savingBulkGrades, setSavingBulkGrades] = useState<boolean>(false);
  const [syncingStudentId, setSyncingStudentId] = useState<number | null>(null);

  // Keep class locked when Guru Wali views Matrix tab
  useEffect(() => {
    if (
      subTab === "matrix" &&
      currentUser?.role === "wali_kelas" &&
      currentUser.assignedClassId
    ) {
      setSelectedClassId(currentUser.assignedClassId);
    }
  }, [subTab, currentUser]);

  const loadGradesData = useCallback(async () => {
    if (subTab === "master" || !selectedClassId) return;
    setLoadingGrades(true);
    try {
      const params = new URLSearchParams({
        view: subTab === "matrix" ? "matrix" : "subject",
        classId: String(selectedClassId),
        subjectId: String(selectedSubjectId || subjects[0]?.id || 0),
        semester,
        academicYear: settings.academicYear,
      });
      const res = await fetch(`/api/grades?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        if (subTab === "matrix") {
          setMatrixRows(Array.isArray(data.matrixRows) ? data.matrixRows : []);
        } else {
          setGradeRows(Array.isArray(data.rows) ? data.rows : []);
        }
      }
    } catch {
      onNotify({
        type: "error",
        title: "Gagal memuat daftar nilai",
      });
    } finally {
      setLoadingGrades(false);
    }
  }, [
    subTab,
    selectedClassId,
    selectedSubjectId,
    semester,
    settings.academicYear,
    subjects,
    onNotify,
  ]);

  useEffect(() => {
    loadGradesData();
  }, [loadGradesData]);

  const activeSubjectObj =
    subjects.find((s) => s.id === selectedSubjectId) || subjects[0] || null;
  const activeClassObj =
    classes.find((c) => c.id === selectedClassId) || classes[0] || null;

  function handleLocalScoreChange(
    studentId: number,
    field: "assignmentScore" | "midtermScore" | "finalScore" | "teacherNotes",
    rawVal: string
  ) {
    setGradeRows((prev) =>
      prev.map((row) => {
        if (row.studentId !== studentId) return row;
        if (field === "teacherNotes") {
          return { ...row, teacherNotes: rawVal };
        }
        const num = Math.max(
          0,
          Math.min(100, Number(rawVal === "" ? 0 : rawVal))
        );
        const updated = { ...row, [field]: num };
        const { totalScore, predicate } = computeLocalGrade(
          updated.assignmentScore,
          updated.midtermScore,
          updated.finalScore
        );
        return {
          ...updated,
          totalScore,
          predicate,
          isPassing: totalScore >= (activeSubjectObj?.kkm ?? 75),
        };
      })
    );
  }

  async function saveSingleRow(row: GradeRowItem) {
    if (!activeSubjectObj || !selectedClassId) return;
    setSyncingStudentId(row.studentId);
    try {
      const res = await fetch("/api/grades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "single",
          classId: selectedClassId,
          subjectId: activeSubjectObj.id,
          semester,
          academicYear: settings.academicYear,
          studentId: row.studentId,
          assignmentScore: row.assignmentScore,
          midtermScore: row.midtermScore,
          finalScore: row.finalScore,
          teacherNotes: row.teacherNotes,
          updatedBy:
            activeSubjectObj.teacherName ||
            currentUser?.fullName ||
            "Guru Mapel",
        }),
      });
      if (res.ok) {
        setGradeRows((prev) =>
          prev.map((item) =>
            item.studentId === row.studentId
              ? { ...item, isSaved: true }
              : item
          )
        );
        onRefreshBootstrap();
      }
    } finally {
      setSyncingStudentId(null);
    }
  }

  async function handleSaveAllGrades() {
    if (!activeSubjectObj || !selectedClassId || gradeRows.length === 0) return;
    setSavingBulkGrades(true);
    try {
      const res = await fetch("/api/grades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "bulk",
          classId: selectedClassId,
          subjectId: activeSubjectObj.id,
          semester,
          academicYear: settings.academicYear,
          updatedBy:
            activeSubjectObj.teacherName ||
            currentUser?.fullName ||
            "Guru Mapel",
          entries: gradeRows.map((r) => ({
            studentId: r.studentId,
            assignmentScore: r.assignmentScore,
            midtermScore: r.midtermScore,
            finalScore: r.finalScore,
            teacherNotes: r.teacherNotes,
          })),
        }),
      });
      if (!res.ok) throw new Error();
      setGradeRows((prev) => prev.map((r) => ({ ...r, isSaved: true })));
      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: `Daftar Nilai ${activeSubjectObj.name} Tersimpan!`,
        description: `${gradeRows.length} nilai siswa Kelas ${
          activeClassObj?.name || ""
        } berhasil disimpan & siap dipantau Guru Wali.`,
      });
    } catch {
      onNotify({ type: "error", title: "Gagal menyimpan daftar nilai" });
    } finally {
      setSavingBulkGrades(false);
    }
  }

  function handleExportGradesExcel() {
    if (subTab === "matrix") {
      const data = matrixRows.map((row, idx) => {
        const base: Record<string, string | number> = {
          No: idx + 1,
          NISN: row.nisn,
          "Nama Siswa": row.name,
          JK: row.gender,
        };
        subjects.forEach((s) => {
          base[`${s.code} (KKM ${s.kkm})`] =
            row.scoresBySubject[s.id]?.totalScore ?? "-";
        });
        base["Rata-Rata"] = row.averageScore;
        base["Mapel < KKM"] = row.belowKkmCount;
        return base;
      });
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, ws, "Pantauan_Nilai_Kelas");
      XLSX.writeFile(
        wb,
        `Pantauan_Nilai_Lintas_Mapel_Kelas_${activeClassObj?.name || "SMPN1"}.xlsx`
      );
      return;
    }

    const data = gradeRows.map((r, idx) => ({
      No: idx + 1,
      NISN: r.nisn,
      "Nama Siswa": r.name,
      JK: r.gender,
      "Nilai Tugas (30%)": r.assignmentScore,
      "Nilai UTS (30%)": r.midtermScore,
      "Nilai UAS (40%)": r.finalScore,
      "Nilai Akhir": r.totalScore,
      Predikat: r.predicate,
      KKM: r.kkm,
      Ketuntasan: r.isPassing ? "Tuntas" : "Belum Tuntas",
      "Catatan Guru Mapel": r.teacherNotes,
    }));
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, "Daftar_Nilai_Mapel");
    XLSX.writeFile(
      wb,
      `Daftar_Nilai_${activeSubjectObj?.code || "Mapel"}_Kelas_${
        activeClassObj?.name || "VII"
      }.xlsx`
    );
  }

  const filteredGradeRows = gradeRows.filter(
    (r) =>
      r.name.toLowerCase().includes(gradeSearch.toLowerCase()) ||
      r.nisn.toLowerCase().includes(gradeSearch.toLowerCase())
  );

  const filteredMatrixRows = matrixRows.filter(
    (r) =>
      r.name.toLowerCase().includes(gradeSearch.toLowerCase()) ||
      r.nisn.toLowerCase().includes(gradeSearch.toLowerCase())
  );

  const avgClassSubjectScore =
    gradeRows.length > 0
      ? Math.round(
          gradeRows.reduce((acc, r) => acc + r.totalScore, 0) / gradeRows.length
        )
      : 0;
  const passingCount = gradeRows.filter((r) => r.isPassing).length;
  const remedialCount = gradeRows.length - passingCount;

  return (
    <div className="space-y-6 print-container">
      {/* Official Print Kop Surat */}
      <div className="hidden print-only border-b-4 border-double border-black pb-4 mb-6">
        <div className="flex items-center justify-between gap-4">
          <img
            src={settings.logoUrl || "/images/logo-smpn1-umalulu.png"}
            alt="Logo Sekolah"
            className="w-20 h-20 object-contain"
          />
          <div className="text-center flex-1">
            <p className="text-sm font-bold uppercase">
              Pemerintah Kabupaten Sumba Timur — Dinas Pendidikan
            </p>
            <h1 className="text-xl font-extrabold uppercase mt-0.5">
              {settings.schoolName}
            </h1>
            <p className="text-xs mt-1">
              NPSN: {settings.npsn} • {settings.address}
            </p>
          </div>
          <div className="w-20" />
        </div>
      </div>

      {/* Top Module Header & Sub-Navigation Switcher */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 no-print">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-1.5">
              <BookMarked className="w-3.5 h-3.5" />
              Kurikulum, Mata Pelajaran & Evaluasi Akademik
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              Data Mata Pelajaran & Daftar Nilai Mata Pelajaran
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Kelola Master Mata Pelajaran (Tambah, Edit & Hapus), input daftar
              nilai per mata pelajaran, serta pantau capaian nilai lintas mapel
              oleh Guru Mapel & Guru Wali.
            </p>
          </div>

          {/* 3-Tab Mode Pill Bar */}
          <div className="flex flex-wrap p-1.5 rounded-2xl bg-slate-100 border border-slate-200 gap-1 self-start">
            <button
              type="button"
              onClick={() => setSubTab("master")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                subTab === "master"
                  ? "bg-blue-700 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <BookMarked className="w-3.5 h-3.5" />
              Master Mapel ({subjects.length})
            </button>
            <button
              type="button"
              onClick={() => setSubTab("grades")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                subTab === "grades"
                  ? "bg-blue-700 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              Input & Nilai Per Mapel
            </button>
            <button
              type="button"
              onClick={() => setSubTab("matrix")}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                subTab === "matrix"
                  ? "bg-emerald-600 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Table2 className="w-3.5 h-3.5" />
              Pantauan Nilai Guru Mapel & Wali
            </button>
          </div>
        </div>
      </div>

      {/* ==================================================================== */}
      {/* TAB 1: MASTER DATA MATA PELAJARAN (TAMBAH, EDIT & HAPUS)             */}
      {/* ==================================================================== */}
      {subTab === "master" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={subjectSearch}
                onChange={(e) => setSubjectSearch(e.target.value)}
                placeholder="Cari kode, nama mapel, atau guru..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900"
              />
            </div>

            <button
              type="button"
              onClick={openAddSubject}
              className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold shadow-xs flex items-center gap-2 shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Tambah Mata Pelajaran Baru
            </button>
          </div>

          {filteredSubjects.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
              <BookMarked className="w-10 h-10 text-slate-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-900">
                Mata Pelajaran Tidak Ditemukan
              </h3>
              <p className="text-sm text-slate-500 mt-1">
                Klik tombol Tambah Mata Pelajaran Baru untuk menginput mata
                pelajaran.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
              {filteredSubjects.map((subj) => (
                <div
                  key={subj.id}
                  className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between hover:border-blue-300 transition-all"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 font-mono-code text-xs font-extrabold">
                            {subj.code}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[11px] font-semibold">
                            {subj.category || "Umum"} • {subj.weeklyHours ?? 4}{" "}
                            JP
                          </span>
                        </div>
                        <h2 className="text-lg font-extrabold text-slate-900 mt-2">
                          {subj.name}
                        </h2>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEditSubject(subj)}
                          title="Edit Mata Pelajaran"
                          className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTargetSubject(subj)}
                          title="Hapus Mata Pelajaran"
                          className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Assigned Subject Teacher Box */}
                    <div className="mt-4 p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                        Guru Pengampu Mata Pelajaran
                      </span>
                      {subj.teacherName ? (
                        <div className="mt-0.5">
                          <p className="text-sm font-bold text-slate-900">
                            {subj.teacherName}
                          </p>
                          <p className="font-mono-code text-xs text-slate-500">
                            NIP. {subj.teacherNip}
                          </p>
                        </div>
                      ) : (
                        <p className="text-xs italic text-amber-600 mt-1">
                          Belum ditentukan — Klik Edit untuk memilih guru
                        </p>
                      )}
                    </div>

                    {/* Grade Stats Summary */}
                    <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                      <div className="p-2 rounded-xl bg-slate-50 border border-slate-100">
                        <span className="block text-[10px] font-semibold uppercase text-slate-500">
                          KKM / KKTP
                        </span>
                        <span className="text-sm font-extrabold text-slate-900">
                          {subj.kkm ?? 75}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-emerald-50/70 border border-emerald-100">
                        <span className="block text-[10px] font-semibold uppercase text-emerald-700">
                          Rata-Rata
                        </span>
                        <span className="text-sm font-extrabold text-emerald-800">
                          {subj.averageScore || "-"}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-rose-50/70 border border-rose-100">
                        <span className="block text-[10px] font-semibold uppercase text-rose-700">
                          &lt; KKM
                        </span>
                        <span className="text-sm font-extrabold text-rose-800">
                          {subj.belowKkmCount ?? 0} Siswa
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-500">
                      {subj.gradedCount ?? 0} Nilai Tersimpan
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedSubjectId(subj.id);
                        setSubTab("grades");
                      }}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Award className="w-3.5 h-3.5" />
                      Input / Lihat Nilai
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 2: INPUT & DAFTAR NILAI PER MAPEL                                */}
      {/* ==================================================================== */}
      {subTab === "grades" && (
        <div className="space-y-6">
          {/* Controls Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 no-print">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Input & Daftar Nilai Per Mata Pelajaran
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Formula Nilai Akhir otomatis: 30% Tugas + 30% UTS + 40% UAS.
                  Seluruh perubahan langsung dapat dipantau Guru Mapel & Guru
                  Wali.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleExportGradesExcel}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  Export Excel
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3.5 py-2 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  Cetak Daftar Nilai
                </button>
                <button
                  type="button"
                  onClick={handleSaveAllGrades}
                  disabled={savingBulkGrades || gradeRows.length === 0}
                  className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold flex items-center gap-2 shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  {savingBulkGrades ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  Simpan Semua Nilai Kelas
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Pilih Kelas
                </label>
                <select
                  value={selectedClassId}
                  onChange={(e) => setSelectedClassId(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-900"
                >
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      Kelas {c.name} ({c.studentCount} Siswa)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Pilih Mata Pelajaran
                </label>
                <select
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-900"
                >
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code}) — KKM {s.kkm}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Semester
                </label>
                <select
                  value={semester}
                  onChange={(e) => setSemester(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
                >
                  <option value="Ganjil">Semester Ganjil</option>
                  <option value="Genap">Semester Genap</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Cari Nama / NISN Siswa
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={gradeSearch}
                    onChange={(e) => setGradeSearch(e.target.value)}
                    placeholder="Ketik nama siswa..."
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* KPI Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 no-print">
            <div className="bg-white rounded-2xl border border-slate-200 p-4">
              <span className="text-xs font-semibold text-slate-500">
                KKM {activeSubjectObj?.name || "Mapel"}
              </span>
              <p className="text-2xl font-extrabold text-slate-900 mt-1">
                {activeSubjectObj?.kkm ?? 75}
              </p>
            </div>
            <div className="bg-white rounded-2xl border border-blue-200 p-4">
              <span className="text-xs font-semibold text-blue-700">
                Rata-Rata Kelas {activeClassObj?.name}
              </span>
              <p className="text-2xl font-extrabold text-blue-700 mt-1">
                {avgClassSubjectScore}
              </p>
            </div>
            <div className="bg-white rounded-2xl border border-emerald-200 p-4">
              <span className="text-xs font-semibold text-emerald-700">
                Tuntas (&ge; KKM)
              </span>
              <p className="text-2xl font-extrabold text-emerald-700 mt-1">
                {passingCount} Siswa
              </p>
            </div>
            <div className="bg-white rounded-2xl border border-rose-200 p-4">
              <span className="text-xs font-semibold text-rose-700">
                Perlu Bimbingan / Remedial
              </span>
              <p className="text-2xl font-extrabold text-rose-700 mt-1">
                {remedialCount} Siswa
              </p>
            </div>
          </div>

          {/* Print Heading */}
          <div className="hidden print-only text-center mb-4">
            <h2 className="text-base font-bold uppercase underline">
              DAFTAR NILAI MATA PELAJARAN:{" "}
              {activeSubjectObj?.name.toUpperCase()}
            </h2>
            <p className="text-xs mt-1">
              Kelas: {activeClassObj?.name} • Semester {semester} TP{" "}
              {settings.academicYear} • KKM: {activeSubjectObj?.kkm}
            </p>
          </div>

          {/* Per-Subject Grade Input Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            {loadingGrades ? (
              <div className="p-12 flex flex-col items-center justify-center text-slate-500">
                <Loader2 className="w-7 h-7 animate-spin text-blue-600 mb-2" />
                <p className="text-sm">Memuat daftar nilai siswa...</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-600">
                      <th className="py-3.5 pl-5 pr-2">No</th>
                      <th className="py-3.5 px-3">Nama Siswa & NISN</th>
                      <th className="py-3.5 px-2 text-center">Tugas (30%)</th>
                      <th className="py-3.5 px-2 text-center">UTS (30%)</th>
                      <th className="py-3.5 px-2 text-center">UAS (40%)</th>
                      <th className="py-3.5 px-3 text-center">Nilai Akhir</th>
                      <th className="py-3.5 px-2 text-center">Predikat</th>
                      <th className="py-3.5 px-3">Ketuntasan</th>
                      <th className="py-3.5 pl-3 pr-5">
                        Catatan Guru Mapel / Tindak Lanjut
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredGradeRows.map((row, idx) => (
                      <tr key={row.studentId} className="hover:bg-slate-50/70">
                        <td className="py-3 pl-5 pr-2 text-xs text-slate-500">
                          {idx + 1}
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-slate-900">
                              {row.name}
                            </span>
                            {syncingStudentId === row.studentId ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                            ) : (
                              row.isSaved && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 no-print" />
                              )
                            )}
                          </div>
                          <span className="block font-mono-code text-xs text-slate-500">
                            {row.nisn}
                          </span>
                        </td>
                        <td className="py-3 px-2 text-center">
                          <input
                            type="number"
                            min={0}
                            max={100}
                            value={row.assignmentScore}
                            onChange={(e) =>
                              handleLocalScoreChange(
                                row.studentId,
                                "assignmentScore",
                                e.target.value
                              )
                            }
                            onBlur={() => saveSingleRow(row)}
                            className="w-16 px-2 py-1.5 rounded-lg border border-slate-300 text-center font-mono-code text-xs font-bold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                          />
                        </td>
                        <td className="py-3 px-2 text-center">
                          <input
                            type="number"
                            min={0}
                            max={100}
                            value={row.midtermScore}
                            onChange={(e) =>
                              handleLocalScoreChange(
                                row.studentId,
                                "midtermScore",
                                e.target.value
                              )
                            }
                            onBlur={() => saveSingleRow(row)}
                            className="w-16 px-2 py-1.5 rounded-lg border border-slate-300 text-center font-mono-code text-xs font-bold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                          />
                        </td>
                        <td className="py-3 px-2 text-center">
                          <input
                            type="number"
                            min={0}
                            max={100}
                            value={row.finalScore}
                            onChange={(e) =>
                              handleLocalScoreChange(
                                row.studentId,
                                "finalScore",
                                e.target.value
                              )
                            }
                            onBlur={() => saveSingleRow(row)}
                            className="w-16 px-2 py-1.5 rounded-lg border border-slate-300 text-center font-mono-code text-xs font-bold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                          />
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span
                            className={`inline-block px-2.5 py-1 rounded-lg font-mono-code text-xs font-extrabold ${
                              row.isPassing
                                ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
                                : "bg-rose-50 text-rose-800 border border-rose-200"
                            }`}
                          >
                            {row.totalScore}
                          </span>
                        </td>
                        <td className="py-3 px-2 text-center font-extrabold text-slate-800 text-xs">
                          {row.predicate}
                        </td>
                        <td className="py-3 px-3">
                          {row.isPassing ? (
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Tuntas
                            </span>
                          ) : (
                            <div className="space-y-1">
                              <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-700">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                Belum Tuntas
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  onNavigate("bimbingan-wali", {
                                    classId: selectedClassId,
                                    guidanceStudentId: row.studentId,
                                  })
                                }
                                className="block text-[11px] font-semibold text-blue-700 hover:underline no-print cursor-pointer"
                              >
                                + Rujuk Bimbingan Wali →
                              </button>
                            </div>
                          )}
                        </td>
                        <td className="py-3 pl-3 pr-5 min-w-[210px]">
                          <input
                            type="text"
                            value={row.teacherNotes}
                            onChange={(e) =>
                              handleLocalScoreChange(
                                row.studentId,
                                "teacherNotes",
                                e.target.value
                              )
                            }
                            onBlur={() => saveSingleRow(row)}
                            placeholder="Catatan capaian..."
                            className="w-full px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-700"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Official Signature Block */}
            <div className="p-6 border-t border-slate-200 bg-slate-50/50 grid grid-cols-1 sm:grid-cols-2 gap-8 text-sm">
              <div>
                <p className="text-xs text-slate-500">Mengetahui, Guru Wali</p>
                <p className="font-semibold text-slate-900">
                  Kelas {activeClassObj?.name || "-"}
                </p>
                <div className="h-12" />
                <p className="font-bold text-slate-900 underline">
                  {activeClassObj?.homeroomTeacherName ||
                    "_______________________"}
                </p>
                <p className="font-mono-code text-xs text-slate-600">
                  NIP. {activeClassObj?.homeroomTeacherNip || "-"}
                </p>
              </div>
              <div className="sm:text-right">
                <p className="text-xs text-slate-500">
                  Umalulu,{" "}
                  {new Date().toLocaleDateString("id-ID", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </p>
                <p className="font-semibold text-slate-900">
                  Guru Mata Pelajaran {activeSubjectObj?.name}
                </p>
                <div className="h-12" />
                <p className="font-bold text-slate-900 underline">
                  {activeSubjectObj?.teacherName || "_______________________"}
                </p>
                <p className="font-mono-code text-xs text-slate-600">
                  NIP. {activeSubjectObj?.teacherNip || "-"}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 3: MATRIKS PANTAUAN LINTAS MAPEL (GURU MAPEL & GURU WALI)        */}
      {/* ==================================================================== */}
      {subTab === "matrix" && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 no-print">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Matriks Pantauan Nilai Seluruh Mata Pelajaran Per Kelas
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Memudahkan Guru Wali & Guru Mapel memantau seluruh nilai
                  akademik siswa secara menyeluruh dan menindaklanjuti nilai di
                  bawah KKM.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleExportGradesExcel}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  Export Leger Excel (.xlsx)
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  Cetak Leger Nilai Kelas
                </button>
              </div>
            </div>

            {currentUser?.role === "wali_kelas" && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-2.5 text-xs font-medium text-emerald-900">
                <Lock className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>
                  Mode Pantauan Guru Wali Aktif: Menampilkan khusus Anak Wali{" "}
                  <strong>Kelas {currentUser.assignedClassName}</strong>.
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kelas Pantauan
                </label>
                <select
                  value={selectedClassId}
                  disabled={currentUser?.role === "wali_kelas"}
                  onChange={(e) => setSelectedClassId(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white disabled:bg-slate-100 text-sm font-semibold text-slate-900"
                >
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      Kelas {c.name} — Guru Wali:{" "}
                      {c.homeroomTeacherName || "Belum ditentukan"}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Semester
                </label>
                <select
                  value={semester}
                  onChange={(e) => setSemester(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
                >
                  <option value="Ganjil">Semester Ganjil</option>
                  <option value="Genap">Semester Genap</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Cari Siswa
                </label>
                <input
                  type="text"
                  value={gradeSearch}
                  onChange={(e) => setGradeSearch(e.target.value)}
                  placeholder="Cari nama siswa / NISN..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900"
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            {loadingGrades ? (
              <div className="p-12 flex flex-col items-center justify-center text-slate-500">
                <Loader2 className="w-7 h-7 animate-spin text-blue-600 mb-2" />
                <p className="text-sm">Memuat matriks nilai seluruh mapel...</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-600">
                      <th className="py-3.5 pl-5 pr-2">No</th>
                      <th className="py-3.5 px-3 min-w-[180px]">
                        Nama Anak Wali / Siswa
                      </th>
                      {subjects.map((s) => (
                        <th
                          key={s.id}
                          onClick={() => {
                            setSelectedSubjectId(s.id);
                            setSubTab("grades");
                          }}
                          title={`Klik untuk edit nilai ${s.name}`}
                          className="py-3.5 px-2.5 text-center cursor-pointer hover:text-blue-700"
                        >
                          <span className="block font-extrabold">{s.code}</span>
                          <span className="block text-[9px] text-slate-400">
                            KKM {s.kkm}
                          </span>
                        </th>
                      ))}
                      <th className="py-3.5 px-3 text-center bg-blue-50/50 text-blue-900">
                        Rata2
                      </th>
                      <th className="py-3.5 pl-3 pr-5 text-right no-print">
                        Bimbingan
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                    {filteredMatrixRows.map((row, idx) => (
                      <tr key={row.studentId} className="hover:bg-slate-50/70">
                        <td className="py-3 pl-5 pr-2 text-xs text-slate-500">
                          {idx + 1}
                        </td>
                        <td className="py-3 px-3">
                          <p className="font-bold text-slate-900">{row.name}</p>
                          <p className="font-mono-code text-[11px] text-slate-400">
                            {row.nisn}
                          </p>
                        </td>
                        {subjects.map((s) => {
                          const cell = row.scoresBySubject[s.id];
                          const val = cell?.totalScore;
                          return (
                            <td
                              key={s.id}
                              className="py-3 px-2.5 text-center font-mono-code"
                            >
                              {val === null || val === undefined ? (
                                <span className="text-slate-300">-</span>
                              ) : (
                                <span
                                  className={`inline-block px-2 py-0.5 rounded font-bold text-xs ${
                                    cell.belowKkm
                                      ? "bg-rose-50 text-rose-700 border border-rose-200"
                                      : "text-slate-800"
                                  }`}
                                >
                                  {val}
                                </span>
                              )}
                            </td>
                          );
                        })}
                        <td className="py-3 px-3 text-center bg-blue-50/30 font-mono-code font-extrabold text-blue-800">
                          {row.averageScore}
                        </td>
                        <td className="py-3 pl-3 pr-5 text-right no-print">
                          <button
                            type="button"
                            onClick={() =>
                              onNavigate("bimbingan-wali", {
                                classId: selectedClassId,
                                guidanceStudentId: row.studentId,
                              })
                            }
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 cursor-pointer ${
                              row.belowKkmCount > 0
                                ? "bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200"
                                : "bg-slate-100 hover:bg-slate-200 text-slate-700"
                            }`}
                          >
                            <HeartHandshake className="w-3.5 h-3.5" />
                            {row.belowKkmCount > 0
                              ? `Bimbing (${row.belowKkmCount} < KKM)`
                              : "Catat"}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* ADD / EDIT SUBJECT MODAL                                             */}
      {/* ==================================================================== */}
      {subjectModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full shadow-xl overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editingSubject
                  ? `Edit Mata Pelajaran ${editingSubject.name}`
                  : "Input / Tambah Mata Pelajaran Baru"}
              </h3>
              <button
                type="button"
                onClick={() => setSubjectModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSubject} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kode Mapel *
                  </label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="SBK / MULOK"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-code text-sm uppercase"
                    required
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Mata Pelajaran *
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Contoh: Seni Budaya & Prakarya"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kelompok Mapel
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Umum">Wajib / Umum</option>
                    <option value="Muatan Lokal">Muatan Lokal</option>
                    <option value="Pilihan">Pilihan / Ekstra</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    KKM / KKTP *
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={100}
                    value={kkm}
                    onChange={(e) => setKkm(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Alokasi (JP / Minggu)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={12}
                    value={weeklyHours}
                    onChange={(e) => setWeeklyHours(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Guru Pengampu Mata Pelajaran (Beserta NIP)
                </label>
                <select
                  value={teacherId}
                  onChange={(e) => setTeacherId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                >
                  <option value="">-- Pilih Guru Pengampu --</option>
                  {teachers.map((t) => (
                    <option key={t.id} value={String(t.id)}>
                      {t.name} — NIP. {t.nip}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setSubjectModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={savingSubject}
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
                >
                  {savingSubject && (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  )}
                  {editingSubject ? "Simpan Perubahan" : "Tambah Mata Pelajaran"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE SUBJECT CONFIRMATION MODAL */}
      {deleteTargetSubject && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-xl">
            <h3 className="text-lg font-bold text-slate-900">
              Hapus Mata Pelajaran {deleteTargetSubject.name}?
            </h3>
            <p className="text-sm text-slate-600 mt-2">
              Menghapus mata pelajaran{" "}
              <strong>
                {deleteTargetSubject.name} ({deleteTargetSubject.code})
              </strong>{" "}
              juga akan menghapus daftar nilai yang terkait dengan mata
              pelajaran ini.
            </p>
            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteTargetSubject(null)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteSubject}
                disabled={savingSubject}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
              >
                {savingSubject && <Loader2 className="w-4 h-4 animate-spin" />}
                Ya, Hapus Mapel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

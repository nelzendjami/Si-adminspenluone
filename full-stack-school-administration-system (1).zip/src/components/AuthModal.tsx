"use client";

import React, { useState } from "react";
import {
  X,
  ShieldCheck,
  Lock,
  UserCheck,
  Loader2,
  LogOut,
} from "lucide-react";
import { SchoolSettingsData, SessionUserData } from "@/types/school";
import { setStoredSessionToken } from "@/lib/client-auth";

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  currentUser: SessionUserData | null;
  settings: SchoolSettingsData;
  onLoginSuccess: (user: SessionUserData) => void;
  onLogoutSuccess: () => void;
}

export default function AuthModal({
  open,
  onClose,
  currentUser,
  settings,
  onLoginSuccess,
  onLogoutSuccess,
}: AuthModalProps) {
  const [identifier, setIdentifier] = useState("admin");
  const [password, setPassword] = useState("admin123");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  async function doLogin(idVal: string, pwVal: string) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: idVal, password: pwVal }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Login gagal.");
        setLoading(false);
        return;
      }
      if (data.token) {
        setStoredSessionToken(data.token);
      }
      onLoginSuccess(data.user);
      setLoading(false);
      onClose();
    } catch {
      setError("Koneksi ke server gagal.");
      setLoading(false);
    }
  }

  async function handleLogout() {
    setLoading(true);
    await fetch("/api/auth/logout", { method: "POST" });
    setStoredSessionToken(null);
    onLogoutSuccess();
    setLoading(false);
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full shadow-xl overflow-hidden">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={settings.logoUrl || "/images/logo-smpn1-umalulu.png"}
              alt="Logo"
              className="w-9 h-9 rounded-lg object-contain bg-white border border-slate-200 p-1"
            />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Portal Sesi & Autentikasi
              </h3>
              <p className="text-xs text-slate-500">{settings.schoolName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {currentUser && (
            <div className="mb-6 p-4 rounded-xl bg-blue-50/70 border border-blue-200 flex items-center justify-between gap-4">
              <div>
                <span className="text-xs font-semibold text-blue-700 uppercase">
                  Sesi Aktif Saat Ini
                </span>
                <p className="text-sm font-bold text-slate-900 mt-0.5">
                  {currentUser.fullName}
                </p>
                <p className="text-xs text-slate-600">
                  Peran:{" "}
                  <strong>
                    {currentUser.role === "wali_kelas"
                      ? "GURU WALI"
                      : currentUser.role.toUpperCase()}
                  </strong>
                  {currentUser.assignedClassName
                    ? ` • Khusus Kelas ${currentUser.assignedClassName}`
                    : ""}
                </p>
              </div>
              <button
                onClick={handleLogout}
                disabled={loading}
                className="px-3.5 py-2 rounded-xl bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-semibold flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                Keluar
              </button>
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-medium text-rose-700">
              {error}
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              doLogin(identifier, password);
            }}
            className="space-y-4"
          >
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username atau Email
              </label>
              <div className="relative">
                <UserCheck className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ShieldCheck className="w-4 h-4" />
              )}
              Masuk / Ganti Akun
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-slate-200">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2.5">
              Akses Cepat Peran Sekolah:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => doLogin("admin", "admin123")}
                className="p-2.5 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 text-left cursor-pointer"
              >
                <span className="block text-xs font-bold text-blue-700">
                  Admin Pribadi
                </span>
                <span className="block text-[11px] text-slate-500 mt-0.5">
                  Logo, Akun & Master
                </span>
              </button>
              <button
                type="button"
                onClick={() => doLogin("wali7a", "guru123")}
                className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 text-left cursor-pointer"
              >
                <span className="block text-xs font-bold text-emerald-700">
                  Guru Wali VII-A
                </span>
                <span className="block text-[11px] text-slate-500 mt-0.5">
                  Terkunci 1 Kelas Saja
                </span>
              </button>
              <button
                type="button"
                onClick={() => doLogin("mapel", "guru123")}
                className="p-2.5 rounded-xl border border-slate-200 hover:border-amber-400 hover:bg-amber-50/50 text-left cursor-pointer"
              >
                <span className="block text-xs font-bold text-amber-700">
                  Guru Mapel
                </span>
                <span className="block text-[11px] text-slate-500 mt-0.5">
                  Absensi & Nilai Mapel
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

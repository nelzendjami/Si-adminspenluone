"use client";

import React, { useCallback, useEffect, useState } from "react";
import * as XLSX from "xlsx";
import {
  HeartHandshake,
  Plus,
  Pencil,
  Trash2,
  Search,
  Lock,
  Printer,
  FileSpreadsheet,
  Eye,
  X,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Users,
} from "lucide-react";
import {
  ActiveTab,
  AnakWaliProfile,
  ClassItem,
  GuidanceRecordItem,
  NavigationOptions,
  SchoolSettingsData,
  SessionUserData,
  TeacherItem,
  ToastMessage,
} from "@/types/school";

interface GuidanceSectionProps {
  settings: SchoolSettingsData;
  classes: ClassItem[];
  teachers: TeacherItem[];
  currentUser: SessionUserData | null;
  initialClassId?: number | null;
  initialStudentId?: number | null;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
  onNavigate: (tab: ActiveTab, opts?: NavigationOptions) => void;
}

export default function GuidanceSection({
  settings,
  classes,
  teachers,
  currentUser,
  initialClassId = null,
  initialStudentId = null,
  onNotify,
  onNavigate,
}: GuidanceSectionProps) {
  const guruWaliList = teachers.filter((t) => t.homeroomClassId !== null);

  const [selectedClassId, setSelectedClassId] = useState<number>(() => {
    if (currentUser?.role === "wali_kelas" && currentUser.assignedClassId) {
      return currentUser.assignedClassId;
    }
    return (
      initialClassId ||
      guruWaliList[0]?.homeroomClassId ||
      classes[0]?.id ||
      0
    );
  });

  const [activeView, setActiveView] = useState<"journal" | "children">(
    "journal"
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  const [childProfiles, setChildProfiles] = useState<AnakWaliProfile[]>([]);
  const [records, setRecords] = useState<GuidanceRecordItem[]>([]);
  const [inspectChild, setInspectChild] = useState<AnakWaliProfile | null>(
    null
  );

  // Add / Edit Guidance Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] =
    useState<GuidanceRecordItem | null>(null);
  const [studentId, setStudentId] = useState<number>(0);
  const [date, setDate] = useState<string>(() =>
    new Date().toISOString().slice(0, 10)
  );
  const [category, setCategory] = useState<string>("Akademik & Nilai");
  const [topic, setTopic] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [followUpPlan, setFollowUpPlan] = useState<string>("");
  const [parentInvolved, setParentInvolved] = useState<boolean>(false);
  const [status, setStatus] = useState<string>("Dalam Pemantauan");
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Sync single class lock for Guru Wali account
  useEffect(() => {
    if (currentUser?.role === "wali_kelas" && currentUser.assignedClassId) {
      setSelectedClassId(currentUser.assignedClassId);
    } else if (initialClassId) {
      setSelectedClassId(initialClassId);
    }
  }, [currentUser, initialClassId]);

  const fetchGuidanceWorkspace = useCallback(async () => {
    if (!selectedClassId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/guidance?classId=${selectedClassId}`);
      const data = await res.json();
      if (res.ok) {
        const profiles: AnakWaliProfile[] = Array.isArray(data.childProfiles)
          ? data.childProfiles
          : [];
        setChildProfiles(profiles);
        setRecords(Array.isArray(data.records) ? data.records : []);

        // If navigated here from Daftar Nilai with a specific struggling student, auto-open form!
        if (initialStudentId) {
          const target = profiles.find((p) => p.id === initialStudentId);
          if (target) {
            setEditingRecord(null);
            setStudentId(target.id);
            setDate(new Date().toISOString().slice(0, 10));
            setCategory("Akademik & Nilai");
            setTopic(
              target.belowKkmSubjects.length > 0
                ? `Pendampingan Nilai Mapel: ${target.belowKkmSubjects.join(
                    ", "
                  )}`
                : "Pembinaan Akademik Anak Wali"
            );
            setNotes("");
            setFollowUpPlan(
              "Koordinasi latihan remedial bersama Guru Mata Pelajaran terkait."
            );
            setParentInvolved(false);
            setStatus("Dalam Pemantauan");
            setModalOpen(true);
          }
        }
      }
    } catch {
      onNotify({
        type: "error",
        title: "Gagal memuat data Bimbingan Anak Wali",
      });
    } finally {
      setLoading(false);
    }
  }, [selectedClassId, initialStudentId, onNotify]);

  useEffect(() => {
    fetchGuidanceWorkspace();
  }, [fetchGuidanceWorkspace]);

  const activeClassObj = classes.find((c) => c.id === selectedClassId) || null;

  function openNewGuidanceModal(preselectedChild?: AnakWaliProfile) {
    const chosen = preselectedChild || childProfiles[0];
    setEditingRecord(null);
    setStudentId(chosen?.id || 0);
    setDate(new Date().toISOString().slice(0, 10));
    setCategory("Akademik & Nilai");
    setTopic(
      preselectedChild && preselectedChild.belowKkmSubjects.length > 0
        ? `Pendampingan Nilai: ${preselectedChild.belowKkmSubjects.join(", ")}`
        : ""
    );
    setNotes("");
    setFollowUpPlan("");
    setParentInvolved(false);
    setStatus("Dalam Pemantauan");
    setModalOpen(true);
  }

  function openEditGuidanceModal(rec: GuidanceRecordItem) {
    setEditingRecord(rec);
    setStudentId(rec.studentId);
    setDate(rec.date);
    setCategory(rec.category);
    setTopic(rec.topic);
    setNotes(rec.notes);
    setFollowUpPlan(rec.followUpPlan);
    setParentInvolved(rec.parentInvolved);
    setStatus(rec.status);
    setModalOpen(true);
  }

  async function handleSaveGuidance(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        studentId,
        classId: selectedClassId,
        date,
        category,
        topic,
        notes,
        followUpPlan,
        parentInvolved,
        status,
        createdBy:
          activeClassObj?.homeroomTeacherName ||
          currentUser?.fullName ||
          "Guru Wali",
      };

      const res = editingRecord
        ? await fetch(`/api/guidance/${editingRecord.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch("/api/guidance", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
      const data = await res.json();
      if (!res.ok) {
        onNotify({
          type: "error",
          title: "Gagal menyimpan bimbingan",
          description: data.error || "Periksa kembali formulir.",
        });
        setSubmitting(false);
        return;
      }

      setModalOpen(false);
      await fetchGuidanceWorkspace();
      onNotify({
        type: "success",
        title: editingRecord
          ? "Catatan bimbingan diperbarui"
          : "Catatan Bimbingan Anak Wali tersimpan!",
      });
    } catch {
      onNotify({ type: "error", title: "Koneksi gagal" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleQuickStatusChange(recId: number, nextStatus: string) {
    setRecords((prev) =>
      prev.map((r) => (r.id === recId ? { ...r, status: nextStatus } : r))
    );
    await fetch(`/api/guidance/${recId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });
    onNotify({
      type: "success",
      title: `Status bimbingan diubah menjadi "${nextStatus}"`,
    });
  }

  async function handleDeleteGuidance(rec: GuidanceRecordItem) {
    if (!confirm(`Hapus catatan bimbingan untuk ${rec.studentName}?`)) return;
    try {
      const res = await fetch(`/api/guidance/${rec.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      setRecords((prev) => prev.filter((r) => r.id !== rec.id));
      onNotify({ type: "success", title: "Catatan bimbingan dihapus" });
    } catch {
      onNotify({ type: "error", title: "Gagal menghapus catatan bimbingan" });
    }
  }

  function handleExportGuidanceExcel() {
    const rows = records.map((r, idx) => ({
      No: idx + 1,
      Tanggal: r.date,
      NISN: r.studentNisn,
      "Nama Anak Wali": r.studentName,
      Kelas: r.className,
      Kategori: r.category,
      "Topik Pembinaan / Bimbingan": r.topic,
      "Hasil Konseling / Catatan": r.notes,
      "Rencana Tindak Lanjut": r.followUpPlan,
      "Orang Tua Dilibatkan": r.parentInvolved ? "Ya" : "Tidak",
      Status: r.status,
      "Guru Wali": r.guruWaliName,
    }));
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, "Jurnal_Bimbingan_Wali");
    XLSX.writeFile(
      wb,
      `Jurnal_Bimbingan_Anak_Wali_Kelas_${activeClassObj?.name || "SMPN1"}.xlsx`
    );
  }

  const filteredRecords = records.filter((r) => {
    const matchCat = categoryFilter === "all" || r.category === categoryFilter;
    const q = searchQuery.toLowerCase();
    const matchText =
      r.studentName.toLowerCase().includes(q) ||
      r.topic.toLowerCase().includes(q) ||
      r.notes.toLowerCase().includes(q);
    return matchCat && matchText;
  });

  const filteredProfiles = childProfiles.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.nisn.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const attentionCount = childProfiles.filter(
    (p) => p.belowKkmCount > 0 || p.alpaCount > 0
  ).length;
  const classAvgGrade =
    childProfiles.length > 0
      ? Math.round(
          childProfiles.reduce((acc, p) => acc + p.averageGrade, 0) /
            childProfiles.length
        )
      : 0;

  return (
    <div className="space-y-6 print-container">
      {/* Print Kop Surat */}
      <div className="hidden print-only border-b-4 border-double border-black pb-4 mb-6">
        <div className="flex items-center justify-between gap-4">
          <img
            src={settings.logoUrl || "/images/logo-smpn1-umalulu.png"}
            alt="Logo Sekolah"
            className="w-20 h-20 object-contain"
          />
          <div className="text-center flex-1">
            <p className="text-sm font-bold uppercase">
              Pemerintah Kabupaten Sumba Timur — Dinas Pendidikan
            </p>
            <h1 className="text-xl font-extrabold uppercase mt-0.5">
              {settings.schoolName}
            </h1>
            <p className="text-xs mt-1">
              NPSN: {settings.npsn} • {settings.address}
            </p>
          </div>
          <div className="w-20" />
        </div>
      </div>

      {/* Header & Class / Guru Wali Control Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 mb-1.5">
              <HeartHandshake className="w-3.5 h-3.5" />
              Pendampingan Akademik, Kehadiran & Karakter
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              Menu Bimbingan Anak Wali & Pantauan Nilai
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Jurnal pembinaan resmi Guru Wali terintegrasi langsung dengan
              capaian nilai seluruh mata pelajaran dan rekam kehadiran masing-masing
              Anak Wali.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleExportGuidanceExcel}
              className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Export Excel
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3.5 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Cetak Jurnal
            </button>
            <button
              type="button"
              onClick={() => openNewGuidanceModal()}
              className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Catat Bimbingan Baru
            </button>
          </div>
        </div>

        {currentUser?.role === "wali_kelas" && (
          <div className="p-3.5 rounded-xl bg-emerald-50/80 border border-emerald-200 flex items-center gap-2.5 text-xs font-medium text-emerald-900">
            <Lock className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              Akun Guru Wali Aktif (<strong>{currentUser.fullName}</strong>) —
              Menampilkan khusus Anak Wali Binaan{" "}
              <strong>Kelas {currentUser.assignedClassName}</strong>.
            </span>
          </div>
        )}

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <select
              value={selectedClassId}
              disabled={currentUser?.role === "wali_kelas"}
              onChange={(e) => setSelectedClassId(Number(e.target.value))}
              className="px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white disabled:bg-slate-100 text-sm font-bold text-slate-900"
            >
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  Anak Wali Kelas {c.name} — Guru Wali:{" "}
                  {c.homeroomTeacherName || "Belum ditentukan"}
                </option>
              ))}
            </select>

            <div className="inline-flex p-1 rounded-xl bg-slate-100 border border-slate-200">
              <button
                type="button"
                onClick={() => setActiveView("journal")}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  activeView === "journal"
                    ? "bg-white text-slate-900 shadow-2xs"
                    : "text-slate-600"
                }`}
              >
                Jurnal Bimbingan ({records.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveView("children")}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer ${
                  activeView === "children"
                    ? "bg-white text-slate-900 shadow-2xs"
                    : "text-slate-600"
                }`}
              >
                Profil & Nilai Anak Wali ({childProfiles.length})
              </button>
            </div>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama anak wali / topik..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-sm text-slate-900"
            />
          </div>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 no-print">
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <span className="text-xs font-semibold text-slate-500">
            Jumlah Anak Wali ({activeClassObj?.name})
          </span>
          <p className="text-2xl font-extrabold text-slate-900 mt-1">
            {childProfiles.length} Siswa
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-blue-200 p-4">
          <span className="text-xs font-semibold text-blue-700">
            Rata-Rata Nilai Semua Mapel
          </span>
          <p className="text-2xl font-extrabold text-blue-700 mt-1">
            {classAvgGrade}
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-amber-200 p-4">
          <span className="text-xs font-semibold text-amber-700">
            Anak Wali Perlu Perhatian
          </span>
          <p className="text-2xl font-extrabold text-amber-700 mt-1">
            {attentionCount} Siswa
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-emerald-200 p-4">
          <span className="text-xs font-semibold text-emerald-700">
            Total Sesi Bimbingan Tercatat
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 mt-1">
            {records.length} Sesi
          </p>
        </div>
      </div>

      {/* Print Heading */}
      <div className="hidden print-only text-center mb-4">
        <h2 className="text-base font-bold uppercase underline">
          JURNAL BIMBINGAN & PEMANTAUAN ANAK WALI — KELAS{" "}
          {activeClassObj?.name}
        </h2>
        <p className="text-xs mt-1">
          Guru Wali: {activeClassObj?.homeroomTeacherName || "-"} (NIP.{" "}
          {activeClassObj?.homeroomTeacherNip || "-"}) • TP{" "}
          {settings.academicYear}
        </p>
      </div>

      {/* ==================================================================== */}
      {/* VIEW 1: JURNAL BIMBINGAN ANAK WALI                                   */}
      {/* ==================================================================== */}
      {activeView === "journal" ? (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="p-5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 no-print">
            <div className="flex flex-wrap items-center gap-2">
              {[
                "all",
                "Akademik & Nilai",
                "Kedisiplinan & Kehadiran",
                "Karakter & Sosial",
                "Minat, Bakat & Karir",
              ].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer ${
                    categoryFilter === cat
                      ? "bg-slate-900 text-white border-slate-900"
                      : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  {cat === "all" ? "Semua Kategori" : cat}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="p-12 flex flex-col items-center justify-center text-slate-500">
              <Loader2 className="w-7 h-7 animate-spin text-blue-600 mb-2" />
              <p className="text-sm">Memuat jurnal bimbingan anak wali...</p>
            </div>
          ) : filteredRecords.length === 0 ? (
            <div className="p-12 text-center">
              <Users className="w-10 h-10 text-slate-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-900">
                Belum Ada Catatan Bimbingan pada Filter Ini
              </h3>
              <p className="text-sm text-slate-500 mt-1">
                Klik tombol Catat Bimbingan Baru untuk mendokumentasikan sesi
                pendampingan Anak Wali.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-600">
                    <th className="py-3.5 pl-6 pr-3">Tanggal</th>
                    <th className="py-3.5 px-3">Nama Anak Wali</th>
                    <th className="py-3.5 px-3">Kategori</th>
                    <th className="py-3.5 px-3">
                      Topik, Hasil Bimbingan & Tindak Lanjut
                    </th>
                    <th className="py-3.5 px-3">Status</th>
                    <th className="py-3.5 pl-3 pr-6 text-right no-print">
                      Aksi
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {filteredRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/70">
                      <td className="py-4 pl-6 pr-3 font-mono-code text-xs text-slate-600 align-top whitespace-nowrap">
                        {rec.date}
                      </td>
                      <td className="py-4 px-3 align-top">
                        <p className="font-bold text-slate-900">
                          {rec.studentName}
                        </p>
                        <p className="font-mono-code text-xs text-slate-400">
                          NISN: {rec.studentNisn}
                        </p>
                        {rec.parentInvolved && (
                          <span className="mt-1 inline-block px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[10px] font-bold">
                            Ortu Dilibatkan
                          </span>
                        )}
                      </td>
                      <td className="py-4 px-3 align-top">
                        <span className="inline-block px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 border border-blue-200 text-xs font-semibold">
                          {rec.category}
                        </span>
                      </td>
                      <td className="py-4 px-3 align-top max-w-md">
                        <p className="font-bold text-slate-900">{rec.topic}</p>
                        {rec.notes && (
                          <p className="text-xs text-slate-600 mt-1">
                            {rec.notes}
                          </p>
                        )}
                        {rec.followUpPlan && (
                          <p className="text-xs font-medium text-emerald-800 mt-1">
                            Tindak Lanjut: {rec.followUpPlan}
                          </p>
                        )}
                      </td>
                      <td className="py-4 px-3 align-top">
                        <select
                          value={rec.status}
                          onChange={(e) =>
                            handleQuickStatusChange(rec.id, e.target.value)
                          }
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold border cursor-pointer ${
                            rec.status === "Tuntas"
                              ? "bg-emerald-50 text-emerald-800 border-emerald-200"
                              : rec.status === "Perlu Tindak Lanjut"
                              ? "bg-amber-50 text-amber-800 border-amber-200"
                              : "bg-sky-50 text-sky-800 border-sky-200"
                          }`}
                        >
                          <option value="Perlu Tindak Lanjut">
                            Perlu Tindak Lanjut
                          </option>
                          <option value="Dalam Pemantauan">
                            Dalam Pemantauan
                          </option>
                          <option value="Tuntas">Tuntas</option>
                        </select>
                      </td>
                      <td className="py-4 pl-3 pr-6 text-right align-top no-print">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => openEditGuidanceModal(rec)}
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-blue-700 hover:bg-blue-50 cursor-pointer"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteGuidance(rec)}
                            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-rose-700 hover:bg-rose-50 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Signature Footer */}
          <div className="p-6 border-t border-slate-200 bg-slate-50/50 grid grid-cols-1 sm:grid-cols-2 gap-8 text-sm">
            <div>
              <p className="text-xs text-slate-500">Mengetahui,</p>
              <p className="font-semibold text-slate-900">
                Kepala {settings.schoolName}
              </p>
              <div className="h-12" />
              <p className="font-bold text-slate-900 underline">
                {settings.principalName}
              </p>
              <p className="font-mono-code text-xs text-slate-600">
                NIP. {settings.principalNip}
              </p>
            </div>
            <div className="sm:text-right">
              <p className="text-xs text-slate-500">
                Umalulu,{" "}
                {new Date().toLocaleDateString("id-ID", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </p>
              <p className="font-semibold text-slate-900">
                Guru Wali Kelas {activeClassObj?.name}
              </p>
              <div className="h-12" />
              <p className="font-bold text-slate-900 underline">
                {activeClassObj?.homeroomTeacherName ||
                  "_______________________"}
              </p>
              <p className="font-mono-code text-xs text-slate-600">
                NIP. {activeClassObj?.homeroomTeacherNip || "-"}
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* ==================================================================== */
        /* VIEW 2: PROFIL & PANTAUAN NILAI ANAK WALI                            */
        /* ==================================================================== */
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 no-print">
          {filteredProfiles.map((child) => (
            <div
              key={child.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between hover:border-blue-300 transition-all"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      {child.name}
                    </h3>
                    <p className="font-mono-code text-xs text-slate-500">
                      NISN: {child.nisn} • Ortu: {child.parentName}
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-lg font-mono-code text-xs font-extrabold ${
                      child.belowKkmCount > 0
                        ? "bg-amber-50 text-amber-800 border border-amber-200"
                        : "bg-emerald-50 text-emerald-800 border border-emerald-200"
                    }`}
                  >
                    Rata2: {child.averageGrade}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-slate-50">
                    <span className="block text-[10px] font-semibold uppercase text-slate-500">
                      Kehadiran
                    </span>
                    <span className="text-xs font-extrabold text-slate-900">
                      {child.attendanceRate}%
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50">
                    <span className="block text-[10px] font-semibold uppercase text-slate-500">
                      Mapel &lt; KKM
                    </span>
                    <span
                      className={`text-xs font-extrabold ${
                        child.belowKkmCount > 0
                          ? "text-rose-700"
                          : "text-emerald-700"
                      }`}
                    >
                      {child.belowKkmCount} Mapel
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50">
                    <span className="block text-[10px] font-semibold uppercase text-slate-500">
                      Bimbingan
                    </span>
                    <span className="text-xs font-extrabold text-blue-700">
                      {child.guidanceCount}x
                    </span>
                  </div>
                </div>

                {child.belowKkmSubjects.length > 0 ? (
                  <div className="mt-3 p-2.5 rounded-xl bg-rose-50/70 border border-rose-200 text-xs text-rose-900 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <span>
                      Perlu pendampingan:{" "}
                      <strong>{child.belowKkmSubjects.join(", ")}</strong>
                    </span>
                  </div>
                ) : (
                  <div className="mt-3 p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Seluruh mata pelajaran tuntas di atas KKM</span>
                  </div>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setInspectChild(child)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Rincian Nilai
                </button>
                <button
                  type="button"
                  onClick={() => openNewGuidanceModal(child)}
                  className="px-3.5 py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Beri Bimbingan
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL RINCIAN NILAI PER MAPEL ANAK WALI                              */}
      {/* ==================================================================== */}
      {inspectChild && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full shadow-xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Kartu Pantauan Nilai Per Mapel — {inspectChild.name}
                </h3>
                <p className="text-xs text-slate-500">
                  NISN {inspectChild.nisn} • Rata-rata Nilai:{" "}
                  <strong>{inspectChild.averageGrade}</strong>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setInspectChild(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-[11px] font-semibold uppercase text-slate-500">
                    <th className="py-2.5 pr-3">Mata Pelajaran</th>
                    <th className="py-2.5 px-2 text-center">KKM</th>
                    <th className="py-2.5 px-2 text-center">Tugas</th>
                    <th className="py-2.5 px-2 text-center">UTS</th>
                    <th className="py-2.5 px-2 text-center">UAS</th>
                    <th className="py-2.5 px-2 text-center">Akhir</th>
                    <th className="py-2.5 pl-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {inspectChild.detailedGrades.map((dg) => (
                    <tr key={dg.subjectId}>
                      <td className="py-2.5 pr-3 font-semibold text-slate-900">
                        {dg.subjectName}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono-code text-slate-500">
                        {dg.kkm}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono-code">
                        {dg.assignmentScore ?? "-"}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono-code">
                        {dg.midtermScore ?? "-"}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono-code">
                        {dg.finalScore ?? "-"}
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono-code font-extrabold">
                        {dg.totalScore ?? "-"}
                      </td>
                      <td className="py-2.5 pl-2 text-right">
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-bold ${
                            dg.isBelowKkm
                              ? "bg-rose-50 text-rose-700"
                              : "bg-emerald-50 text-emerald-700"
                          }`}
                        >
                          {dg.isBelowKkm ? "Remedial" : "Tuntas"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  const clsId = selectedClassId;
                  setInspectChild(null);
                  onNavigate("mapel-nilai", {
                    classId: clsId,
                    subjectOpts: { subTab: "grades" },
                  });
                }}
                className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
              >
                Buka Menu Input Nilai Mapel →
              </button>
              <button
                type="button"
                onClick={() => {
                  const target = inspectChild;
                  setInspectChild(null);
                  openNewGuidanceModal(target);
                }}
                className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold cursor-pointer"
              >
                + Catat Bimbingan Anak Wali Ini
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* ADD / EDIT GUIDANCE RECORD MODAL                                     */}
      {/* ==================================================================== */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full shadow-xl overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editingRecord
                  ? "Edit Catatan Bimbingan Anak Wali"
                  : "Tambah Catatan Bimbingan Anak Wali"}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveGuidance} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Pilih Anak Wali *
                  </label>
                  <select
                    value={studentId}
                    onChange={(e) => setStudentId(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white font-semibold"
                    required
                  >
                    {childProfiles.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} (Rata2 Nilai: {c.averageGrade})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal Bimbingan *
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Aspek / Kategori Bimbingan
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Akademik & Nilai">Akademik & Nilai</option>
                    <option value="Kedisiplinan & Kehadiran">
                      Kedisiplinan & Kehadiran
                    </option>
                    <option value="Karakter & Sosial">Karakter & Sosial</option>
                    <option value="Minat, Bakat & Karir">
                      Minat, Bakat & Karir
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status Tindak Lanjut
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Perlu Tindak Lanjut">
                      Perlu Tindak Lanjut
                    </option>
                    <option value="Dalam Pemantauan">Dalam Pemantauan</option>
                    <option value="Tuntas">Tuntas</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Topik / Fokus Bimbingan *
                </label>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Contoh: Pendampingan Peningkatan Nilai Matematika"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Uraian Hasil Bimbingan / Catatan Guru Wali
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ringkasan diskusi bersama anak wali..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Rencana Tindak Lanjut Bersama Guru Mapel / Orang Tua
                </label>
                <input
                  type="text"
                  value={followUpPlan}
                  onChange={(e) => setFollowUpPlan(e.target.value)}
                  placeholder="Contoh: Latihan tambahan & pantauan pekan depan"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={parentInvolved}
                  onChange={(e) => setParentInvolved(e.target.checked)}
                  className="rounded"
                />
                <span>Melibatkan komunikasi bersama Orang Tua / Wali Murid</span>
              </label>

              <div className="pt-3 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
                >
                  {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                  Simpan Catatan Bimbingan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

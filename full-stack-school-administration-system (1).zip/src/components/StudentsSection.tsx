"use client";

import React, { useState } from "react";
import * as XLSX from "xlsx";
import {
  Users,
  Upload,
  Download,
  Plus,
  Pencil,
  Trash2,
  Search,
  FileSpreadsheet,
  X,
  Loader2,
  Sparkles,
  ScanLine,
} from "lucide-react";
import {
  ActiveTab,
  ClassItem,
  SchoolSettingsData,
  StudentItem,
  ToastMessage,
} from "@/types/school";
import StudentBarcodeCard from "./StudentBarcodeCard";

interface StudentsSectionProps {
  settings: SchoolSettingsData;
  students: StudentItem[];
  classes: ClassItem[];
  onRefreshBootstrap: () => Promise<void>;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
  onNavigate: (
    tab: ActiveTab,
    classId?: number,
    barcodeOpts?: { mode: "mapel" | "wali"; subTab?: "scanner" | "cards" }
  ) => void;
}

export default function StudentsSection({
  settings,
  students,
  classes,
  onRefreshBootstrap,
  onNotify,
  onNavigate,
}: StudentsSectionProps) {
  const [filterClassId, setFilterClassId] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [barcodePreviewStudent, setBarcodePreviewStudent] =
    useState<StudentItem | null>(null);

  // Add / Edit Student Modal state
  const [studentModalOpen, setStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<StudentItem | null>(
    null
  );
  const [nisn, setNisn] = useState("");
  const [nis, setNis] = useState("");
  const [name, setName] = useState("");
  const [gender, setGender] = useState<"L" | "P">("L");
  const [classId, setClassId] = useState<number>(classes[0]?.id || 0);
  const [birthPlace, setBirthPlace] = useState("Umalulu");
  const [birthDate, setBirthDate] = useState("");
  const [parentName, setParentName] = useState("");
  const [address, setAddress] = useState("Kec. Umalulu");
  const [submitting, setSubmitting] = useState(false);

  // Import Modal state
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewRows, setPreviewRows] = useState<Record<string, string>[]>([]);
  const [defaultImportClassId, setDefaultImportClassId] = useState<number>(
    classes[0]?.id || 0
  );
  const [importing, setImporting] = useState(false);

  const filteredStudents = students.filter((s) => {
    const matchClass =
      filterClassId === "all" || s.classId === Number(filterClassId);
    const matchText =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nisn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.barcodeCode || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.className.toLowerCase().includes(searchQuery.toLowerCase());
    return matchClass && matchText;
  });

  function openAddStudent() {
    setEditingStudent(null);
    setNisn("");
    setNis("");
    setName("");
    setGender("L");
    setClassId(
      filterClassId !== "all" ? Number(filterClassId) : classes[0]?.id || 0
    );
    setBirthPlace("Umalulu");
    setBirthDate("");
    setParentName("");
    setAddress("Kec. Umalulu");
    setStudentModalOpen(true);
  }

  function openEditStudent(stu: StudentItem) {
    setEditingStudent(stu);
    setNisn(stu.nisn);
    setNis(stu.nis);
    setName(stu.name);
    setGender(stu.gender === "P" ? "P" : "L");
    setClassId(stu.classId);
    setBirthPlace(stu.birthPlace || "Umalulu");
    setBirthDate(stu.birthDate || "");
    setParentName(stu.parentName || "");
    setAddress(stu.address || "Kec. Umalulu");
    setStudentModalOpen(true);
  }

  async function handleSaveStudent(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        nisn,
        nis,
        name,
        gender,
        classId,
        birthPlace,
        birthDate,
        parentName,
        address,
      };
      const res = editingStudent
        ? await fetch(`/api/students/${editingStudent.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch("/api/students", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
      const data = await res.json();
      if (!res.ok) {
        onNotify({
          type: "error",
          title: "Gagal menyimpan siswa",
          description: data.error || "Periksa kembali data siswa.",
        });
        setSubmitting(false);
        return;
      }

      await onRefreshBootstrap();
      setStudentModalOpen(false);
      onNotify({
        type: "success",
        title: editingStudent
          ? "Data & Barcode siswa diperbarui"
          : "Siswa & Kartu Barcode otomatis dibuat",
        description: `${name} (${data.student?.barcodeCode || nisn}) tersimpan.`,
      });
    } catch {
      onNotify({ type: "error", title: "Koneksi gagal" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDeleteStudent(stu: StudentItem) {
    if (!confirm(`Hapus data siswa ${stu.name} (NISN: ${stu.nisn})?`)) return;
    try {
      const res = await fetch(`/api/students/${stu.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: "Data siswa dihapus",
        description: `${stu.name} telah dihapus dari sistem.`,
      });
    } catch {
      onNotify({ type: "error", title: "Gagal menghapus data siswa" });
    }
  }

  // Parse selected Excel/CSV file locally for instant preview
  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelectedFile(file);

    try {
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const parsed = XLSX.utils.sheet_to_json<Record<string, string>>(ws, {
        defval: "",
      });
      setPreviewRows(parsed);
    } catch {
      onNotify({
        type: "error",
        title: "Gagal membaca pratinjau file",
        description:
          "Pastikan menggunakan template .xlsx atau .csv yang disediakan.",
      });
    }
  }

  function loadInstantSampleRows() {
    setSelectedFile(null);
    const rand = Math.floor(100 + Math.random() * 899);
    setPreviewRows([
      {
        NISN: `012990${rand}1`,
        NIS: `26${rand.toString().slice(0, 2)}`,
        Nama_Lengkap: "Damianus Umbu Rauta",
        JK: "L",
        Kelas: classes[0]?.name || "VII-A",
        Tempat_Lahir: "Umalulu",
        Tanggal_Lahir: "2013-04-12",
        Nama_Orang_Tua: "Lukas Rauta",
        Alamat: "Desa Watupuda, Kec. Umalulu",
      },
      {
        NISN: `012990${rand}2`,
        NIS: `27${rand.toString().slice(0, 2)}`,
        Nama_Lengkap: "Aurelia Rambu Lodu",
        JK: "P",
        Kelas: classes[1]?.name || "VII-B",
        Tempat_Lahir: "Melolo",
        Tanggal_Lahir: "2013-08-19",
        Nama_Orang_Tua: "Yohanes Lodu",
        Alamat: "Kel. Lumbukore, Kec. Umalulu",
      },
    ]);
  }

  async function handleConfirmImport() {
    setImporting(true);
    try {
      let res: Response;
      if (selectedFile) {
        const fd = new FormData();
        fd.append("file", selectedFile);
        fd.append("defaultClassId", String(defaultImportClassId));
        res = await fetch("/api/students/import", {
          method: "POST",
          body: fd,
        });
      } else {
        res = await fetch("/api/students/import", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            rows: previewRows,
            defaultClassId: defaultImportClassId,
          }),
        });
      }

      const data = await res.json();
      if (!res.ok) {
        onNotify({
          type: "error",
          title: "Import gagal",
          description: data.error || "Periksa format template.",
        });
        setImporting(false);
        return;
      }

      await onRefreshBootstrap();
      setImportModalOpen(false);
      setSelectedFile(null);
      setPreviewRows([]);
      onNotify({
        type: "success",
        title: "Import Siswa & Generate Barcode Berhasil!",
        description: `${data.importedCount} siswa baru ditambahkan, ${data.updatedCount} diperbarui lengkap dengan Barcode otomatis.`,
      });
    } catch {
      onNotify({ type: "error", title: "Gagal mengunggah data import" });
    } finally {
      setImporting(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header & Template Import Action Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-1.5">
            <Users className="w-3.5 h-3.5" />
            Database Induk & Barcode Peserta Didik
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
            Data Siswa, Kartu Barcode & Import Template Resmi
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Setiap siswa yang ditambahkan atau di-import otomatis memperoleh
            Kode Barcode unik (
            <code className="font-mono-code font-semibold text-blue-700">
              SMPN1UML-NISN
            </code>
            ) siap cetak & scan.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() =>
              onNavigate("scan-barcode", undefined, {
                mode: "mapel",
                subTab: "cards",
              })
            }
            className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
          >
            <ScanLine className="w-4 h-4 text-emerald-400" />
            Cetak Semua Kartu Barcode
          </button>

          <a
            href="/api/students/template?format=xlsx"
            download
            className="px-4 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            Unduh Template (.xlsx)
          </a>

          <button
            onClick={() => {
              setPreviewRows([]);
              setSelectedFile(null);
              setImportModalOpen(true);
            }}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            Import Data Siswa
          </button>

          <button
            onClick={openAddStudent}
            className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Tambah Siswa
          </button>
        </div>
      </div>

      {/* Filter & Student Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setFilterClassId("all")}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer ${
                filterClassId === "all"
                  ? "bg-slate-900 text-white border-slate-900"
                  : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
              }`}
            >
              Semua ({students.length})
            </button>
            {classes.map((c) => (
              <button
                key={c.id}
                onClick={() => setFilterClassId(String(c.id))}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer ${
                  filterClassId === String(c.id)
                    ? "bg-blue-700 text-white border-blue-700"
                    : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                }`}
              >
                {c.name} ({c.studentCount})
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari NISN, Barcode, atau nama..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-sm text-slate-900"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                <th className="py-3.5 pl-6 pr-3">No</th>
                <th className="py-3.5 px-3">NISN / NIS</th>
                <th className="py-3.5 px-3">Nama Lengkap</th>
                <th className="py-3.5 px-3">Kode Barcode Sistem</th>
                <th className="py-3.5 px-3 text-center">JK</th>
                <th className="py-3.5 px-3 text-center">Kelas</th>
                <th className="py-3.5 pl-3 pr-6 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredStudents.map((stu, idx) => (
                <tr key={stu.id} className="hover:bg-slate-50/70">
                  <td className="py-3.5 pl-6 pr-3 text-xs text-slate-500">
                    {idx + 1}
                  </td>
                  <td className="py-3.5 px-3 font-mono-code text-xs">
                    <span className="font-semibold text-slate-900">
                      {stu.nisn}
                    </span>
                    <span className="block text-slate-400">
                      NIS: {stu.nis || "-"}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 font-semibold text-slate-900">
                    {stu.name}
                  </td>
                  <td className="py-3.5 px-3">
                    <button
                      type="button"
                      onClick={() => setBarcodePreviewStudent(stu)}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-blue-50 text-slate-800 hover:text-blue-700 border border-slate-200 font-mono-code text-xs font-semibold transition-colors cursor-pointer"
                    >
                      <ScanLine className="w-3.5 h-3.5 text-blue-600" />
                      {stu.barcodeCode}
                    </button>
                  </td>
                  <td className="py-3.5 px-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded-md text-xs font-bold ${
                        stu.gender === "P"
                          ? "bg-pink-50 text-pink-700"
                          : "bg-indigo-50 text-indigo-700"
                      }`}
                    >
                      {stu.gender}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 text-center">
                    <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200 text-xs font-bold">
                      {stu.className}
                    </span>
                  </td>
                  <td className="py-3.5 pl-3 pr-6 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setBarcodePreviewStudent(stu)}
                        title="Lihat & Unduh Kartu Barcode Siswa"
                        className="px-2.5 py-1.5 rounded-lg border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold cursor-pointer"
                      >
                        Barcode
                      </button>
                      <button
                        onClick={() => openEditStudent(stu)}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-blue-700 hover:bg-blue-50 cursor-pointer"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteStudent(stu)}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-rose-700 hover:bg-rose-50 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Single Student Barcode Card Modal */}
      {barcodePreviewStudent && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                Kartu Absensi Barcode Siswa
              </h3>
              <button
                type="button"
                onClick={() => setBarcodePreviewStudent(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <StudentBarcodeCard
              student={barcodePreviewStudent}
              settings={settings}
              onQuickScan={() => {
                const clsId = barcodePreviewStudent.classId;
                setBarcodePreviewStudent(null);
                onNavigate("scan-barcode", clsId, {
                  mode: "mapel",
                  subTab: "scanner",
                });
              }}
            />
          </div>
        </div>
      )}

      {/* Import Template Modal */}
      {importModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full shadow-xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className="w-5 h-5 text-emerald-700" />
                <h3 className="text-base font-bold text-slate-900">
                  Import Data Siswa dari Template Resmi
                </h3>
              </div>
              <button
                onClick={() => setImportModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto">
              {/* Step 1: Download Official Template */}
              <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-bold uppercase text-blue-800">
                    Langkah 1 — Unduh Template Resmi SMPN 1 Umalulu
                  </p>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Kolom standar: NISN, NIS, Nama_Lengkap, JK, Kelas,
                    Tempat_Lahir, Tanggal_Lahir, Nama_Orang_Tua, Alamat
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href="/api/students/template?format=xlsx"
                    download
                    className="px-3 py-2 rounded-xl bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Template .XLSX
                  </a>
                  <a
                    href="/api/students/template?format=csv"
                    download
                    className="px-3 py-2 rounded-xl bg-white border border-blue-300 text-blue-800 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    .CSV
                  </a>
                </div>
              </div>

              {/* Step 2: Upload File or Load Demo Sample */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold uppercase text-slate-700">
                    Langkah 2 — Pilih File Template (.xlsx / .csv)
                  </label>
                  <button
                    type="button"
                    onClick={loadInstantSampleRows}
                    className="text-xs font-semibold text-emerald-700 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Muat Contoh Data Siap Import
                  </button>
                </div>

                <label className="block border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-2xl p-6 text-center cursor-pointer transition-colors bg-slate-50/60">
                  <Upload className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-slate-900">
                    {selectedFile
                      ? `File dipilih: ${selectedFile.name}`
                      : "Klik untuk memilih file Excel (.xlsx) atau CSV (.csv)"}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Sistem otomatis men-generate Barcode unik (SMPN1UML-NISN)
                    untuk setiap siswa yang di-import
                  </p>
                  <input
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kelas Default (Digunakan bila kolom Kelas pada file dikosongkan)
                </label>
                <select
                  value={defaultImportClassId}
                  onChange={(e) =>
                    setDefaultImportClassId(Number(e.target.value))
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                >
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      Kelas {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Preview Table */}
              {previewRows.length > 0 && (
                <div>
                  <p className="text-xs font-bold text-slate-700 mb-2">
                    Pratinjau Data Siap Import ({previewRows.length} Baris):
                  </p>
                  <div className="border border-slate-200 rounded-xl overflow-x-auto max-h-48">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-600">
                        <tr>
                          <th className="py-2 px-3">NISN</th>
                          <th className="py-2 px-3">Nama Lengkap</th>
                          <th className="py-2 px-3">JK</th>
                          <th className="py-2 px-3">Kelas</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {previewRows.slice(0, 8).map((r, i) => (
                          <tr key={i}>
                            <td className="py-2 px-3 font-mono-code">
                              {r.NISN || r.nisn}
                            </td>
                            <td className="py-2 px-3 font-semibold">
                              {r.Nama_Lengkap || r.Nama || r.nama}
                            </td>
                            <td className="py-2 px-3">{r.JK || r.jk}</td>
                            <td className="py-2 px-3">{r.Kelas || r.kelas}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5">
              <button
                onClick={() => setImportModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmImport}
                disabled={
                  importing || (!selectedFile && previewRows.length === 0)
                }
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold flex items-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                {importing && <Loader2 className="w-4 h-4 animate-spin" />}
                Proses Import Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Add / Edit Student Modal */}
      {studentModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full shadow-xl overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editingStudent ? "Edit Data Siswa" : "Tambah Siswa Manual"}
              </h3>
              <button
                onClick={() => setStudentModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    NISN *
                  </label>
                  <input
                    type="text"
                    value={nisn}
                    onChange={(e) => setNisn(e.target.value)}
                    placeholder="0129510010"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    NIS Sekolah
                  </label>
                  <input
                    type="text"
                    value={nis}
                    onChange={(e) => setNis(e.target.value)}
                    placeholder="2610"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Lengkap Siswa *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Umbu Raka Pratama"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Jenis Kelamin *
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as "L" | "P")}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kelas *
                  </label>
                  <select
                    value={classId}
                    onChange={(e) => setClassId(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        Kelas {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tempat Lahir
                  </label>
                  <input
                    type="text"
                    value={birthPlace}
                    onChange={(e) => setBirthPlace(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal Lahir
                  </label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Orang Tua / Wali Murid
                  </label>
                  <input
                    type="text"
                    value={parentName}
                    onChange={(e) => setParentName(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Alamat Desa / Kelurahan
                  </label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setStudentModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
                >
                  {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                  Simpan Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

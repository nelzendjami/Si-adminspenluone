"use client";

import React, { useCallback, useEffect, useState } from "react";
import {
  CheckCircle2,
  Search,
  Save,
  Lock,
  Loader2,
  UserCheck,
  BookOpen,
  Calendar,
  Sparkles,
  Users,
  ScanLine,
} from "lucide-react";
import {
  ActiveTab,
  AttendanceRowItem,
  ClassItem,
  SessionUserData,
  SubjectItem,
  TeacherItem,
  ToastMessage,
} from "@/types/school";

interface AttendanceSectionProps {
  mode: "mapel" | "wali";
  classes: ClassItem[];
  teachers: TeacherItem[];
  subjects: SubjectItem[];
  currentUser: SessionUserData | null;
  initialClassId?: number | null;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
  onRefreshRecap: () => void;
  onNavigate: (
    tab: ActiveTab,
    classId?: number,
    barcodeOpts?: { mode: "mapel" | "wali"; subTab?: "scanner" | "cards" }
  ) => void;
}

export default function AttendanceSection({
  mode,
  classes,
  teachers,
  subjects,
  currentUser,
  initialClassId,
  onNotify,
  onRefreshRecap,
  onNavigate,
}: AttendanceSectionProps) {
  // Determine Guru Wali teachers assigned to a single class
  const waliTeachers = teachers.filter((t) => t.homeroomClassId !== null);

  const [selectedWaliTeacherId, setSelectedWaliTeacherId] = useState<number>(
    () => {
      if (currentUser?.role === "wali_kelas" && currentUser.teacherId) {
        return currentUser.teacherId;
      }
      return waliTeachers[0]?.id || 0;
    }
  );

  const [selectedClassId, setSelectedClassId] = useState<number>(() => {
    if (mode === "wali") {
      if (currentUser?.role === "wali_kelas" && currentUser.assignedClassId) {
        return currentUser.assignedClassId;
      }
      return waliTeachers[0]?.homeroomClassId || classes[0]?.id || 0;
    }
    return initialClassId || classes[0]?.id || 0;
  });

  const [selectedSubject, setSelectedSubject] = useState<string>(() => {
    if (currentUser?.teacherSubject) return currentUser.teacherSubject;
    return subjects[0]?.name || "Matematika";
  });

  const [selectedTeacherId, setSelectedTeacherId] = useState<number>(() => {
    const matchedSubj = subjects[0];
    return matchedSubj?.teacherId || teachers[0]?.id || 0;
  });

  const [selectedDate, setSelectedDate] = useState<string>(() =>
    new Date().toISOString().slice(0, 10)
  );

  const [rows, setRows] = useState<AttendanceRowItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [savingBulk, setSavingBulk] = useState(false);
  const [syncingStudentId, setSyncingStudentId] = useState<number | null>(null);

  // Sync class selection when switching modes or when logged-in Guru Wali changes
  useEffect(() => {
    if (mode === "wali") {
      if (currentUser?.role === "wali_kelas" && currentUser.assignedClassId) {
        setSelectedClassId(currentUser.assignedClassId);
        if (currentUser.teacherId) {
          setSelectedWaliTeacherId(currentUser.teacherId);
        }
      } else {
        const chosenWali =
          teachers.find(
            (t) => t.id === selectedWaliTeacherId && t.homeroomClassId
          ) || teachers.find((t) => t.homeroomClassId !== null);
        if (chosenWali && chosenWali.homeroomClassId) {
          setSelectedWaliTeacherId(chosenWali.id);
          setSelectedClassId(chosenWali.homeroomClassId);
        }
      }
    } else if (initialClassId) {
      setSelectedClassId(initialClassId);
    }
  }, [mode, currentUser, initialClassId, teachers, selectedWaliTeacherId]);

  // Update default teacher when subject changes in Mapel mode
  useEffect(() => {
    if (mode === "mapel") {
      const subjObj = subjects.find((s) => s.name === selectedSubject);
      if (subjObj?.teacherId) {
        setSelectedTeacherId(subjObj.teacherId);
      } else {
        const bySubject = teachers.find((t) => t.subject === selectedSubject);
        if (bySubject) setSelectedTeacherId(bySubject.id);
      }
    }
  }, [mode, selectedSubject, subjects, teachers]);

  const fetchSheet = useCallback(async () => {
    if (!selectedClassId) {
      setRows([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const params = new URLSearchParams({
        type: mode,
        classId: String(selectedClassId),
        date: selectedDate,
        subjectName: mode === "wali" ? "Guru Wali" : selectedSubject,
      });
      const res = await fetch(`/api/attendance?${params.toString()}`);
      const data = await res.json();
      if (res.ok && Array.isArray(data.rows)) {
        setRows(data.rows);
      }
    } catch {
      onNotify({
        type: "error",
        title: "Gagal memuat daftar hadir",
        description: "Periksa koneksi server lalu coba kembali.",
      });
    } finally {
      setLoading(false);
    }
  }, [mode, selectedClassId, selectedDate, selectedSubject, onNotify]);

  useEffect(() => {
    fetchSheet();
  }, [fetchSheet]);

  const activeClass = classes.find((c) => c.id === selectedClassId) || null;
  const activeTeacher =
    mode === "wali"
      ? teachers.find((t) => t.id === activeClass?.homeroomTeacherId) || null
      : teachers.find((t) => t.id === selectedTeacherId) || null;

  // Optimistic single status update
  async function handleStatusToggle(
    studentId: number,
    newStatus: "H" | "S" | "I" | "A"
  ) {
    const previousRows = [...rows];
    const targetRow = rows.find((r) => r.studentId === studentId);
    if (!targetRow) return;

    setRows((prev) =>
      prev.map((r) =>
        r.studentId === studentId
          ? { ...r, status: newStatus, isRecorded: true }
          : r
      )
    );
    setSyncingStudentId(studentId);

    try {
      const res = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "single",
          studentId,
          classId: selectedClassId,
          attendanceType: mode,
          subjectName: mode === "wali" ? "Guru Wali" : selectedSubject,
          teacherId: activeTeacher?.id || null,
          recordedBy:
            activeTeacher?.name || currentUser?.fullName || "Guru Wali",
          date: selectedDate,
          status: newStatus,
          notes: targetRow.notes,
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Gagal menyimpan status");
      }
      onRefreshRecap();
    } catch (e: unknown) {
      setRows(previousRows);
      onNotify({
        type: "error",
        title: "Gagal menyimpan perubahan",
        description: e instanceof Error ? e.message : "Terjadi kesalahan",
      });
    } finally {
      setSyncingStudentId(null);
    }
  }

  // Optimistic note blur save
  async function handleNoteBlur(studentId: number, notes: string) {
    const row = rows.find((r) => r.studentId === studentId);
    if (!row) return;
    setSyncingStudentId(studentId);
    try {
      await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "single",
          studentId,
          classId: selectedClassId,
          attendanceType: mode,
          subjectName: mode === "wali" ? "Guru Wali" : selectedSubject,
          teacherId: activeTeacher?.id || null,
          recordedBy:
            activeTeacher?.name || currentUser?.fullName || "Guru Wali",
          date: selectedDate,
          status: row.status,
          notes,
        }),
      });
    } finally {
      setSyncingStudentId(null);
    }
  }

  // Bulk Save All / Mark All Present
  async function handleBulkSave(forceAllPresent = false) {
    if (rows.length === 0) return;
    setSavingBulk(true);
    const updatedRows: AttendanceRowItem[] = rows.map((r) => ({
      ...r,
      status: forceAllPresent ? "H" : r.status,
      notes: forceAllPresent ? "" : r.notes,
      isRecorded: true,
    }));
    setRows(updatedRows);

    try {
      const res = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "bulk",
          classId: selectedClassId,
          attendanceType: mode,
          subjectName: mode === "wali" ? "Guru Wali" : selectedSubject,
          teacherId: activeTeacher?.id || null,
          recordedBy:
            activeTeacher?.name || currentUser?.fullName || "Guru Wali",
          date: selectedDate,
          entries: updatedRows.map((r) => ({
            studentId: r.studentId,
            status: r.status,
            notes: r.notes,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menyimpan absensi");

      onRefreshRecap();
      onNotify({
        type: "success",
        title: forceAllPresent
          ? "Seluruh siswa ditandai Hadir"
          : "Absensi berhasil disimpan",
        description: `${updatedRows.length} siswa Kelas ${
          activeClass?.name || ""
        } tersimpan ke database PostgreSQL.`,
      });
    } catch (e: unknown) {
      onNotify({
        type: "error",
        title: "Gagal menyimpan absensi",
        description: e instanceof Error ? e.message : "Terjadi kesalahan",
      });
    } finally {
      setSavingBulk(false);
    }
  }

  const filteredRows = rows.filter(
    (r) =>
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.nisn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (r.barcodeCode || "").toLowerCase().includes(searchQuery.toLowerCase())
  );

  const countH = rows.filter((r) => r.status === "H").length;
  const countS = rows.filter((r) => r.status === "S").length;
  const countI = rows.filter((r) => r.status === "I").length;
  const countA = rows.filter((r) => r.status === "A").length;

  const statusButtons: Array<{
    code: "H" | "S" | "I" | "A";
    label: string;
    activeClass: string;
  }> = [
    {
      code: "H",
      label: "Hadir",
      activeClass: "bg-emerald-600 text-white border-emerald-600 shadow-xs",
    },
    {
      code: "S",
      label: "Sakit",
      activeClass: "bg-sky-600 text-white border-sky-600 shadow-xs",
    },
    {
      code: "I",
      label: "Izin",
      activeClass: "bg-amber-500 text-white border-amber-500 shadow-xs",
    },
    {
      code: "A",
      label: "Alpa",
      activeClass: "bg-rose-600 text-white border-rose-600 shadow-xs",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner Distinguishing Absensi Mata Pelajaran vs Absensi Guru Wali (1 Kelas) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              {mode === "mapel" ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                  <BookOpen className="w-3.5 h-3.5" />
                  Opsi A • Absensi Mata Pelajaran (Pilih Kelas)
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <Lock className="w-3.5 h-3.5" />
                  Opsi B • Absensi Guru Wali (Khusus 1 Kelas Saja)
                </span>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              {mode === "mapel"
                ? "Absensi Mata Pelajaran Sesuai Kelas Pilihan"
                : "Absensi Guru Wali (Satu Kelas Saja)"}
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              {mode === "mapel"
                ? "Pilih kelas tujuan, mata pelajaran, dan tanggal pertemuan untuk mencatat kehadiran siswa."
                : "Setiap Guru Wali hanya memiliki akses absensi pendampingan pada satu kelas binaan yang ditugaskan."}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() =>
                onNavigate("scan-barcode", selectedClassId, {
                  mode,
                  subTab: "scanner",
                })
              }
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              <ScanLine className="w-4 h-4 text-emerald-400" />
              Scan Barcode Siswa
            </button>
            <button
              type="button"
              onClick={() => handleBulkSave(true)}
              disabled={savingBulk || rows.length === 0}
              className="px-4 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              Hadir Semua
            </button>
            <button
              type="button"
              onClick={() => handleBulkSave(false)}
              disabled={savingBulk || rows.length === 0}
              className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-semibold shadow-xs transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {savingBulk ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              Simpan Absensi
            </button>
          </div>
        </div>

        {/* Filter Controls */}
        {mode === "mapel" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Pilih Kelas
              </label>
              <select
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    Kelas {c.name} ({c.studentCount} Siswa)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Mata Pelajaran
              </label>
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {subjects.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Guru Mata Pelajaran (NIP)
              </label>
              <select
                value={selectedTeacherId}
                onChange={(e) => setSelectedTeacherId(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} — NIP. {t.nip}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Tanggal Pertemuan
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>
          </div>
        ) : (
          /* Single-Class Guru Wali Controls */
          <div className="pt-5 space-y-4">
            {currentUser?.role === "wali_kelas" && (
              <div className="p-4 rounded-xl bg-emerald-50/80 border border-emerald-200 flex items-center gap-3 text-sm text-emerald-900">
                <Lock className="w-5 h-5 text-emerald-700 shrink-0" />
                <div>
                  <strong>Mode Akun Guru Wali Aktif:</strong> Anda masuk sebagai{" "}
                  <strong>{currentUser.fullName}</strong> dan terkunci secara
                  otomatis hanya untuk{" "}
                  <strong>Kelas {currentUser.assignedClassName}</strong> (1
                  kelas saja).
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Nama Guru Wali (NIP)
                </label>
                <select
                  value={selectedWaliTeacherId}
                  disabled={currentUser?.role === "wali_kelas"}
                  onChange={(e) => {
                    const tId = Number(e.target.value);
                    setSelectedWaliTeacherId(tId);
                    const found = waliTeachers.find((w) => w.id === tId);
                    if (found?.homeroomClassId) {
                      setSelectedClassId(found.homeroomClassId);
                    }
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white disabled:bg-slate-100 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                >
                  {waliTeachers.map((wt) => (
                    <option key={wt.id} value={wt.id}>
                      {wt.name} (Guru Wali {wt.homeroomClassName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Kelas Binaan Guru Wali (1 Kelas Saja)
                </label>
                <div className="w-full px-3.5 py-2.5 rounded-xl border border-emerald-300 bg-emerald-50/60 text-sm font-bold text-emerald-900 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-emerald-700" />
                    Kelas {activeClass?.name || "-"} ({activeClass?.room || "-"})
                  </span>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-white border border-emerald-200 text-emerald-700">
                    1 Kelas Saja
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Tanggal Absensi Guru Wali
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Live Attendance Counters + Search Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-800 text-xs font-bold">
              Total: {rows.length} Siswa
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
              Hadir: {countH}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-sky-50 text-sky-700 border border-sky-200 text-xs font-bold">
              Sakit: {countS}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 text-xs font-bold">
              Izin: {countI}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold">
              Alpa: {countA}
            </span>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari siswa / NISN / barcode..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </div>

        {/* Loading / Empty / Attendance Table */}
        {loading ? (
          <div className="p-12 flex flex-col items-center justify-center text-slate-500">
            <Loader2 className="w-7 h-7 animate-spin text-blue-600 mb-3" />
            <p className="text-sm font-medium">
              Memuat lembar absensi Kelas {activeClass?.name || ""}...
            </p>
          </div>
        ) : rows.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Belum Ada Siswa di Kelas {activeClass?.name || "Ini"}
            </h3>
            <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
              Tambahkan siswa secara manual atau gunakan fitur Import Template
              Excel/CSV terlebih dahulu untuk mulai mencatat absensi.
            </p>
            <button
              onClick={() => onNavigate("siswa")}
              className="mt-4 px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold cursor-pointer"
            >
              Buka Menu Data Siswa & Import
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  <th className="py-3.5 pl-6 pr-3 w-12">No</th>
                  <th className="py-3.5 px-3">NISN / Barcode</th>
                  <th className="py-3.5 px-3">Nama Peserta Didik</th>
                  <th className="py-3.5 px-3 text-center">L/P</th>
                  <th className="py-3.5 px-3">Status Kehadiran</th>
                  <th className="py-3.5 pl-3 pr-6">Keterangan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredRows.map((row, idx) => (
                  <tr
                    key={row.studentId}
                    className="hover:bg-slate-50/70 transition-colors"
                  >
                    <td className="py-3.5 pl-6 pr-3 text-xs font-medium text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="py-3.5 px-3 font-mono-code text-xs text-slate-700">
                      <span className="font-semibold">{row.nisn}</span>
                      <span className="block text-[11px] text-blue-700">
                        {row.barcodeCode}
                      </span>
                    </td>
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900">
                          {row.name}
                        </span>
                        {syncingStudentId === row.studentId ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                        ) : (
                          row.isRecorded && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          )
                        )}
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-md text-xs font-bold ${
                          row.gender === "P"
                            ? "bg-pink-50 text-pink-700"
                            : "bg-indigo-50 text-indigo-700"
                        }`}
                      >
                        {row.gender}
                      </span>
                    </td>
                    <td className="py-3.5 px-3">
                      <div className="inline-flex items-center gap-1.5">
                        {statusButtons.map((btn) => {
                          const isSelected = row.status === btn.code;
                          return (
                            <button
                              key={btn.code}
                              type="button"
                              onClick={() =>
                                handleStatusToggle(row.studentId, btn.code)
                              }
                              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                                isSelected
                                  ? btn.activeClass
                                  : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                              }`}
                            >
                              {btn.label}
                            </button>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-3.5 pl-3 pr-6 min-w-[200px]">
                      <input
                        type="text"
                        value={row.notes}
                        onChange={(e) => {
                          const val = e.target.value;
                          setRows((prev) =>
                            prev.map((item) =>
                              item.studentId === row.studentId
                                ? { ...item, notes: val }
                                : item
                            )
                          );
                        }}
                        onBlur={(e) =>
                          handleNoteBlur(row.studentId, e.target.value)
                        }
                        placeholder="Catatan (opsional)..."
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Footer Info Bar */}
        {activeTeacher && (
          <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
            <span>
              {mode === "wali" ? "Guru Wali:" : "Guru Mata Pelajaran:"}{" "}
              <strong className="text-slate-900">{activeTeacher.name}</strong>{" "}
              <span className="font-mono-code">
                (NIP. {activeTeacher.nip})
              </span>
            </span>
            <span className="text-emerald-700 font-medium">
              Klik status langsung menyimpan otomatis ke PostgreSQL
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { BrowserMultiFormatReader } from "@zxing/library";
import {
  ScanLine,
  Camera,
  CameraOff,
  Upload,
  Printer,
  Search,
  Volume2,
  VolumeX,
  CheckCircle2,
  Lock,
  BookOpen,
  UserCheck,
  Loader2,
  CreditCard,
  Sparkles,
  Calendar,
} from "lucide-react";
import {
  ClassItem,
  ScannedLogEntry,
  SchoolSettingsData,
  SessionUserData,
  StudentItem,
  SubjectItem,
  TeacherItem,
  ToastMessage,
} from "@/types/school";
import StudentBarcodeCard from "./StudentBarcodeCard";

interface StudentBarcodeSectionProps {
  settings: SchoolSettingsData;
  classes: ClassItem[];
  teachers: TeacherItem[];
  subjects: SubjectItem[];
  students: StudentItem[];
  currentUser: SessionUserData | null;
  initialSubTab?: "scanner" | "cards";
  initialMode?: "mapel" | "wali";
  initialClassId?: number | null;
  onRefreshBootstrap: () => Promise<void>;
  onRefreshRecap: () => void;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
}

export default function StudentBarcodeSection({
  settings,
  classes,
  teachers,
  subjects,
  students,
  currentUser,
  initialSubTab = "scanner",
  initialMode = "mapel",
  initialClassId = null,
  onRefreshBootstrap,
  onRefreshRecap,
  onNotify,
}: StudentBarcodeSectionProps) {
  const [subTab, setSubTab] = useState<"scanner" | "cards">(initialSubTab);

  // Target session config: Option A = Absensi Mata Pelajaran | Option B = Absensi Guru Wali (1 Kelas)
  const guruWaliList = teachers.filter((t) => t.homeroomClassId !== null);

  const [attendanceMode, setAttendanceMode] = useState<"mapel" | "wali">(() =>
    currentUser?.role === "wali_kelas" ? "wali" : initialMode
  );

  const [selectedGuruWaliId, setSelectedGuruWaliId] = useState<number>(() => {
    if (currentUser?.role === "wali_kelas" && currentUser.teacherId) {
      return currentUser.teacherId;
    }
    return guruWaliList[0]?.id || 0;
  });

  const [selectedClassId, setSelectedClassId] = useState<number>(() => {
    if (currentUser?.role === "wali_kelas" && currentUser.assignedClassId) {
      return currentUser.assignedClassId;
    }
    if (initialClassId) return initialClassId;
    return classes[0]?.id || 0;
  });

  const [lockMapelClass, setLockMapelClass] = useState<boolean>(false);
  const [selectedSubject, setSelectedSubject] = useState<string>(
    subjects[0]?.name || "Matematika"
  );
  const [selectedTeacherId, setSelectedTeacherId] = useState<number>(
    subjects[0]?.teacherId || teachers[0]?.id || 0
  );
  const [selectedDate, setSelectedDate] = useState<string>(() =>
    new Date().toISOString().slice(0, 10)
  );

  // Scanner controls & states
  const [barcodeInput, setBarcodeInput] = useState<string>("");
  const [scanning, setScanning] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scanLogs, setScanLogs] = useState<ScannedLogEntry[]>([]);
  const [lastScanned, setLastScanned] = useState<ScannedLogEntry | null>(null);

  // Generator & Print Filter States
  const [cardClassFilter, setCardClassFilter] = useState<string>("all");
  const [cardSearch, setCardSearch] = useState<string>("");

  const inputRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const zxingReaderRef = useRef<BrowserMultiFormatReader | null>(null);
  const lastDecodedCodeRef = useRef<{ code: string; time: number }>({
    code: "",
    time: 0,
  });

  // Sync class when Guru Wali mode or logged-in Guru Wali changes
  useEffect(() => {
    if (attendanceMode === "wali") {
      if (currentUser?.role === "wali_kelas" && currentUser.assignedClassId) {
        setSelectedClassId(currentUser.assignedClassId);
        if (currentUser.teacherId) {
          setSelectedGuruWaliId(currentUser.teacherId);
        }
      } else {
        const gw =
          guruWaliList.find((t) => t.id === selectedGuruWaliId) ||
          guruWaliList[0];
        if (gw?.homeroomClassId) {
          setSelectedGuruWaliId(gw.id);
          setSelectedClassId(gw.homeroomClassId);
        }
      }
    }
  }, [attendanceMode, currentUser, selectedGuruWaliId, guruWaliList]);

  // Play crisp WebAudio confirmation tone
  const playScanBeep = useCallback(
    (isSuccess: boolean) => {
      if (!soundEnabled || typeof window === "undefined") return;
      try {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = isSuccess ? "sine" : "sawtooth";
        osc.frequency.setValueAtTime(isSuccess ? 880 : 240, ctx.currentTime);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.19);
      } catch {
        // ignore audio policy block
      }
    },
    [soundEnabled]
  );

  // Core Barcode Scan Submission to /api/attendance/scan
  const submitScannedCode = useCallback(
    async (rawCode: string) => {
      const code = rawCode.trim();
      if (!code) return;

      setScanning(true);
      try {
        const res = await fetch("/api/attendance/scan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            code,
            attendanceType: attendanceMode,
            classId: selectedClassId,
            lockClass: attendanceMode === "wali" ? true : lockMapelClass,
            subjectName:
              attendanceMode === "wali" ? "Guru Wali" : selectedSubject,
            teacherId: selectedTeacherId,
            date: selectedDate,
            status: "H",
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          playScanBeep(false);
          onNotify({
            type: "error",
            title: "Scan Barcode Ditolak",
            description: data.error || "Barcode tidak dikenali.",
          });
          return;
        }

        playScanBeep(true);
        const entry: ScannedLogEntry = {
          logId: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          scannedAt: data.scannedAt,
          alreadyRecorded: data.alreadyRecorded,
          attendanceType: data.session.attendanceType,
          subjectName: data.session.subjectName,
          date: data.session.date,
          status: data.session.status,
          classPresentCount: data.session.classPresentCount,
          classTotalStudents: data.session.classTotalStudents,
          student: data.student,
        };

        setLastScanned(entry);
        setScanLogs((prev) => [entry, ...prev].slice(0, 30));
        setBarcodeInput("");
        onRefreshRecap();

        onNotify({
          type: "success",
          title: `Hadir Tercatat: ${data.student.name}`,
          description: `Kelas ${data.student.className} • ${
            data.session.subjectName
          } (${data.scannedAt})`,
        });
      } catch {
        playScanBeep(false);
        onNotify({
          type: "error",
          title: "Koneksi Gagal",
          description: "Gagal menghubungi server absensi barcode.",
        });
      } finally {
        setScanning(false);
        inputRef.current?.focus();
      }
    },
    [
      attendanceMode,
      selectedClassId,
      lockMapelClass,
      selectedSubject,
      selectedTeacherId,
      selectedDate,
      playScanBeep,
      onRefreshRecap,
      onNotify,
    ]
  );

  // Stop camera helper
  const stopCamera = useCallback(() => {
    if (zxingReaderRef.current) {
      zxingReaderRef.current.reset();
      zxingReaderRef.current = null;
    }
    setCameraActive(false);
  }, []);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  // Start Live Camera Barcode/QR Scanner
  async function startCamera() {
    setCameraError(null);
    setCameraActive(true);
    try {
      const reader = new BrowserMultiFormatReader();
      zxingReaderRef.current = reader;

      await reader.decodeFromVideoDevice(
        null,
        videoRef.current!,
        (result) => {
          if (result) {
            const text = result.getText().trim();
            const now = Date.now();
            // Prevent duplicate rapid triggers within 2.5 seconds for same code
            if (
              text === lastDecodedCodeRef.current.code &&
              now - lastDecodedCodeRef.current.time < 2500
            ) {
              return;
            }
            lastDecodedCodeRef.current = { code: text, time: now };
            submitScannedCode(text);
          }
        }
      );
    } catch {
      setCameraError(
        "Kamera tidak dapat diakses pada perangkat/browser ini. Gunakan Alat Scanner USB, Upload Gambar Kartu Barcode (.PNG), atau Klik Uji Scan Cepat di bawah."
      );
      setCameraActive(false);
    }
  }

  // Decode uploaded image of a student barcode / QR card (.PNG / .JPG)
  async function handleDecodeBarcodeImage(
    e: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";

    const objectUrl = URL.createObjectURL(file);
    try {
      const reader = new BrowserMultiFormatReader();
      const result = await reader.decodeFromImageUrl(objectUrl);
      const decodedText = result.getText();
      await submitScannedCode(decodedText);
    } catch {
      onNotify({
        type: "error",
        title: "Barcode pada gambar tidak terbaca",
        description:
          "Pastikan mengunggah gambar Kartu Barcode PNG/JPG yang jelas.",
      });
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  }

  // Regenerate Student Barcode Code via API
  async function handleRegenerateStudentBarcode(stu: StudentItem) {
    try {
      const res = await fetch(`/api/students/${stu.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          regenerateBarcode: true,
          withRandomSuffix: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal generate barcode");

      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: "Kode Barcode Baru Berhasil Digenerate!",
        description: `${stu.name} kini memiliki kode ${data.student.barcodeCode}.`,
      });
    } catch {
      onNotify({
        type: "error",
        title: "Gagal men-generate ulang barcode siswa",
      });
    }
  }

  const activeClassObj = classes.find((c) => c.id === selectedClassId) || null;
  const rosterForQuickTest = students.filter(
    (s) => s.classId === selectedClassId
  );

  const filteredCardStudents = students.filter((s) => {
    const matchCls =
      cardClassFilter === "all" || s.classId === Number(cardClassFilter);
    const q = cardSearch.toLowerCase();
    const matchText =
      s.name.toLowerCase().includes(q) ||
      s.nisn.toLowerCase().includes(q) ||
      s.barcodeCode.toLowerCase().includes(q) ||
      s.className.toLowerCase().includes(q);
    return matchCls && matchText;
  });

  return (
    <div className="space-y-6">
      {/* Top Mode Switcher Header (Hidden on Print) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-1.5">
              <ScanLine className="w-3.5 h-3.5" />
              Sistem Absensi Barcode Otomatis Siswa
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              Scan Barcode Kehadiran & Generator Kartu Barcode Siswa
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Setiap siswa otomatis memiliki kode barcode unik dari sistem (
              <code className="font-mono-code font-semibold text-blue-700">
                SMPN1UML-NISN
              </code>
              ) yang dapat dicetak serta di-scan untuk Absensi Mata Pelajaran
              maupun Absensi Guru Wali.
            </p>
          </div>

          <div className="inline-flex p-1.5 rounded-2xl bg-slate-100 border border-slate-200 shrink-0 self-start">
            <button
              type="button"
              onClick={() => setSubTab("scanner")}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
                subTab === "scanner"
                  ? "bg-blue-700 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <ScanLine className="w-4 h-4" />
              Mesin Scan Barcode
            </button>
            <button
              type="button"
              onClick={() => {
                stopCamera();
                setSubTab("cards");
              }}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
                subTab === "cards"
                  ? "bg-blue-700 text-white shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <CreditCard className="w-4 h-4" />
              Kartu Barcode Siswa ({students.length})
            </button>
          </div>
        </div>
      </div>

      {/* ==================================================================== */}
      {/* SUB-TAB 1: MESIN SCAN BARCODE ABSENSI                                */}
      {/* ==================================================================== */}
      {subTab === "scanner" && (
        <div className="space-y-6 no-print">
          {/* Session Target Selector: Option A (Absensi Mapel) vs Option B (Absensi Guru Wali) */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  1. Pilih Jenis Sesi Absensi Barcode
                </h2>
                <p className="text-xs text-slate-500">
                  Pilih target pencatatan antara Absensi Mata Pelajaran atau
                  Absensi Guru Wali (1 Kelas Saja)
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setAttendanceMode("mapel")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold border flex items-center gap-2 cursor-pointer transition-all ${
                    attendanceMode === "mapel"
                      ? "bg-blue-700 text-white border-blue-700"
                      : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  Opsi A: Absensi Mata Pelajaran
                </button>
                <button
                  type="button"
                  onClick={() => setAttendanceMode("wali")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold border flex items-center gap-2 cursor-pointer transition-all ${
                    attendanceMode === "wali"
                      ? "bg-emerald-600 text-white border-emerald-600"
                      : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  Opsi B: Absensi Guru Wali (1 Kelas)
                </button>
              </div>
            </div>

            {attendanceMode === "mapel" ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Pilih Kelas Simulasi / Filter
                  </label>
                  <select
                    value={selectedClassId}
                    onChange={(e) => setSelectedClassId(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-900"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        Kelas {c.name} ({c.studentCount} Siswa)
                      </option>
                    ))}
                  </select>
                  <label className="mt-2 inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={lockMapelClass}
                      onChange={(e) => setLockMapelClass(e.target.checked)}
                      className="rounded"
                    />
                    <span>Tolak jika siswa dari kelas lain</span>
                  </label>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Mata Pelajaran
                  </label>
                  <select
                    value={selectedSubject}
                    onChange={(e) => {
                      const val = e.target.value;
                      setSelectedSubject(val);
                      const subj = subjects.find((s) => s.name === val);
                      if (subj?.teacherId) setSelectedTeacherId(subj.teacherId);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-900"
                  >
                    {subjects.map((s) => (
                      <option key={s.id} value={s.name}>
                        {s.name} ({s.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Guru Mata Pelajaran (NIP)
                  </label>
                  <select
                    value={selectedTeacherId}
                    onChange={(e) =>
                      setSelectedTeacherId(Number(e.target.value))
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
                  >
                    {teachers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} — NIP. {t.nip}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Tanggal Scan
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Nama Guru Wali (NIP)
                  </label>
                  <select
                    value={selectedGuruWaliId}
                    disabled={currentUser?.role === "wali_kelas"}
                    onChange={(e) => {
                      const tId = Number(e.target.value);
                      setSelectedGuruWaliId(tId);
                      const gw = guruWaliList.find((w) => w.id === tId);
                      if (gw?.homeroomClassId) {
                        setSelectedClassId(gw.homeroomClassId);
                      }
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white disabled:bg-slate-100 text-sm font-semibold text-slate-900"
                  >
                    {guruWaliList.map((gw) => (
                      <option key={gw.id} value={gw.id}>
                        {gw.name} (Guru Wali {gw.homeroomClassName})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Kelas Binaan Guru Wali (Terkunci 1 Kelas Saja)
                  </label>
                  <div className="px-3.5 py-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-sm font-bold text-emerald-900 flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-emerald-700" />
                      Kelas {activeClassObj?.name || "-"}
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-white border border-emerald-200 text-emerald-700">
                      1 Kelas Saja
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Tanggal Absensi Guru Wali
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Scanner Input + Camera + Live Result Split Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left 7 Columns: Hardware Wedge Input, Live Camera, Image Upload & Quick Test */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      2. Arahkan Scanner Barcode / Kamera / Upload Kartu
                    </h2>
                    <p className="text-xs text-slate-500">
                      Mendukung Barcode Scanner USB/Wireless, Kamera Live,
                      maupun File Kartu PNG
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSoundEnabled(!soundEnabled)}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer"
                  >
                    {soundEnabled ? (
                      <>
                        <Volume2 className="w-4 h-4 text-emerald-600" />
                        Suara Beep Aktif
                      </>
                    ) : (
                      <>
                        <VolumeX className="w-4 h-4 text-slate-400" />
                        Suara Nonaktif
                      </>
                    )}
                  </button>
                </div>

                {/* Auto-Focus Hardware Barcode Scanner Form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    submitScannedCode(barcodeInput);
                  }}
                  className="flex flex-col sm:flex-row gap-3"
                >
                  <div className="relative flex-1">
                    <ScanLine className="w-5 h-5 text-blue-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      ref={inputRef}
                      type="text"
                      value={barcodeInput}
                      onChange={(e) => setBarcodeInput(e.target.value)}
                      placeholder="Scan barcode di sini atau ketik SMPN1UML-0118421001..."
                      autoFocus
                      className="w-full pl-11 pr-4 py-3 rounded-xl border-2 border-blue-300 focus:border-blue-700 focus:outline-none font-mono-code text-sm font-semibold text-slate-900"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={scanning || !barcodeInput.trim()}
                    className="px-5 py-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-bold flex items-center justify-center gap-2 shrink-0 disabled:opacity-50 cursor-pointer"
                  >
                    {scanning ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4" />
                    )}
                    Proses Scan
                  </button>
                </form>

                {/* Camera & Image File Decode Buttons */}
                <div className="flex flex-wrap items-center gap-3">
                  {!cameraActive ? (
                    <button
                      type="button"
                      onClick={startCamera}
                      className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer"
                    >
                      <Camera className="w-4 h-4" />
                      Aktifkan Kamera Scanner
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={stopCamera}
                      className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer"
                    >
                      <CameraOff className="w-4 h-4" />
                      Matikan Kamera
                    </button>
                  )}

                  <label className="px-4 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors">
                    <Upload className="w-4 h-4" />
                    Scan dari File Gambar Kartu (.PNG / .JPG)
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleDecodeBarcodeImage}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Active Camera Viewport */}
                {cameraActive && (
                  <div className="relative rounded-2xl overflow-hidden bg-slate-950 border-2 border-blue-500 aspect-video max-h-72 flex items-center justify-center">
                    <video
                      ref={videoRef}
                      className="w-full h-full object-cover"
                      muted
                      playsInline
                    />
                    <div className="inset-x-12 top-1/2 -translate-y-1/2 h-0.5 bg-emerald-400 shadow-[0_0_12px_#34d399] absolute pointer-events-none" />
                    <span className="absolute bottom-3 px-3 py-1 rounded-full bg-slate-900/80 text-white text-[11px] font-semibold">
                      Arahkan Kartu Barcode / QR Siswa ke garis hijau
                    </span>
                  </div>
                )}

                {cameraError && (
                  <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                    {cameraError}
                  </div>
                )}
              </div>

              {/* Instant One-Click Student Barcode Simulator for Selected Class */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      Simulasi Scan Barcode Cepat — Kelas{" "}
                      {activeClassObj?.name || "-"}
                    </h3>
                    <p className="text-xs text-slate-500">
                      Klik tombol Scan pada kartu siswa di bawah untuk menguji
                      pencatatan barcode otomatis ke database
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setCardClassFilter(String(selectedClassId));
                      setSubTab("cards");
                    }}
                    className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
                  >
                    Lihat Kartu Penuh →
                  </button>
                </div>

                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                  {rosterForQuickTest.map((stu) => (
                    <div
                      key={stu.id}
                      className="py-2.5 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 truncate">
                          {stu.name}
                        </p>
                        <p className="font-mono-code text-xs text-slate-500">
                          {stu.barcodeCode}
                        </p>
                      </div>
                      <button
                        type="button"
                        disabled={scanning}
                        onClick={() => submitScannedCode(stu.barcodeCode)}
                        className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0 cursor-pointer"
                      >
                        <ScanLine className="w-3.5 h-3.5" />
                        Scan Barcode
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right 5 Columns: Latest Scanned Student Card + Real-time Log */}
            <div className="lg:col-span-5 space-y-6">
              {/* Latest Scanned Verification Card */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6">
                <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4">
                  Status Pemindaian Terakhir
                </h2>

                {!lastScanned ? (
                  <div className="py-10 text-center">
                    <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center mx-auto mb-3">
                      <ScanLine className="w-7 h-7" />
                    </div>
                    <p className="text-sm font-bold text-slate-900">
                      Menunggu Scan Barcode Siswa...
                    </p>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                      Scan menggunakan alat barcode, upload gambar kartu PNG,
                      atau klik tombol Scan Barcode pada daftar siswa di kiri.
                    </p>
                  </div>
                ) : (
                  <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-300 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-600 text-white text-xs font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        HADIR TERCATAT
                      </span>
                      <span className="font-mono-code text-xs font-bold text-emerald-900">
                        Pukul {lastScanned.scannedAt}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-lg font-extrabold text-slate-900">
                        {lastScanned.student.name}
                      </h3>
                      <p className="font-mono-code text-xs text-slate-700 mt-0.5">
                        Barcode: <strong>{lastScanned.student.barcodeCode}</strong>{" "}
                        • NISN: {lastScanned.student.nisn}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-emerald-200 flex items-center justify-between text-xs font-semibold text-emerald-900">
                      <span>
                        Kelas {lastScanned.student.className} •{" "}
                        {lastScanned.subjectName}
                      </span>
                      <span>
                        Progres Hadir: {lastScanned.classPresentCount}/
                        {lastScanned.classTotalStudents} Siswa
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Recent Scan History Feed */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-slate-900">
                    Riwayat Scan Sesi Ini ({scanLogs.length})
                  </h3>
                  {scanLogs.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setScanLogs([])}
                      className="text-xs text-slate-400 hover:text-slate-700 cursor-pointer"
                    >
                      Bersihkan Log
                    </button>
                  )}
                </div>

                {scanLogs.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center">
                    Belum ada riwayat scan pada sesi layar ini.
                  </p>
                ) : (
                  <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                    {scanLogs.map((log) => (
                      <div
                        key={log.logId}
                        className="py-2.5 flex items-center justify-between gap-2 text-xs"
                      >
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 truncate">
                            {log.student.name}
                          </p>
                          <p className="text-slate-500">
                            Kelas {log.student.className} • {log.subjectName}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-bold">
                            Hadir
                          </span>
                          <p className="font-mono-code text-[11px] text-slate-400 mt-0.5">
                            {log.scannedAt}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* SUB-TAB 2: GENERATOR & CETAK KARTU BARCODE SISWA                     */}
      {/* ==================================================================== */}
      {subTab === "cards" && (
        <div className="space-y-6 print-container">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 no-print">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setCardClassFilter("all")}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer ${
                  cardClassFilter === "all"
                    ? "bg-slate-900 text-white border-slate-900"
                    : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                }`}
              >
                Semua Kelas ({students.length})
              </button>
              {classes.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCardClassFilter(String(c.id))}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer ${
                    cardClassFilter === String(c.id)
                      ? "bg-blue-700 text-white border-blue-700"
                      : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  Kelas {c.name} ({c.studentCount})
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={cardSearch}
                  onChange={(e) => setCardSearch(e.target.value)}
                  placeholder="Cari siswa / kode barcode..."
                  className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-sm text-slate-900"
                />
              </div>

              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                Cetak Kartu Barcode
              </button>
            </div>
          </div>

          {/* Printable Student Barcode Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 print:grid-cols-2 print:gap-4">
            {filteredCardStudents.map((stu) => (
              <StudentBarcodeCard
                key={stu.id}
                student={stu}
                settings={settings}
                onQuickScan={(code) => {
                  setSubTab("scanner");
                  submitScannedCode(code);
                }}
                onRegenerate={handleRegenerateStudentBarcode}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

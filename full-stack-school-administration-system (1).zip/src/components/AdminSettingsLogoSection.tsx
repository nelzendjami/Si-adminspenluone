"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ShieldCheck,
  Upload,
  RotateCcw,
  Lock,
  Save,
  Loader2,
  Image as ImageIcon,
  CheckCircle2,
  KeyRound,
  UserPlus,
  Trash2,
  Database,
  Download,
  Sparkles,
  Link2,
  AlertTriangle,
} from "lucide-react";
import {
  ClassItem,
  SchoolSettingsData,
  SessionUserData,
  TeacherItem,
  ToastMessage,
} from "@/types/school";
import {
  getStoredSessionToken,
  optimizeLogoFileToDataUrl,
  setStoredSessionToken,
} from "@/lib/client-auth";

interface ManagedUserItem {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: string;
  teacherId: number | null;
  teacherName: string | null;
  teacherNip: string | null;
  assignedClassId: number | null;
  assignedClassName: string | null;
}

interface AdminSettingsLogoSectionProps {
  settings: SchoolSettingsData;
  teachers: TeacherItem[];
  classes: ClassItem[];
  currentUser: SessionUserData | null;
  onLoginSuccess: (user: SessionUserData) => void;
  onSettingsUpdated: (updated: SchoolSettingsData) => void;
  onRefreshBootstrap: () => Promise<void>;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
}

export default function AdminSettingsLogoSection({
  settings,
  teachers,
  classes,
  currentUser,
  onLoginSuccess,
  onSettingsUpdated,
  onRefreshBootstrap,
  onNotify,
}: AdminSettingsLogoSectionProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Inline Admin Login state when unauthenticated or logged in as non-admin
  const [loginId, setLoginId] = useState("admin");
  const [loginPassword, setLoginPassword] = useState("admin123");
  const [loggingIn, setLoggingIn] = useState(false);

  // Logo upload & URL state
  const [previewLogo, setPreviewLogo] = useState<string | null>(null);
  const [selectedLogoName, setSelectedLogoName] = useState<string>("");
  const [logoExternalUrl, setLogoExternalUrl] = useState<string>("");
  const [dragActive, setDragActive] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  // School Profile state
  const [schoolName, setSchoolName] = useState(settings.schoolName);
  const [npsn, setNpsn] = useState(settings.npsn);
  const [academicYear, setAcademicYear] = useState(settings.academicYear);
  const [semester, setSemester] = useState(settings.semester);
  const [address, setAddress] = useState(settings.address);
  const [email, setEmail] = useState(settings.email);
  const [phone, setPhone] = useState(settings.phone);
  const [savingProfile, setSavingProfile] = useState(false);

  // Admin Own Credentials state
  const [adminUsername, setAdminUsername] = useState(
    currentUser?.username || "admin"
  );
  const [adminEmail, setAdminEmail] = useState(
    currentUser?.email || "admin@smpn1umalulu.sch.id"
  );
  const [newPassword, setNewPassword] = useState("");
  const [savingAccount, setSavingAccount] = useState(false);

  // School User Accounts Management state
  const [managedUsers, setManagedUsers] = useState<ManagedUserItem[]>([]);
  const [newAccUsername, setNewAccUsername] = useState("");
  const [newAccPassword, setNewAccPassword] = useState("");
  const [newAccRole, setNewAccRole] = useState<"wali_kelas" | "guru_mapel" | "admin">(
    "wali_kelas"
  );
  const [newAccTeacherId, setNewAccTeacherId] = useState<string>(
    teachers[0] ? String(teachers[0].id) : ""
  );
  const [creatingUser, setCreatingUser] = useState(false);
  const [processingMaint, setProcessingMaint] = useState(false);

  const isAdmin = currentUser?.role === "admin";

  const loadManagedUsers = useCallback(async () => {
    if (!isAdmin) return;
    try {
      const res = await fetch("/api/users");
      const data = await res.json();
      if (res.ok && Array.isArray(data.users)) {
        setManagedUsers(data.users);
      }
    } catch {
      // ignore
    }
  }, [isAdmin]);

  useEffect(() => {
    setSchoolName(settings.schoolName);
    setNpsn(settings.npsn);
    setAcademicYear(settings.academicYear);
    setSemester(settings.semester);
    setAddress(settings.address);
    setEmail(settings.email);
    setPhone(settings.phone);
  }, [settings]);

  useEffect(() => {
    if (currentUser) {
      setAdminUsername(currentUser.username);
      setAdminEmail(currentUser.email);
    }
  }, [currentUser]);

  useEffect(() => {
    loadManagedUsers();
  }, [loadManagedUsers]);

  // Persist a prepared logo DataURL or URL directly to PostgreSQL
  const persistLogoDataUrl = useCallback(
    async (
      dataUrlToSave: string,
      fileLabel?: string,
      explicitToken?: string | null
    ) => {
      setUploadingLogo(true);
      try {
        const activeToken = explicitToken || getStoredSessionToken();
        const url = activeToken
          ? `/api/settings?_st=${encodeURIComponent(activeToken)}`
          : "/api/settings";
        const res = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(activeToken ? { "X-Session-Token": activeToken } : {}),
          },
          body: JSON.stringify({
            logoDataUrl: dataUrlToSave,
            _st: activeToken,
          }),
        });

        let data: { settings?: SchoolSettingsData; error?: string } = {};
        try {
          data = await res.json();
        } catch {
          throw new Error(
            "Ukuran gambar terlalu besar atau format tidak dikenali."
          );
        }

        if (!res.ok || !data.settings) {
          throw new Error(data.error || "Gagal menyimpan logo ke database.");
        }

        // Immediate 0ms state update across Sidebar, Overview, Barcode Cards & Print Header
        onSettingsUpdated(data.settings);
        setPreviewLogo(null);
        setLogoExternalUrl("");
        if (fileLabel) setSelectedLogoName(fileLabel);

        onNotify({
          type: "success",
          title: "Logo Sekolah Berhasil Diperbarui!",
          description:
            "Logo baru telah aktif pada Sidebar, Halaman Login, Kartu Barcode, dan Kop Surat.",
        });
      } catch (err: unknown) {
        onNotify({
          type: "error",
          title: "Gagal menyimpan logo",
          description:
            err instanceof Error ? err.message : "Terjadi kesalahan saat menyimpan.",
        });
      } finally {
        setUploadingLogo(false);
      }
    },
    [onSettingsUpdated, onNotify]
  );

  // Process dropped or picked file: optimize resolution + auto-save if already logged in as Admin!
  async function processIncomingFile(file: File) {
    try {
      setUploadingLogo(true);
      const optimizedDataUrl = await optimizeLogoFileToDataUrl(file);
      setPreviewLogo(optimizedDataUrl);
      setSelectedLogoName(file.name);

      if (isAdmin) {
        await persistLogoDataUrl(optimizedDataUrl, file.name);
      } else {
        setUploadingLogo(false);
        onNotify({
          type: "info",
          title: "Pratinjau Logo Siap!",
          description:
            "Klik tombol 'Masuk & Terapkan Logo' di sebelah kanan untuk menyimpan ke server.",
        });
      }
    } catch (err: unknown) {
      setUploadingLogo(false);
      onNotify({
        type: "error",
        title: "File gambar tidak dapat dibaca",
        description:
          err instanceof Error
            ? err.message
            : "Gunakan file PNG, JPG, WEBP, atau SVG.",
      });
    }
  }

  function handleSelectLogoFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    // Reset value immediately so selecting the same file again still triggers onChange
    e.target.value = "";
    if (!file) return;
    processIncomingFile(file);
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processIncomingFile(file);
    }
  }

  async function handleInlineAdminLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoggingIn(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identifier: loginId,
          password: loginPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        onNotify({
          type: "error",
          title: "Login Admin Gagal",
          description: data.error || "Periksa username dan password.",
        });
        setLoggingIn(false);
        return;
      }

      if (data.token) {
        setStoredSessionToken(data.token);
      }
      onLoginSuccess(data.user);
      setAdminUsername(data.user.username);
      setAdminEmail(data.user.email);

      // If user already picked a logo before signing in, immediately apply & save it now!
      if (previewLogo && data.user?.role === "admin") {
        await persistLogoDataUrl(previewLogo, selectedLogoName, data.token);
      } else {
        onNotify({
          type: "success",
          title: "Berhasil Masuk sebagai Admin Pribadi",
          description:
            "Silakan pilih atau seret file Logo Sekolah untuk langsung menerapkannya.",
        });
      }
    } catch {
      onNotify({ type: "error", title: "Koneksi gagal" });
    } finally {
      setLoggingIn(false);
    }
  }

  async function handleApplyExternalUrl(e: React.FormEvent) {
    e.preventDefault();
    if (!logoExternalUrl.trim()) return;
    await persistLogoDataUrl(logoExternalUrl.trim(), "Logo via URL");
  }

  async function handleResetDefaultLogo() {
    setUploadingLogo(true);
    try {
      const activeToken = getStoredSessionToken();
      const targetUrl = activeToken
        ? `/api/settings?_st=${encodeURIComponent(activeToken)}`
        : "/api/settings";
      const res = await fetch(targetUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(activeToken ? { "X-Session-Token": activeToken } : {}),
        },
        body: JSON.stringify({ resetDefault: true, _st: activeToken }),
      });
      const data = await res.json();
      if (!res.ok || !data.settings)
        throw new Error(data.error || "Gagal mereset logo");

      onSettingsUpdated(data.settings);
      setPreviewLogo(null);
      setSelectedLogoName("");
      onNotify({
        type: "info",
        title: "Logo dikembalikan ke lambang standar SMPN 1 Umalulu",
      });
    } catch (err: unknown) {
      onNotify({
        type: "error",
        title: "Gagal mereset logo",
        description: err instanceof Error ? err.message : "Terjadi kesalahan",
      });
    } finally {
      setUploadingLogo(false);
    }
  }

  async function handleSaveSchoolProfile(e: React.FormEvent) {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...settings,
          schoolName,
          npsn,
          academicYear,
          semester,
          address,
          email,
          phone,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menyimpan profil");
      if (data.settings) onSettingsUpdated(data.settings);
      onNotify({
        type: "success",
        title: "Identitas Sekolah berhasil disimpan",
      });
    } catch {
      onNotify({ type: "error", title: "Gagal menyimpan identitas sekolah" });
    } finally {
      setSavingProfile(false);
    }
  }

  async function handleUpdateAdminCredentials(e: React.FormEvent) {
    e.preventDefault();
    setSavingAccount(true);
    try {
      const activeToken = getStoredSessionToken();
      const targetUrl = activeToken
        ? `/api/auth/me?_st=${encodeURIComponent(activeToken)}`
        : "/api/auth/me";
      const res = await fetch(targetUrl, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          ...(activeToken ? { "X-Session-Token": activeToken } : {}),
        },
        body: JSON.stringify({
          username: adminUsername,
          email: adminEmail,
          fullName: currentUser?.fullName || "Admin Pribadi SMPN 1 Umalulu",
          newPassword,
          _st: activeToken,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal memperbarui akun");
      onLoginSuccess(data.user);
      setNewPassword("");
      loadManagedUsers();
      onNotify({
        type: "success",
        title: "Kredensial Admin Pribadi diperbarui",
      });
    } catch (err: unknown) {
      onNotify({
        type: "error",
        title: "Gagal memperbarui akun",
        description: err instanceof Error ? err.message : "Terjadi kesalahan",
      });
    } finally {
      setSavingAccount(false);
    }
  }

  async function handleCreateSchoolAccount(e: React.FormEvent) {
    e.preventDefault();
    setCreatingUser(true);
    try {
      const selectedTeacher = teachers.find(
        (t) => t.id === Number(newAccTeacherId)
      );
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: newAccUsername,
          password: newAccPassword,
          role: newAccRole,
          teacherId:
            newAccRole === "admin" || !newAccTeacherId
              ? null
              : Number(newAccTeacherId),
          fullName:
            newAccRole === "admin"
              ? `Admin ${newAccUsername}`
              : selectedTeacher?.name || newAccUsername,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal membuat akun");

      setNewAccUsername("");
      setNewAccPassword("");
      await loadManagedUsers();
      onNotify({
        type: "success",
        title: `Akun login "${data.user.username}" berhasil dibuat!`,
      });
    } catch (err: unknown) {
      onNotify({
        type: "error",
        title: "Gagal membuat akun pengguna",
        description: err instanceof Error ? err.message : "Periksa kembali isian",
      });
    } finally {
      setCreatingUser(false);
    }
  }

  async function handleDeleteUserAccount(u: ManagedUserItem) {
    if (!confirm(`Hapus akun login "${u.username}" (${u.fullName})?`)) return;
    try {
      const res = await fetch(`/api/users/${u.id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menghapus akun");
      setManagedUsers((prev) => prev.filter((item) => item.id !== u.id));
      onNotify({ type: "success", title: `Akun ${u.username} dihapus` });
    } catch (err: unknown) {
      onNotify({
        type: "error",
        title: "Tidak dapat menghapus akun",
        description: err instanceof Error ? err.message : "Terjadi kesalahan",
      });
    }
  }

  async function handleDownloadBackup() {
    setProcessingMaint(true);
    try {
      const res = await fetch("/api/system/manage");
      if (!res.ok) throw new Error("Gagal mengambil data backup.");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Backup_SI_ADMIN_${settings.schoolName.replace(
        /\s+/g,
        "_"
      )}_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      onNotify({
        type: "success",
        title: "File Backup Database (.json) Berhasil Diunduh",
      });
    } catch {
      onNotify({
        type: "error",
        title: "Gagal mengunduh cadangan database",
      });
    } finally {
      setProcessingMaint(false);
    }
  }

  async function handleSystemMaintenance(
    action: "reset_transactional_records" | "clear_demo_students",
    confirmMsg: string
  ) {
    if (!confirm(confirmMsg)) return;
    setProcessingMaint(true);
    try {
      const res = await fetch("/api/system/manage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal memproses");
      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: "Sistem Siap Digunakan",
        description: data.message,
      });
    } catch (err: unknown) {
      onNotify({
        type: "error",
        title: "Tindakan gagal",
        description: err instanceof Error ? err.message : "Terjadi kesalahan",
      });
    } finally {
      setProcessingMaint(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Hidden Global File Picker Input so any button or logo box click triggers cleanly */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,.png,.jpg,.jpeg,.webp,.svg,.gif,.ico,.bmp"
        onChange={handleSelectLogoFile}
        className="hidden"
      />

      {/* Section Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-1.5">
            <ShieldCheck className="w-3.5 h-3.5" />
            Panel Admin Pribadi & Kesiapan Publikasi Sekolah
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
            Logo Sekolah Manual, Akun Pengguna & Persiapan Publikasi
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Unggah logo resmi sekolah secara instan, kelola akun login Guru Wali
            & Guru Mapel, serta cadangkan data untuk pemakaian operasional.
          </p>
        </div>

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploadingLogo}
          className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-bold shadow-xs flex items-center gap-2 shrink-0 cursor-pointer"
        >
          {uploadingLogo ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Upload className="w-4 h-4" />
          )}
          Pilih File Logo Baru
        </button>
      </div>

      {/* ==================================================================== */}
      {/* CARD 1: IMPORT / GANTI LOGO SEKOLAH MANUAL                           */}
      {/* ==================================================================== */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Clickable Live Logo Preview Box */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
              Logo Sekolah Aktif
            </span>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Klik untuk memilih file logo baru dari perangkat"
              className="group relative w-40 h-40 rounded-2xl bg-white border-2 border-slate-200 hover:border-blue-500 shadow-xs p-3 flex items-center justify-center overflow-hidden transition-all cursor-pointer"
            >
              <img
                src={
                  previewLogo ||
                  settings.logoUrl ||
                  "/images/logo-smpn1-umalulu.png"
                }
                alt="Logo Sekolah"
                className="w-full h-full object-contain"
              />
              <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white p-2">
                <Upload className="w-6 h-6 mb-1" />
                <span className="text-xs font-bold">Klik Ganti Logo</span>
              </div>
            </button>

            <p className="text-sm font-bold text-slate-900 mt-4">
              {settings.schoolName}
            </p>
            <p className="text-xs text-slate-500">NPSN {settings.npsn}</p>

            {previewLogo ? (
              <span className="mt-2.5 inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                <ImageIcon className="w-3.5 h-3.5" />
                Menunggu Login Admin untuk Menyimpan
              </span>
            ) : (
              <span className="mt-2.5 inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Aktif di Sidebar, Kartu Barcode & Kop Surat
              </span>
            )}
          </div>

          {/* Right Action Area: Seamless Login + Instant Auto-Save Uploader */}
          <div className="lg:col-span-7">
            {!isAdmin ? (
              <div className="p-6 rounded-2xl bg-slate-50 border border-blue-200 space-y-4">
                <div className="flex items-center gap-2.5">
                  <Lock className="w-5 h-5 text-blue-700" />
                  <h2 className="text-lg font-bold text-slate-900">
                    Verifikasi Login Admin Pribadi
                  </h2>
                </div>
                <p className="text-sm text-slate-600">
                  {previewLogo
                    ? `File "${selectedLogoName}" sudah siap! Klik tombol di bawah untuk masuk sebagai Admin Pribadi sekaligus langsung menyimpan logo baru Anda.`
                    : "Masuk sebagai Admin Pribadi terlebih dahulu (atau pilih file logo lalu klik Masuk) agar perubahan logo tersimpan permanen di server."}
                </p>

                <form onSubmit={handleInlineAdminLogin} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Username Admin
                      </label>
                      <input
                        type="text"
                        value={loginId}
                        onChange={(e) => setLoginId(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Password Admin
                      </label>
                      <input
                        type="password"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <span className="text-xs text-slate-500">
                      Akun Awal:{" "}
                      <code className="font-mono-code font-semibold text-slate-800">
                        admin / admin123
                      </code>
                    </span>
                    <button
                      type="submit"
                      disabled={loggingIn || uploadingLogo}
                      className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-bold flex items-center gap-2 cursor-pointer"
                    >
                      {loggingIn || uploadingLogo ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <ShieldCheck className="w-4 h-4" />
                      )}
                      {previewLogo
                        ? "Masuk & Langsung Simpan Logo"
                        : "Masuk sebagai Admin Pribadi"}
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Sesi Admin Pribadi Aktif ({currentUser.username}) — Pilih file
                  untuk langsung mengganti logo otomatis
                </div>

                {/* Drag & Drop + Click File Upload Zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                    dragActive
                      ? "border-blue-600 bg-blue-50"
                      : "border-blue-300 hover:border-blue-600 bg-blue-50/40"
                  }`}
                >
                  {uploadingLogo ? (
                    <Loader2 className="w-8 h-8 text-blue-700 mx-auto mb-2 animate-spin" />
                  ) : (
                    <Upload className="w-8 h-8 text-blue-700 mx-auto mb-2" />
                  )}
                  <p className="text-sm font-bold text-slate-900">
                    {uploadingLogo
                      ? "Mengoptimalkan & Menyimpan Logo Sekolah..."
                      : selectedLogoName
                      ? `Terakhir Diunggah: ${selectedLogoName} (Klik / Seret File untuk Mengganti Lagi)`
                      : "Klik di Sini atau Seret File Logo Sekolah dari Komputer / HP"}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Mendukung PNG transparan, JPG, JPEG, WEBP, SVG, GIF, atau ICO
                    — otomatis dioptimalkan & langsung tersimpan
                  </p>
                </div>

                {/* Optional Paste Direct Logo URL Input */}
                <form
                  onSubmit={handleApplyExternalUrl}
                  className="flex flex-col sm:flex-row gap-2.5"
                >
                  <div className="relative flex-1">
                    <Link2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={logoExternalUrl}
                      onChange={(e) => setLogoExternalUrl(e.target.value)}
                      placeholder="Atau tempel link gambar logo (https://.../logo.png)..."
                      className="w-full pl-10 pr-3.5 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm text-slate-900"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={!logoExternalUrl.trim() || uploadingLogo}
                    className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-blue-700 text-white text-xs font-semibold shrink-0 disabled:opacity-50 cursor-pointer"
                  >
                    Gunakan Link URL
                  </button>
                </form>

                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingLogo}
                    className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
                  >
                    <ImageIcon className="w-4 h-4" />
                    Unggah File Logo dari Perangkat
                  </button>

                  <button
                    type="button"
                    disabled={uploadingLogo}
                    onClick={handleResetDefaultLogo}
                    className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Reset Logo Standar
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ==================================================================== */}
      {/* CARD 2: IDENTITAS SEKOLAH + KREDENSIAL ADMIN PRIBADI                 */}
      {/* ==================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handleSaveSchoolProfile}
          className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 space-y-4"
        >
          <h2 className="text-base font-bold text-slate-900">
            Identitas Resmi & Tahun Akademik Sekolah
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nama Satuan Pendidikan
              </label>
              <input
                type="text"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                NPSN
              </label>
              <input
                type="text"
                value={npsn}
                onChange={(e) => setNpsn(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono-code text-sm"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tahun Pelajaran
              </label>
              <input
                type="text"
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Semester Aktif
              </label>
              <select
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm bg-white"
              >
                <option value="Ganjil">Ganjil</option>
                <option value="Genap">Genap</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Alamat Lengkap Kop Surat Sekolah
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Email Resmi Sekolah
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Telepon Sekolah
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={savingProfile}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-blue-700 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              {savingProfile ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              Simpan Identitas Sekolah
            </button>
          </div>
        </form>

        {/* Admin Credential Management Card */}
        <form
          onSubmit={handleUpdateAdminCredentials}
          className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 space-y-4"
        >
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-blue-700" />
            <h2 className="text-base font-bold text-slate-900">
              Keamanan Akun Login Admin Pribadi
            </h2>
          </div>

          {!isAdmin ? (
            <p className="text-xs text-slate-500 leading-relaxed">
              Masuk sebagai Admin Pribadi terlebih dahulu pada kartu di atas
              untuk mengubah username, email, atau password Admin sebelum
              dipublikasikan untuk sekolah.
            </p>
          ) : (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Username Login Admin
                </label>
                <input
                  type="text"
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Email Admin
                </label>
                <input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password Baru Admin (Penting sebelum publikasi!)
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimal 6 karakter"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <button
                type="submit"
                disabled={savingAccount}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                {savingAccount && <Loader2 className="w-4 h-4 animate-spin" />}
                Perbarui Kredensial Admin
              </button>
            </>
          )}
        </form>
      </div>

      {/* ==================================================================== */}
      {/* CARD 3: MANAJEMEN AKUN LOGIN GURU WALI & GURU MAPEL (ADMIN ONLY)     */}
      {/* ==================================================================== */}
      {isAdmin && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-blue-700" />
                Manajemen Akun Login Guru Wali, Guru Mapel & Operator
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Buat akun login resmi untuk setiap Guru Wali (otomatis terkunci ke
                kelas binaannya) dan Guru Mata Pelajaran.
              </p>
            </div>
          </div>

          <form
            onSubmit={handleCreateSchoolAccount}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end bg-slate-50 p-4 rounded-2xl border border-slate-200"
          >
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Peran Akun *
              </label>
              <select
                value={newAccRole}
                onChange={(e) =>
                  setNewAccRole(
                    e.target.value as "wali_kelas" | "guru_mapel" | "admin"
                  )
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white font-semibold"
              >
                <option value="wali_kelas">Guru Wali (1 Kelas)</option>
                <option value="guru_mapel">Guru Mata Pelajaran</option>
                <option value="admin">Admin Sekolah</option>
              </select>
            </div>

            <div className="lg:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Pilih Guru Terkait
              </label>
              <select
                value={newAccTeacherId}
                disabled={newAccRole === "admin"}
                onChange={(e) => setNewAccTeacherId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white disabled:bg-slate-100"
              >
                {teachers.map((t) => (
                  <option key={t.id} value={String(t.id)}>
                    {t.name}{" "}
                    {t.homeroomClassName
                      ? `(Guru Wali ${t.homeroomClassName})`
                      : `(${t.subject})`}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username Baru *
              </label>
              <input
                type="text"
                value={newAccUsername}
                onChange={(e) => setNewAccUsername(e.target.value)}
                placeholder="misal: wali9a"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white"
                required
              />
            </div>

            <div className="flex gap-2">
              <div className="flex-1">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  value={newAccPassword}
                  onChange={(e) => setNewAccPassword(e.target.value)}
                  placeholder="Min. 6 kar"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={creatingUser}
                className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold self-end h-[38px] cursor-pointer"
              >
                {creatingUser ? "..." : "+ Buat"}
              </button>
            </div>
          </form>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-[11px] font-semibold uppercase text-slate-500">
                  <th className="py-2.5 pr-3">Username</th>
                  <th className="py-2.5 px-3">Nama Pengguna</th>
                  <th className="py-2.5 px-3">Peran</th>
                  <th className="py-2.5 px-3">Kelas Binaan / Akses</th>
                  <th className="py-2.5 pl-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {managedUsers.map((u) => (
                  <tr key={u.id}>
                    <td className="py-3 pr-3 font-mono-code font-bold text-slate-900">
                      {u.username}
                    </td>
                    <td className="py-3 px-3 font-medium text-slate-800">
                      {u.fullName}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-bold ${
                          u.role === "admin"
                            ? "bg-blue-50 text-blue-700"
                            : u.role === "wali_kelas"
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-amber-50 text-amber-700"
                        }`}
                      >
                        {u.role === "wali_kelas" ? "Guru Wali" : u.role}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-xs text-slate-600">
                      {u.role === "wali_kelas"
                        ? u.assignedClassName
                          ? `Terkunci Kelas ${u.assignedClassName}`
                          : "Belum terhubung kelas"
                        : u.role === "admin"
                        ? "Akses Penuh Seluruh Modul"
                        : "Absensi & Nilai Multi Kelas"}
                    </td>
                    <td className="py-3 pl-3 text-right">
                      {u.id !== currentUser?.id && (
                        <button
                          type="button"
                          onClick={() => handleDeleteUserAccount(u)}
                          className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* CARD 4: PUSAT PUBLIKASI, BACKUP DATABASE & MODE SIAP PAKAI           */}
      {/* ==================================================================== */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-700" />
              Pusat Publikasi, Backup Database & Persiapan Pemakaian Sekolah
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
               Daftar periksa kesiapan produksi, unduh cadangan data sekolah, serta
              pembersihan data contoh sebelum digunakan penuh di SMP Negeri 1
              Umalulu.
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold self-start">
            <Sparkles className="w-3.5 h-3.5" />
            Status Server & PostgreSQL: Siap Publikasi
          </span>
        </div>

        {/* Readiness Checklist */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <p className="font-bold text-slate-900">Database PostgreSQL</p>
              <p className="text-slate-500">Penyimpanan permanen aktif</p>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <p className="font-bold text-slate-900">Kop Surat & NIP Kepsek</p>
              <p className="text-slate-500">Siap cetak laporan & leger</p>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <p className="font-bold text-slate-900">
                {classes.length} Kelas & {teachers.length} Guru
              </p>
              <p className="text-slate-500">Aturan 1 Guru Wali = 1 Kelas</p>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <p className="font-bold text-slate-900">Scan Barcode & Excel</p>
              <p className="text-slate-500">Import/Export .xlsx & QR siap</p>
            </div>
          </div>
        </div>

        {isAdmin && (
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              type="button"
              disabled={processingMaint}
              onClick={handleDownloadBackup}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Unduh Backup Penuh (.JSON)
            </button>

            <button
              type="button"
              disabled={processingMaint}
              onClick={() =>
                handleSystemMaintenance(
                  "reset_transactional_records",
                  "Bersihkan seluruh riwayat absensi, nilai, dan bimbingan contoh untuk memulai semester baru? (Data Kelas, Guru, Mapel, Siswa, dan Logo Sekolah tetap aman)."
                )
              }
              className="px-4 py-2.5 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <AlertTriangle className="w-4 h-4" />
              Mulai Semester Baru (Reset Absensi & Nilai)
            </button>

            <button
              type="button"
              disabled={processingMaint}
              onClick={() =>
                handleSystemMaintenance(
                  "clear_demo_students",
                  "Kosongkan seluruh 36 data siswa contoh agar Anda dapat mengimpor data siswa asli SMP Negeri 1 Umalulu melalui Template Excel?"
                )
              }
              className="px-4 py-2.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              Kosongkan Siswa Contoh (Siap Import Riil)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

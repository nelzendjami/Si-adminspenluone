"use client";

import React from "react";
import {
  Users,
  School,
  BookMarked,
  CheckCircle2,
  ClipboardCheck,
  UserCheck,
  HeartHandshake,
  Image as ImageIcon,
  Award,
  ArrowRight,
  MapPin,
  ScanLine,
} from "lucide-react";
import {
  ActiveTab,
  ClassItem,
  NavigationOptions,
  RecapResponse,
  SchoolSettingsData,
  SessionUserData,
  StudentItem,
  SubjectItem,
  TeacherItem,
} from "@/types/school";

interface OverviewSectionProps {
  settings: SchoolSettingsData;
  classes: ClassItem[];
  teachers: TeacherItem[];
  subjects: SubjectItem[];
  students: StudentItem[];
  recap: RecapResponse | null;
  currentUser: SessionUserData | null;
  onNavigate: (
    tab: ActiveTab,
    classIdOrOpts?: number | NavigationOptions,
    barcodeOpts?: { mode: "mapel" | "wali"; subTab?: "scanner" | "cards" }
  ) => void;
}

export default function OverviewSection({
  settings,
  classes,
  teachers,
  subjects,
  students,
  recap,
  currentUser,
  onNavigate,
}: OverviewSectionProps) {
  const attendanceRate = recap?.summary?.attendanceRate ?? 92;
  const maleCount = students.filter((s) => s.gender === "L").length;
  const femaleCount = students.filter((s) => s.gender === "P").length;

  return (
    <div className="space-y-6">
      {/* Top School Identity & Campus Hero Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          <div className="lg:col-span-8 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-2.5 mb-4">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                  Tahun Pelajaran {settings.academicYear} • Semester{" "}
                  {settings.semester}
                </span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700">
                  NPSN:{" "}
                  <strong className="font-mono-code">{settings.npsn}</strong>
                </span>
              </div>

              <div className="flex items-start gap-4">
                <img
                  src={settings.logoUrl || "/images/logo-smpn1-umalulu.png"}
                  alt={settings.schoolName}
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-contain bg-slate-50 border border-slate-200 p-2 shrink-0"
                />
                <div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    {settings.schoolName}
                  </h1>
                  <p className="text-sm text-slate-600 mt-1 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>{settings.address}</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Principal Highlight Strip + Quick Actions */}
            <div className="mt-6 pt-6 border-t border-slate-100 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center shrink-0">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                    Kepala Sekolah
                  </p>
                  <p className="text-sm font-bold text-slate-900">
                    {settings.principalName}
                  </p>
                  <p className="text-xs font-mono-code text-slate-600">
                    NIP. {settings.principalNip}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  onClick={() =>
                    onNavigate("scan-barcode", undefined, {
                      mode: "mapel",
                      subTab: "scanner",
                    })
                  }
                  className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  <ScanLine className="w-4 h-4 text-emerald-400" />
                  Scan Barcode
                </button>
                <button
                  onClick={() => onNavigate("absensi-mapel")}
                  className="px-3.5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  <ClipboardCheck className="w-4 h-4" />
                  Absensi Mapel
                </button>
                <button
                  onClick={() => onNavigate("absensi-wali")}
                  className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" />
                  Absensi Guru Wali
                </button>
              </div>
            </div>
          </div>

          {/* Right Campus Banner */}
          <div className="lg:col-span-4 relative min-h-[210px] bg-slate-900 overflow-hidden">
            <img
              src="/images/campus-umalulu.jpg"
              alt="Halaman SMP Negeri 1 Umalulu"
              className="w-full h-full object-cover opacity-85"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-900/25 to-transparent p-6 flex flex-col justify-end">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-300">
                Kabupaten Sumba Timur • NTT
              </span>
              <p className="text-white font-bold text-base mt-0.5">
                Akademik, Nilai Mapel & Bimbingan Anak Wali
              </p>
              <button
                onClick={() => onNavigate("admin-logo")}
                className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-white/95 hover:text-blue-200 transition-colors cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>
                  {currentUser?.role === "admin"
                    ? "Kelola Logo Sekolah (Admin Aktif)"
                    : "Import Logo Sekolah (Login Admin Pribadi)"}
                </span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Core KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        <div
          onClick={() => onNavigate("siswa")}
          className="bg-white rounded-2xl border border-slate-200 p-6 hover:border-blue-300 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Total Peserta Didik
            </span>
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-extrabold text-slate-900 mt-3">
            {students.length}
          </p>
          <p className="text-xs text-slate-600 mt-1.5">
            {maleCount} L • {femaleCount} P • {teachers.length} Guru Aktif
          </p>
        </div>

        <div
          onClick={() =>
            onNavigate("mapel-nilai", {
              subjectOpts: { subTab: "master" },
            })
          }
          className="bg-white rounded-2xl border border-slate-200 p-6 hover:border-indigo-300 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Mata Pelajaran & Nilai
            </span>
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <BookMarked className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-extrabold text-slate-900 mt-3">
            {subjects.length} Mapel
          </p>
          <p className="text-xs text-slate-600 mt-1.5">
            Tambah/Edit/Hapus & Input Nilai Mapel
          </p>
        </div>

        <div
          onClick={() => onNavigate("bimbingan-wali")}
          className="bg-white rounded-2xl border border-slate-200 p-6 hover:border-amber-300 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Kelas & Bimbingan Wali
            </span>
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <School className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-extrabold text-slate-900 mt-3">
            {classes.length} Kelas
          </p>
          <p className="text-xs text-slate-600 mt-1.5">
            Jurnal Bimbingan & Pantauan Anak Wali
          </p>
        </div>

        <div
          onClick={() => onNavigate("rekapan")}
          className="bg-white rounded-2xl border border-slate-200 p-6 hover:border-emerald-300 transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Rata-Rata Kehadiran
            </span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-extrabold text-emerald-700 mt-3">
            {attendanceRate}%
          </p>
          <p className="text-xs text-slate-600 mt-1.5">
            H: {recap?.summary?.hadir ?? 0} • S: {recap?.summary?.sakit ?? 0} •
            I: {recap?.summary?.izin ?? 0} • A: {recap?.summary?.alpa ?? 0}
          </p>
        </div>
      </div>

      {/* Quick Action Cards + Daily Chart + Class Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Daily Trend & Quick Tools */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Tren Kehadiran 5 Hari Terakhir
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Gabungan Absensi Guru Wali & Mata Pelajaran
                </p>
              </div>
              <button
                onClick={() => onNavigate("rekapan")}
                className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
              >
                Lihat Rekapan
              </button>
            </div>

            <div className="space-y-4">
              {(recap?.dailyTrend || []).slice(-5).map((d) => (
                <div key={d.date} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono-code font-medium text-slate-700">
                      {d.date}
                    </span>
                    <span className="font-semibold text-slate-900">
                      {d.percentage}% Hadir ({d.hadir}/{d.total})
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
                    <div
                      style={{
                        width: `${d.total ? (d.hadir / d.total) * 100 : 0}%`,
                      }}
                      className="bg-emerald-500 h-full"
                      title={`Hadir: ${d.hadir}`}
                    />
                    <div
                      style={{
                        width: `${d.total ? (d.sakit / d.total) * 100 : 0}%`,
                      }}
                      className="bg-sky-500 h-full"
                      title={`Sakit: ${d.sakit}`}
                    />
                    <div
                      style={{
                        width: `${d.total ? (d.izin / d.total) * 100 : 0}%`,
                      }}
                      className="bg-amber-400 h-full"
                      title={`Izin: ${d.izin}`}
                    />
                    <div
                      style={{
                        width: `${d.total ? (d.alpa / d.total) * 100 : 0}%`,
                      }}
                      className="bg-rose-500 h-full"
                      title={`Alpa: ${d.alpa}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Shortcut Action Tiles */}
          <div className="mt-6 pt-5 border-t border-slate-100 grid grid-cols-3 gap-3">
            <button
              onClick={() =>
                onNavigate("mapel-nilai", {
                  subjectOpts: { subTab: "grades" },
                })
              }
              className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 text-left transition-all cursor-pointer"
            >
              <BookMarked className="w-4 h-4 text-blue-700 mb-1.5" />
              <p className="text-xs font-bold text-slate-900">Input Nilai</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Daftar nilai mapel
              </p>
            </button>
            <button
              onClick={() => onNavigate("bimbingan-wali")}
              className="p-3 rounded-xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-200 text-left transition-all cursor-pointer"
            >
              <HeartHandshake className="w-4 h-4 text-emerald-700 mb-1.5" />
              <p className="text-xs font-bold text-slate-900">Bimbingan</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Jurnal anak wali
              </p>
            </button>
            <button
              onClick={() =>
                onNavigate("scan-barcode", undefined, {
                  mode: "mapel",
                  subTab: "cards",
                })
              }
              className="p-3 rounded-xl bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 text-left transition-all cursor-pointer"
            >
              <ScanLine className="w-4 h-4 text-indigo-700 mb-1.5" />
              <p className="text-xs font-bold text-slate-900">Kartu Barcode</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Cetak per siswa
              </p>
            </button>
          </div>
        </div>

        {/* Right: Classes & Single Guru Wali Assignment Table */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Daftar Kelas & Guru Wali Binaan (1 Kelas / Guru Wali)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Pintasan cepat Absensi, Pantauan Nilai Lintas Mapel, dan
                Bimbingan Anak Wali
              </p>
            </div>
            <button
              onClick={() => onNavigate("kelas")}
              className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer"
            >
              Kelola Kelas
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  <th className="py-3 pr-4">Kelas</th>
                  <th className="py-3 px-4">Guru Wali (NIP)</th>
                  <th className="py-3 px-4 text-center">Siswa</th>
                  <th className="py-3 pl-4 text-right">Pintasan Cepat</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {classes.map((cls) => (
                  <tr
                    key={cls.id}
                    className="hover:bg-slate-50/80 transition-colors"
                  >
                    <td className="py-3.5 pr-4">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 font-bold text-xs border border-blue-200">
                        {cls.name}
                      </span>
                      <span className="block text-[11px] text-slate-500 mt-0.5">
                        {cls.room}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      {cls.homeroomTeacherName ? (
                        <div>
                          <p className="font-semibold text-slate-900 text-xs sm:text-sm">
                            {cls.homeroomTeacherName}
                          </p>
                          <p className="font-mono-code text-[11px] text-slate-500">
                            NIP. {cls.homeroomTeacherNip}
                          </p>
                        </div>
                      ) : (
                        <span className="text-xs italic text-amber-600">
                          Belum ada Guru Wali
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center font-semibold text-slate-700 text-xs">
                      {cls.studentCount} Siswa
                    </td>
                    <td className="py-3.5 pl-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          onClick={() =>
                            onNavigate("mapel-nilai", {
                              classId: cls.id,
                              subjectOpts: { subTab: "matrix" },
                            })
                          }
                          title="Pantau Nilai Kelas"
                          className="px-2.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-xs font-semibold transition-colors cursor-pointer"
                        >
                          Nilai
                        </button>
                        <button
                          onClick={() =>
                            onNavigate("bimbingan-wali", { classId: cls.id })
                          }
                          title="Bimbingan Anak Wali"
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-semibold transition-colors cursor-pointer"
                        >
                          Bimbingan
                        </button>
                        <button
                          onClick={() => onNavigate("absensi-mapel", cls.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-blue-700 text-white text-xs font-semibold transition-colors cursor-pointer"
                        >
                          Absen
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

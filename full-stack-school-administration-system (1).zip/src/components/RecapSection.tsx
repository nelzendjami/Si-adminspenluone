"use client";

import React, { useCallback, useEffect, useState } from "react";
import * as XLSX from "xlsx";
import {
  FileSpreadsheet,
  Printer,
  Search,
  Loader2,
  Filter,
} from "lucide-react";
import {
  ClassItem,
  RecapResponse,
  SchoolSettingsData,
  SubjectItem,
  TeacherItem,
  ToastMessage,
} from "@/types/school";

interface RecapSectionProps {
  settings: SchoolSettingsData;
  classes: ClassItem[];
  subjects: SubjectItem[];
  teachers: TeacherItem[];
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
}

export default function RecapSection({
  settings,
  classes,
  subjects,
  teachers,
  onNotify,
}: RecapSectionProps) {
  const todayStr = new Date().toISOString().slice(0, 10);
  const thirtyDaysAgo = (() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().slice(0, 10);
  })();

  const [classId, setClassId] = useState<string>("all");
  const [attendanceType, setAttendanceType] = useState<string>("all");
  const [subjectName, setSubjectName] = useState<string>("all");
  const [startDate, setStartDate] = useState<string>(thirtyDaysAgo);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);
  const [recap, setRecap] = useState<RecapResponse | null>(null);

  const loadRecap = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        classId,
        type: attendanceType,
        subjectName,
        startDate,
        endDate,
      });
      const res = await fetch(`/api/recap?${params.toString()}`);
      const data = await res.json();
      if (res.ok) setRecap(data);
    } catch {
      onNotify({
        type: "error",
        title: "Gagal memuat rekapan",
        description: "Silakan muat ulang halaman.",
      });
    } finally {
      setLoading(false);
    }
  }, [classId, attendanceType, subjectName, startDate, endDate, onNotify]);

  useEffect(() => {
    loadRecap();
  }, [loadRecap]);

  const filteredStudents = (recap?.studentRecap || []).filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nisn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.className.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedClassObj =
    classId !== "all" ? classes.find((c) => c.id === Number(classId)) : null;

  const signingTeacher = (() => {
    if (attendanceType === "mapel" && subjectName !== "all") {
      const s = subjects.find((item) => item.name === subjectName);
      if (s?.teacherId) {
        return teachers.find((t) => t.id === s.teacherId) || null;
      }
    }
    if (selectedClassObj?.homeroomTeacherId) {
      return (
        teachers.find((t) => t.id === selectedClassObj.homeroomTeacherId) ||
        null
      );
    }
    return teachers[0] || null;
  })();

  function handleExportExcel() {
    if (!recap) return;
    const exportRows = filteredStudents.map((s, index) => ({
      No: index + 1,
      NISN: s.nisn,
      NIS: s.nis,
      "Nama Peserta Didik": s.name,
      "L/P": s.gender,
      Kelas: s.className,
      Hadir: s.hadir,
      Sakit: s.sakit,
      Izin: s.izin,
      Alpa: s.alpa,
      "Total Pertemuan": s.total,
      "Persentase Kehadiran (%)": `${s.percentage}%`,
    }));

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(exportRows);
    ws["!cols"] = [
      { wch: 6 },
      { wch: 15 },
      { wch: 10 },
      { wch: 28 },
      { wch: 6 },
      { wch: 10 },
      { wch: 8 },
      { wch: 8 },
      { wch: 8 },
      { wch: 8 },
      { wch: 16 },
      { wch: 22 },
    ];
    XLSX.utils.book_append_sheet(wb, ws, "Rekapan_Absensi");
    XLSX.writeFile(
      wb,
      `Rekapan_Absensi_${settings.schoolName.replace(/\s+/g, "_")}_${endDate}.xlsx`
    );

    onNotify({
      type: "success",
      title: "File Excel berhasil diunduh",
      description: "Data rekapan absensi telah diekspor ke format .xlsx.",
    });
  }

  return (
    <div className="space-y-6 print-container">
      {/* Official Printable Kop Surat Header (Hidden on screen, visible on Print) */}
      <div className="hidden print-only border-b-4 border-double border-black pb-4 mb-6">
        <div className="flex items-center justify-between gap-4">
          <img
            src={settings.logoUrl || "/images/logo-smpn1-umalulu.png"}
            alt="Logo Sekolah"
            className="w-20 h-20 object-contain"
          />
          <div className="text-center flex-1">
            <p className="text-sm font-bold uppercase tracking-wide">
              Pemerintah Kabupaten Sumba Timur
            </p>
            <p className="text-sm font-bold uppercase tracking-wide">
              Dinas Pendidikan, Kepemudaan dan Olahraga
            </p>
            <h1 className="text-xl font-extrabold uppercase mt-0.5">
              {settings.schoolName}
            </h1>
            <p className="text-xs mt-1">
              NPSN: {settings.npsn} • {settings.address}
            </p>
          </div>
          <div className="w-20" />
        </div>
      </div>

      {/* Screen Header & Action Buttons */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-1.5">
              <Filter className="w-3.5 h-3.5" />
              Laporan & Analitik Kehadiran
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              Rekapan Absensi Siswa & Cetak Laporan Resmi
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Rekapitulasi kehadiran per kelas, mata pelajaran, maupun Guru Wali
              lengkap dengan Kop Surat & tanda tangan Kepala Sekolah beserta NIP.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Export Excel (.xlsx)
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Cetak Rekapan Resmi
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 pt-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Jenis Absensi
            </label>
            <select
              value={attendanceType}
              onChange={(e) => setAttendanceType(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
            >
              <option value="all">Semua (Guru Wali & Mapel)</option>
              <option value="wali">Khusus Absensi Guru Wali</option>
              <option value="mapel">Khusus Absensi Mata Pelajaran</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Pilih Kelas
            </label>
            <select
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
            >
              <option value="all">Semua Kelas</option>
              {classes.map((c) => (
                <option key={c.id} value={String(c.id)}>
                  Kelas {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Mata Pelajaran
            </label>
            <select
              value={subjectName}
              disabled={attendanceType !== "mapel"}
              onChange={(e) => setSubjectName(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white disabled:bg-slate-100 text-sm text-slate-900"
            >
              <option value="all">Semua Mapel</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Dari Tanggal
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Sampai Tanggal
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900"
            />
          </div>
        </div>
      </div>

      {/* Print Report Title */}
      <div className="hidden print-only text-center mb-4">
        <h2 className="text-base font-bold uppercase underline">
          REKAPITULASI KEHADIRAN PESERTA DIDIK
        </h2>
        <p className="text-xs mt-1">
          Periode: {startDate} s/d {endDate} • Kelas:{" "}
          {selectedClassObj ? selectedClassObj.name : "Semua Kelas"} • Tahun
          Pelajaran {settings.academicYear} ({settings.semester})
        </p>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 no-print">
        <div className="bg-white rounded-2xl border border-slate-200 p-4">
          <span className="text-xs font-semibold text-slate-500">
            Tingkat Kehadiran
          </span>
          <p className="text-2xl font-extrabold text-blue-700 mt-1">
            {recap?.summary.attendanceRate ?? 0}%
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-emerald-200 p-4">
          <span className="text-xs font-semibold text-emerald-700">
            Total Hadir (H)
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 mt-1">
            {recap?.summary.hadir ?? 0}
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-sky-200 p-4">
          <span className="text-xs font-semibold text-sky-700">
            Total Sakit (S)
          </span>
          <p className="text-2xl font-extrabold text-sky-700 mt-1">
            {recap?.summary.sakit ?? 0}
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-amber-200 p-4">
          <span className="text-xs font-semibold text-amber-700">
            Total Izin (I)
          </span>
          <p className="text-2xl font-extrabold text-amber-700 mt-1">
            {recap?.summary.izin ?? 0}
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-rose-200 p-4 col-span-2 sm:col-span-1">
          <span className="text-xs font-semibold text-rose-700">
            Total Alpa (A)
          </span>
          <p className="text-2xl font-extrabold text-rose-700 mt-1">
            {recap?.summary.alpa ?? 0}
          </p>
        </div>
      </div>

      {/* Detailed Student Recap Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden print-container">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
          <h2 className="text-base font-bold text-slate-900">
            Rincian Kehadiran Per Peserta Didik ({filteredStudents.length} Siswa)
          </h2>
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter nama / NISN / kelas..."
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-sm text-slate-900"
            />
          </div>
        </div>

        {loading ? (
          <div className="p-12 flex flex-col items-center justify-center text-slate-500">
            <Loader2 className="w-7 h-7 animate-spin text-blue-600 mb-2" />
            <p className="text-sm">Menghitung rekapitulasi kehadiran...</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-600">
                  <th className="py-3.5 pl-6 pr-3">No</th>
                  <th className="py-3.5 px-3">NISN</th>
                  <th className="py-3.5 px-3">Nama Peserta Didik</th>
                  <th className="py-3.5 px-3 text-center">JK</th>
                  <th className="py-3.5 px-3 text-center">Kelas</th>
                  <th className="py-3.5 px-3 text-center text-emerald-700">
                    Hadir
                  </th>
                  <th className="py-3.5 px-3 text-center text-sky-700">Sakit</th>
                  <th className="py-3.5 px-3 text-center text-amber-700">
                    Izin
                  </th>
                  <th className="py-3.5 px-3 text-center text-rose-700">Alpa</th>
                  <th className="py-3.5 pl-3 pr-6 text-right">% Kehadiran</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredStudents.map((stu, idx) => (
                  <tr key={stu.studentId} className="hover:bg-slate-50/70">
                    <td className="py-3 pl-6 pr-3 text-xs text-slate-500">
                      {idx + 1}
                    </td>
                    <td className="py-3 px-3 font-mono-code text-xs text-slate-700">
                      {stu.nisn}
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-900">
                      {stu.name}
                    </td>
                    <td className="py-3 px-3 text-center text-xs font-semibold">
                      {stu.gender}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 text-xs font-bold">
                        {stu.className}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center font-bold text-emerald-700">
                      {stu.hadir}
                    </td>
                    <td className="py-3 px-3 text-center font-semibold text-sky-700">
                      {stu.sakit}
                    </td>
                    <td className="py-3 px-3 text-center font-semibold text-amber-700">
                      {stu.izin}
                    </td>
                    <td className="py-3 px-3 text-center font-semibold text-rose-700">
                      {stu.alpa}
                    </td>
                    <td className="py-3 pl-3 pr-6 text-right">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-full text-xs font-bold ${
                          stu.percentage >= 85
                            ? "bg-emerald-50 text-emerald-700"
                            : stu.percentage >= 75
                            ? "bg-amber-50 text-amber-700"
                            : "bg-rose-50 text-rose-700"
                        }`}
                      >
                        {stu.percentage}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Official Signature Block (Visible on screen card footer & Print report!) */}
        <div className="p-6 sm:p-8 border-t border-slate-200 bg-slate-50/50 grid grid-cols-1 sm:grid-cols-2 gap-8 text-sm">
          <div>
            <p className="text-xs text-slate-500">Mengetahui,</p>
            <p className="font-semibold text-slate-900">
              Kepala {settings.schoolName}
            </p>
            <div className="h-14" />
            <p className="font-bold text-slate-900 underline">
              {settings.principalName}
            </p>
            <p className="font-mono-code text-xs text-slate-600 mt-0.5">
              NIP. {settings.principalNip}
            </p>
          </div>

          <div className="sm:text-right">
            <p className="text-xs text-slate-500">
              Umalulu,{" "}
              {new Date().toLocaleDateString("id-ID", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </p>
            <p className="font-semibold text-slate-900">
              {attendanceType === "mapel" ? "Guru Mata Pelajaran" : "Guru Wali"}
            </p>
            <div className="h-14" />
            <p className="font-bold text-slate-900 underline">
              {signingTeacher?.name || "_______________________"}
            </p>
            <p className="font-mono-code text-xs text-slate-600 mt-0.5">
              NIP. {signingTeacher?.nip || "-"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

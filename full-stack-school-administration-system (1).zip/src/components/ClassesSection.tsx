"use client";

import React, { useState } from "react";
import {
  Plus,
  Pencil,
  Trash2,
  School,
  UserCheck,
  Users,
  X,
  Loader2,
  ClipboardCheck,
  ScanLine,
} from "lucide-react";
import {
  ActiveTab,
  ClassItem,
  TeacherItem,
  ToastMessage,
} from "@/types/school";

interface ClassesSectionProps {
  classes: ClassItem[];
  teachers: TeacherItem[];
  onRefreshBootstrap: () => Promise<void>;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
  onNavigate: (
    tab: ActiveTab,
    classId?: number,
    barcodeOpts?: { mode: "mapel" | "wali"; subTab?: "scanner" | "cards" }
  ) => void;
}

export default function ClassesSection({
  classes,
  teachers,
  onRefreshBootstrap,
  onNotify,
  onNavigate,
}: ClassesSectionProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ClassItem | null>(null);

  const [name, setName] = useState("");
  const [gradeLevel, setGradeLevel] = useState<number>(7);
  const [room, setRoom] = useState("");
  const [academicYear, setAcademicYear] = useState("2025/2026");
  const [capacity, setCapacity] = useState<number>(32);
  const [homeroomTeacherId, setHomeroomTeacherId] = useState<string>("");
  const [transferWali, setTransferWali] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState(false);

  function openAddModal() {
    setEditingClass(null);
    setName("");
    setGradeLevel(7);
    setRoom("Gedung A - R.07");
    setAcademicYear("2025/2026");
    setCapacity(32);
    const freeTeacher = teachers.find((t) => !t.homeroomClassId);
    setHomeroomTeacherId(freeTeacher ? String(freeTeacher.id) : "");
    setTransferWali(false);
    setModalOpen(true);
  }

  function openEditModal(cls: ClassItem) {
    setEditingClass(cls);
    setName(cls.name);
    setGradeLevel(cls.gradeLevel);
    setRoom(cls.room);
    setAcademicYear(cls.academicYear);
    setCapacity(cls.capacity);
    setHomeroomTeacherId(
      cls.homeroomTeacherId ? String(cls.homeroomTeacherId) : ""
    );
    setTransferWali(false);
    setModalOpen(true);
  }

  const chosenTeacherObj = teachers.find(
    (t) => t.id === Number(homeroomTeacherId)
  );
  const conflictOtherClass =
    chosenTeacherObj &&
    chosenTeacherObj.homeroomClassId &&
    chosenTeacherObj.homeroomClassId !== editingClass?.id
      ? chosenTeacherObj.homeroomClassName
      : null;

  async function handleSaveClass(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        name,
        gradeLevel,
        room,
        academicYear,
        capacity,
        homeroomTeacherId: homeroomTeacherId ? Number(homeroomTeacherId) : null,
        transferWali,
      };

      const res = editingClass
        ? await fetch(`/api/classes/${editingClass.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch("/api/classes", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });

      const data = await res.json();
      if (!res.ok) {
        onNotify({
          type: "error",
          title: "Gagal menyimpan data kelas",
          description: data.error || "Periksa kembali isian formulir.",
        });
        setSubmitting(false);
        return;
      }

      await onRefreshBootstrap();
      setModalOpen(false);
      onNotify({
        type: "success",
        title: editingClass
          ? `Kelas ${name.toUpperCase()} diperbarui`
          : `Kelas ${name.toUpperCase()} berhasil ditambahkan`,
        description: "Data kelas dan Guru Wali tersimpan di database.",
      });
    } catch {
      onNotify({
        type: "error",
        title: "Terjadi kesalahan jaringan",
      });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleConfirmDelete() {
    if (!deleteTarget) return;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/classes/${deleteTarget.id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Gagal menghapus kelas");
      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: `Kelas ${deleteTarget.name} berhasil dihapus`,
      });
      setDeleteTarget(null);
    } catch {
      onNotify({
        type: "error",
        title: "Gagal menghapus kelas",
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-1.5">
            <School className="w-3.5 h-3.5" />
            Manajemen Rombongan Belajar
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
            Data Kelas (Tambah, Edit & Hapus Kelas)
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Kelola rombongan belajar Tingkat VII, VIII, dan IX beserta penugasan
            Guru Wali (1 Guru Wali khusus 1 Kelas).
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold shadow-xs flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Tambah Kelas Baru
        </button>
      </div>

      {/* Empty State or Class Grid */}
      {classes.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
          <School className="w-10 h-10 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900">
            Belum Ada Data Kelas
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Klik tombol Tambah Kelas Baru untuk membuat rombongan belajar pertama.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {classes.map((cls) => {
            const fillPct = Math.min(
              100,
              Math.round((cls.studentCount / (cls.capacity || 32)) * 100)
            );
            return (
              <div
                key={cls.id}
                className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between hover:border-blue-300 transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="inline-block px-2.5 py-0.5 rounded-md text-xs font-semibold bg-slate-100 text-slate-700">
                        Tingkat {cls.gradeLevel} • {cls.room}
                      </span>
                      <h2 className="text-2xl font-extrabold text-slate-900 mt-1.5">
                        Kelas {cls.name}
                      </h2>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => openEditModal(cls)}
                        title="Edit Kelas"
                        className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(cls)}
                        title="Hapus Kelas"
                        className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Guru Wali Box */}
                  <div className="mt-5 p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                      <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                      Guru Wali (Khusus 1 Kelas)
                    </div>
                    {cls.homeroomTeacherName ? (
                      <div className="mt-1">
                        <p className="text-sm font-bold text-slate-900">
                          {cls.homeroomTeacherName}
                        </p>
                        <p className="font-mono-code text-xs text-slate-500">
                          NIP. {cls.homeroomTeacherNip}
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs italic text-amber-600 mt-1">
                        Belum ditugaskan — Klik Edit untuk memilih Guru Wali
                      </p>
                    )}
                  </div>

                  {/* Student Capacity */}
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-slate-600 flex items-center gap-1.5 font-medium">
                        <Users className="w-3.5 h-3.5 text-blue-600" />
                        Jumlah Siswa Aktif
                      </span>
                      <span className="font-bold text-slate-900">
                        {cls.studentCount} / {cls.capacity} Siswa
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        style={{ width: `${fillPct}%` }}
                        className="h-full bg-blue-600 rounded-full"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                  <span className="text-xs text-slate-500">
                    TP {cls.academicYear}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() =>
                        onNavigate("scan-barcode", cls.id, {
                          mode: "mapel",
                          subTab: "scanner",
                        })
                      }
                      title="Scan Barcode Kelas Ini"
                      className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors cursor-pointer"
                    >
                      <ScanLine className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onNavigate("absensi-mapel", cls.id)}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <ClipboardCheck className="w-3.5 h-3.5" />
                      Absensi Mapel
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Class Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full shadow-xl overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editingClass
                  ? `Edit Kelas ${editingClass.name}`
                  : "Tambah Kelas Baru"}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveClass} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Kelas *
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Contoh: VII-C"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 uppercase"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tingkat Kelas *
                  </label>
                  <select
                    value={gradeLevel}
                    onChange={(e) => setGradeLevel(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 bg-white"
                  >
                    <option value={7}>Kelas 7 (VII)</option>
                    <option value={8}>Kelas 8 (VIII)</option>
                    <option value={9}>Kelas 9 (IX)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Ruang Belajar
                  </label>
                  <input
                    type="text"
                    value={room}
                    onChange={(e) => setRoom(e.target.value)}
                    placeholder="Gedung A - R.07"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kapasitas Kursi
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={60}
                    value={capacity}
                    onChange={(e) => setCapacity(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Guru Wali (1 Guru Wali = 1 Kelas Saja)
                </label>
                <select
                  value={homeroomTeacherId}
                  onChange={(e) => setHomeroomTeacherId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-900 bg-white"
                >
                  <option value="">-- Belum Ditentukan --</option>
                  {teachers.map((t) => (
                    <option key={t.id} value={String(t.id)}>
                      {t.name} (NIP. {t.nip}){" "}
                      {t.homeroomClassName
                        ? `— Guru Wali ${t.homeroomClassName}`
                        : "— Tersedia"}
                    </option>
                  ))}
                </select>
              </div>

              {conflictOtherClass && (
                <label className="flex items-start gap-2.5 p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={transferWali}
                    onChange={(e) => setTransferWali(e.target.checked)}
                    className="mt-0.5 rounded"
                  />
                  <span>
                    Guru ini saat ini bertugas sebagai Guru Wali pada Kelas{" "}
                    <strong>{conflictOtherClass}</strong>. Centang untuk
                    memindahkan tugas Guru Wali ke kelas ini (karena 1 Guru Wali
                    hanya boleh memegang 1 kelas saja).
                  </span>
                </label>
              )}

              <div className="pt-3 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
                >
                  {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                  {editingClass ? "Simpan Perubahan" : "Tambah Kelas"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Class Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-xl">
            <h3 className="text-lg font-bold text-slate-900">
              Hapus Kelas {deleteTarget.name}?
            </h3>
            <p className="text-sm text-slate-600 mt-2">
              Menghapus Kelas <strong>{deleteTarget.name}</strong> juga akan
              menghapus {deleteTarget.studentCount} data siswa beserta riwayat
              absensi pada kelas tersebut secara permanen.
            </p>
            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={submitting}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
              >
                {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                Ya, Hapus Kelas
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

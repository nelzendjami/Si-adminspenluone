"use client";

import React, { useState } from "react";
import {
  Award,
  GraduationCap,
  Plus,
  Pencil,
  Trash2,
  Save,
  X,
  Loader2,
  Search,
} from "lucide-react";
import {
  SchoolSettingsData,
  TeacherItem,
  ToastMessage,
} from "@/types/school";

interface TeachersPrincipalSectionProps {
  settings: SchoolSettingsData;
  teachers: TeacherItem[];
  onRefreshBootstrap: () => Promise<void>;
  onNotify: (msg: Omit<ToastMessage, "id">) => void;
}

export default function TeachersPrincipalSection({
  settings,
  teachers,
  onRefreshBootstrap,
  onNotify,
}: TeachersPrincipalSectionProps) {
  // Principal form state
  const [principalName, setPrincipalName] = useState(settings.principalName);
  const [principalNip, setPrincipalNip] = useState(settings.principalNip);
  const [savingPrincipal, setSavingPrincipal] = useState(false);

  // Teacher CRUD modal state
  const [searchQuery, setSearchQuery] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<TeacherItem | null>(
    null
  );
  const [name, setName] = useState("");
  const [nip, setNip] = useState("");
  const [subject, setSubject] = useState("");
  const [employmentStatus, setEmploymentStatus] = useState("PNS");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSavePrincipal(e: React.FormEvent) {
    e.preventDefault();
    setSavingPrincipal(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...settings,
          principalName,
          principalNip,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menyimpan");

      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: "Data Kepala Sekolah & NIP diperbarui",
        description: `${principalName} (NIP. ${principalNip}) tersimpan.`,
      });
    } catch (err: unknown) {
      onNotify({
        type: "error",
        title: "Gagal memperbarui Kepala Sekolah",
        description: err instanceof Error ? err.message : "Terjadi kesalahan",
      });
    } finally {
      setSavingPrincipal(false);
    }
  }

  function openAddTeacher() {
    setEditingTeacher(null);
    setName("");
    setNip("");
    setSubject("Seni Budaya");
    setEmploymentStatus("PNS");
    setPhone("");
    setModalOpen(true);
  }

  function openEditTeacher(t: TeacherItem) {
    setEditingTeacher(t);
    setName(t.name);
    setNip(t.nip);
    setSubject(t.subject);
    setEmploymentStatus(t.employmentStatus);
    setPhone(t.phone);
    setModalOpen(true);
  }

  async function handleSaveTeacher(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = { name, nip, subject, employmentStatus, phone };
      const res = editingTeacher
        ? await fetch(`/api/teachers/${editingTeacher.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await fetch("/api/teachers", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal menyimpan data guru");

      await onRefreshBootstrap();
      setModalOpen(false);
      onNotify({
        type: "success",
        title: editingTeacher
          ? "Data Guru Mapel diperbarui"
          : "Guru Mapel baru ditambahkan",
        description: `${name} — NIP. ${nip}`,
      });
    } catch (err: unknown) {
      onNotify({
        type: "error",
        title: "Gagal menyimpan data guru",
        description: err instanceof Error ? err.message : "Terjadi kesalahan",
      });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDeleteTeacher(t: TeacherItem) {
    if (!confirm(`Hapus data guru ${t.name} (NIP. ${t.nip})?`)) return;
    try {
      const res = await fetch(`/api/teachers/${t.id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      await onRefreshBootstrap();
      onNotify({
        type: "success",
        title: "Data guru berhasil dihapus",
      });
    } catch {
      onNotify({ type: "error", title: "Gagal menghapus data guru" });
    }
  }

  const filteredTeachers = teachers.filter(
    (t) =>
      t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.nip.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subject.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Card: Principal & NIP */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-11 h-11 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-700">
              Pimpinan Satuan Pendidikan
            </span>
            <h1 className="text-xl font-bold text-slate-900">
              Data Kepala Sekolah & NIP ({settings.schoolName})
            </h1>
          </div>
        </div>

        <form
          onSubmit={handleSavePrincipal}
          className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end"
        >
          <div className="md:col-span-5">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Nama Lengkap & Gelar Kepala Sekolah *
            </label>
            <input
              type="text"
              value={principalName}
              onChange={(e) => setPrincipalName(e.target.value)}
              placeholder="Drs. Umbu Maramba Meha, M.Pd."
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900"
              required
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              NIP Kepala Sekolah *
            </label>
            <input
              type="text"
              value={principalNip}
              onChange={(e) => setPrincipalNip(e.target.value)}
              placeholder="19690817 199512 1 003"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 font-mono-code text-sm text-slate-900"
              required
            />
          </div>

          <div className="md:col-span-3">
            <button
              type="submit"
              disabled={savingPrincipal}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-blue-700 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {savingPrincipal ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              Simpan Kepala Sekolah
            </button>
          </div>
        </form>
      </div>

      {/* Bottom Card: Subject Teachers & Guru Wali + NIP */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-blue-700" />
              <h2 className="text-lg font-bold text-slate-900">
                Daftar Nama Guru Mata Pelajaran & Guru Wali Beserta NIP
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Seluruh guru terhubung otomatis ke modul Absensi Mata Pelajaran,
              Absensi Guru Wali, dan Tanda Tangan Rekapan.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari Guru / NIP / Mapel..."
                className="pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-sm text-slate-900"
              />
            </div>

            <button
              onClick={openAddTeacher}
              className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Tambah Guru & NIP
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                <th className="py-3.5 pl-6 pr-3">No</th>
                <th className="py-3.5 px-3">Nama Guru & Gelar</th>
                <th className="py-3.5 px-3">NIP</th>
                <th className="py-3.5 px-3">Mata Pelajaran</th>
                <th className="py-3.5 px-3">Tugas Guru Wali</th>
                <th className="py-3.5 px-3">Status</th>
                <th className="py-3.5 pl-3 pr-6 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredTeachers.map((t, idx) => (
                <tr key={t.id} className="hover:bg-slate-50/70">
                  <td className="py-3.5 pl-6 pr-3 text-xs text-slate-500">
                    {idx + 1}
                  </td>
                  <td className="py-3.5 px-3">
                    <p className="font-semibold text-slate-900">{t.name}</p>
                    {t.phone && (
                      <p className="text-xs text-slate-400">{t.phone}</p>
                    )}
                  </td>
                  <td className="py-3.5 px-3 font-mono-code text-xs font-medium text-slate-800">
                    {t.nip}
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 border border-blue-200 text-xs font-semibold">
                      {t.subject}
                    </span>
                  </td>
                  <td className="py-3.5 px-3">
                    {t.homeroomClassName ? (
                      <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                        Guru Wali {t.homeroomClassName}
                      </span>
                    ) : (
                      <span className="text-xs text-slate-400">
                        Guru Mapel Murni
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-xs font-semibold">
                      {t.employmentStatus}
                    </span>
                  </td>
                  <td className="py-3.5 pl-3 pr-6 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        onClick={() => openEditTeacher(t)}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-blue-700 hover:bg-blue-50 cursor-pointer"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteTeacher(t)}
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-rose-700 hover:bg-rose-50 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Teacher Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full shadow-xl overflow-hidden">
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {editingTeacher
                  ? "Edit Data Guru & NIP"
                  : "Tambah Guru Mata Pelajaran & NIP"}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTeacher} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Lengkap & Gelar Guru *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Yosefina Rambu Ata, S.Pd."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  NIP (Nomor Induk Pegawai) *
                </label>
                <input
                  type="text"
                  value={nip}
                  onChange={(e) => setNip(e.target.value)}
                  placeholder="Contoh: 19910514 202012 2 008"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono-code text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mata Pelajaran Pengampu *
                  </label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Contoh: Matematika"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status Kepegawaian
                  </label>
                  <select
                    value={employmentStatus}
                    onChange={(e) => setEmploymentStatus(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="PNS">PNS</option>
                    <option value="PPPK">PPPK</option>
                    <option value="Honorer">Guru Honorer / Komite</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nomor Telepon / WhatsApp
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0812-xxxx-xxxx"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
                >
                  {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                  Simpan Guru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

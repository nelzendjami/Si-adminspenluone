# SI-ADMIN SMP Negeri 1 Umalulu

Sistem Informasi Administrasi Sekolah, **Absensi Scan Barcode Siswa Otomatis**, **Absensi Mata Pelajaran**, **Absensi Guru Wali (1 Kelas)**, **Daftar Nilai Per Mata Pelajaran**, **Bimbingan Anak Wali**, serta **Cetak Laporan Resmi Kop Surat** untuk **SMP Negeri 1 Umalulu, Kec. Umalulu, Kab. Sumba Timur, NTT**.

---

## 1. Cara Membuka & Mempublikasikan Sistem agar Bisa Diakses Guru

### Opsi A — Publikasi Instan Online (Cloud / Link Web Resmi)
1. **Langsung dari Platform Ini**: Klik tombol **Publish / Deploy / Open Preview in New Tab** di bagian atas layar untuk mendapatkan **URL publik HTTPS** yang bisa langsung dibagikan ke grup WhatsApp Guru **SMP Negeri 1 Umalulu** (bisa dibuka dari HP Android, iPhone, maupun Laptop).
2. **Hosting Cloud Mandiri (Gratis / Murah Permanen — Rekomendasi Jangka Panjang)**:
   - Unduh / ekspor kode sumber proyek ini ke **GitHub**.
   - Buat database PostgreSQL gratis di **Neon.tech** atau **Supabase**, lalu salin `DATABASE_URL`.
   - Hubungkan repositori GitHub ke **Vercel** atau **Railway**, tempel `DATABASE_URL` pada bagian *Environment Variables*, lalu klik **Deploy**.
   - Begitu aplikasi pertama kali dibuka, seluruh tabel database otomatis dibuat oleh sistem tanpa perlu konfigurasi rumit.

### Opsi B — Server Lokal Sekolah / Laptop Tata Usaha (Tanpa Kuota Internet)
Cocok digunakan di lingkungan sekolah menggunakan Wi-Fi Router lokal:
1. Pasang **Node.js (v20+)** dan **PostgreSQL** di komputer/laptop server Tata Usaha.
2. Buat file `.env` berisi:
   ```env
   DATABASE_URL=postgresql://postgres:password_anda@127.0.0.1:5432/smpn1_umalulu
   ```
3. Jalankan perintah berikut di Terminal / Command Prompt:
   ```bash
   npm install
   npx drizzle-kit push
   npm run build
   npm run start
   ```
4. Cek IP Wi-Fi laptop server (ketik `ipconfig`, misal `192.168.1.10`). Seluruh guru yang terhubung ke Wi-Fi sekolah dapat langsung mengakses sistem dari HP/Laptop melalui alamat `http://192.168.1.10:3000`.

---

## 2. Urutan Persiapan Awal oleh Admin Pribadi (10 Menit Pertama)

1. **Login sebagai Admin Pribadi**
   - Buka menu **Logo & Admin Pribadi** di bilah kiri.
   - Masuk menggunakan akun awal:
     - **Username**: `admin`
     - **Password**: `admin123`
2. **Amankan Password Admin & Unggah Logo Resmi Sekolah**
   - Klik kotak **Logo Sekolah Aktif** (atau pilih file PNG/JPG logo sekolah) — logo langsung tersimpan otomatis.
   - Pada bagian **Keamanan Akun Login Admin Pribadi**, ganti password `admin123` dengan password rahasia Anda, lalu klik **Perbarui Kredensial Admin**.
3. **Cek Data Kepala Sekolah, Guru, Kelas & Mata Pelajaran**
   - Buka menu **Guru Mapel & Kepsek**: sesuaikan nama & NIP Kepala Sekolah serta tambahkan seluruh Guru Mapel / Guru Wali beserta NIP asli.
   - Buka menu **Data Kelas**: pastikan seluruh rombel (`VII-A`, `VII-B`, dst.) dan **Guru Wali** masing-masing kelas sudah sesuai (1 Guru Wali = 1 Kelas).
   - Buka menu **Data Mapel & Nilai** → tab **Master Mapel**: sesuaikan daftar mata pelajaran dan nilai **KKM / KKTP**.
4. **Kosongkan Data Contoh & Import Siswa Asli**
   - Kembali ke menu **Logo & Admin Pribadi** → bagian bawah klik **Kosongkan Siswa Contoh (Siap Import Riil)**.
   - Buka menu **Data Siswa & Import** → klik **Unduh Template (.xlsx)**.
   - Isi data siswa asli (bisa salin-tempel dari Excel Dapodik: `NISN`, `NIS`, `Nama_Lengkap`, `JK`, `Kelas`, `Tempat_Lahir`, `Tanggal_Lahir`, `Nama_Orang_Tua`, `Alamat`), lalu klik **Import Data Siswa**. Kode Barcode unik tiap siswa otomatis dibuat!
5. **Cetak Kartu Absensi Barcode Siswa**
   - Buka menu **Scan & Kartu Barcode** → pilih tab **Kartu Barcode Siswa**, pilih kelas, lalu klik **Cetak Kartu Barcode** (bisa dicetak di kertas tebal/PVC dan dilaminating).
6. **Buat Akun Login untuk Setiap Guru Wali & Guru Mapel**
   - Di menu **Logo & Admin Pribadi** → bagian **Manajemen Akun Login Guru Wali, Guru Mapel & Operator**, buatkan username & password untuk masing-masing guru, lalu bagikan kepada mereka.

---

## 3. Penggunaan Harian oleh Dewan Guru

- **Petugas Piket / Guru di Kelas (Scan Barcode)**: Buka **Scan & Kartu Barcode**, pilih sesi (*Absensi Mapel* atau *Absensi Guru Wali*), lalu scan kartu siswa menggunakan **Alat Barcode Scanner USB/Wireless** atau **Kamera HP/Laptop**.
- **Guru Mata Pelajaran**: Login dengan akun Guru Mapel → input kehadiran per jam pelajaran pada **Absensi Mata Pelajaran**, serta input Nilai Tugas, UTS, dan UAS pada **Data Mapel & Nilai**.
- **Guru Wali (Khusus 1 Kelas Binaan)**: Login dengan akun Guru Wali → otomatis terkunci khusus pada kelas binaannya untuk mencatat **Absensi Guru Wali**, memantau leger nilai seluruh mapel anak walinya, serta mencatat pembinaan pada **Bimbingan Anak Wali**.
- **Rekapitulasi & Backup Rutin**: Cetak laporan resmi lengkap dengan Kop Surat & NIP Kepala Sekolah pada menu **Rekapan Absensi**, dan unduh salinan cadangan mingguan melalui tombol **Unduh Backup Penuh (.JSON)**.
